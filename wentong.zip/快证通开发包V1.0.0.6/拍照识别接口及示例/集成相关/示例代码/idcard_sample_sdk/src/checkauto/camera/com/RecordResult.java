package checkauto.camera.com;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import android.os.Environment;

//识别结果写入文件类
public class RecordResult {
	
	private RecordResult () {
		
	}
	
	public static RecordResult getInstance () {
		return new RecordResult();
	}
	/**
	 * 
	 * @param fileName  
	 * @param result  
	 * @return
	 */
	public boolean recordResult(String fileName, String ImageName, String result) {
		boolean sdCardExist = Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);
		if (sdCardExist) {
			String PATH = Environment.getExternalStorageDirectory().toString() + "/wtimage";
			File file = new File (PATH + "/" + fileName);
			if (!file.exists()) {
				try {
					file.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			BufferedWriter fw = null;
			try {
				fw = new BufferedWriter(new FileWriter(file, true));
				fw.append("閺傚洣娆㈤崥宥忕窗" + ImageName);
				fw.append(result);
				fw.append("\n\n");
			} catch (IOException e) {
				return false;
			} finally {
				try {
					fw.flush();
					fw.close();
				} catch (IOException e) {
					return false;
				}
			}
			return true;
		}
        return false;
    }
    
}
