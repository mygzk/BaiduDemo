/**
 * 
 */
package checkauto.camera.com;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import wintone.idcard.android.AuthParameterMessage;
import wintone.idcard.android.AuthService;
import wintone.idcard.android.IDCardHolderAPI;
import wintone.idcard.android.RecogParameterMessage;
import wintone.idcard.android.RecogService;
import wintone.idcard.android.ResultMessage;

import checkauto.photo.com.CutPhoto;

import com.wintone.demo.idcard.R;
import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Camera.Size;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.text.format.Time;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 
 * 项目名称：idcard_sample_sdk 类名称：CameraMRZActivity 类描述： 创建人：huangzhen
 * 创建时间：2014-4-15 下午2:58:46 修改人：huangzhen 修改时间：2014-4-15 下午2:58:46 
 * 修改备注：本类已废弃，MRZ码的识别已转移到CameraIDCardNOActivity.java类
 * 
 * @version
 * 
 */
public class CameraMRZActivity extends Activity implements
        SurfaceHolder.Callback, Camera.PreviewCallback {
    public static final String PATH = Environment.getExternalStorageDirectory()
            .toString() + "/wtimage/";
    private String strCaptureFilePath;
    private static final String TAG = "CameraMRZActivity";
    private int width, height;
    private int quality = 80;
    private byte[] imagedata;
    // 证件类型
    int nMainID = 0;
    private int srcwidth;
    private int srcheight;
    private int WIDTH;
    private int HEIGHT;
    public int recogType = -1;// 自动识别、划线识别
    private SurfaceHolder surfaceHolder;
    private SurfaceView surfaceView;
    TextView back_reset_text, take_recog_text, light_text, cut_text,
            lockTextView, textView;
    ImageButton backbtn, resetbtn, takepicbtn, confirmbtn, lighton, cutoff;
    ImageView top_left, top_right, bottom_left, bottom_right, left_cut,
            right_cut, imageView, lockImageView;
    RelativeLayout rlyaout;
    Camera camera;
    private List<String> focusModes;
    private ToneGenerator tone;
    private Bitmap bitmap;
    private int Format = ImageFormat.NV21;// .YUY2
    private int tick = 1;
    private Boolean unlockBoolean = true;
    private SensorManager sManager = null;
    private SensorEventListener myListener = null;
    private float x, y, z;
    private final int UPTATE_Difference_TIME = 200;
    private final float MoveDifference = 0.04f;
    private final float MoveDifferencemin = 0.001f;
    private long last_Time;
    // private Boolean noShakeBoolean = false;
    private List<float[]> mlist;
    private double move_Difference;
    private final int ListMaxLen = 3;
    private Boolean cut = true;
    IDCardHolderAPI idCardHolderAPI = new IDCardHolderAPI();
    private int[] arrayPos;
    private int istakePic = 0;// 判断是否是MRZ码，如果为0则不拍照，如果为1，就拍照
    private boolean startTakePic = false;// 是否开始拍照
    public long startTime;
    // Camera.Parameters p;
    private int picWidth = 0;
    private int flag = 1;
    private AuthService.authBinder authBinder;
    public RecogService.recogBinder recogBinder;
    private RecogParameterMessage rpm;
    private int ReturnAuthority = -1;
    private Size size;
    private boolean isHand = false;
    private int[] array;
    private boolean autoFocusBoolean = false;
    private Camera.AutoFocusCallback mAutoFocusCallback;
    private boolean isFocusing = false, noShakeBoolean = false;
    private String pictureName = "";
    private boolean isAutoPic = true;
    // huangzhen 测试 start
    private long previewStartTime;
    private long previewEndTime;
    private long regSuccess;
    private long startReg;
    private long endReg;
    private long startFocus, endFocus;

    // huangzhne 测试 end
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        width = dm.widthPixels;
        height = dm.heightPixels;
        // System.out.println("屏幕的宽度和高度:"+width+"--"+height);
        setContentView(R.layout.wintone_autocamera);
        if (nMainID == 0) {
            String cfg = "";
            try {
                cfg = readtxt();
            } catch (Exception e) {
                e.printStackTrace();
            }
            String cfgs[] = cfg.split("==##");
            if (cfgs != null && cfgs.length >= 2) {
                if (cfgs[0] != null && !cfgs[0].equals("")) {
                    try {
                        nMainID = Integer.parseInt(cfgs[0]);
                        System.out.println("nMainID:" + nMainID);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        // 设置拍摄尺寸
        Intent intent = this.getIntent();
        // 照片的分辨率2048--1536
        srcwidth = intent.getIntExtra("srcwidth", 2048);
        srcheight = intent.getIntExtra("srcheight", 1536);
        // 预览的分辨率
        WIDTH = intent.getIntExtra("WIDTH", 640);
        HEIGHT = intent.getIntExtra("HEIGHT", 480);
        recogType = intent.getIntExtra("recogType", 1);
        nMainID = intent.getIntExtra("nMainID", 1100);
        findview();
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(CameraMRZActivity.this);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        mlist = new ArrayList<float[]>();
        sManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        // 监听传感器事件
        myListener = new SensorEventListener() {
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }

            public void onSensorChanged(SensorEvent event) {
                long now_Time = System.currentTimeMillis();// 获取当前时间
                long time_Difference = now_Time - last_Time;
                if (time_Difference >= UPTATE_Difference_TIME) {
                    last_Time = now_Time;
                    x = event.values[SensorManager.DATA_X];
                    y = event.values[SensorManager.DATA_Y];
                    z = event.values[SensorManager.DATA_Z];

                    double move_Difference = getStableFloat(x, y, z);
                    if (move_Difference <= MoveDifference
                            && move_Difference >= MoveDifferencemin) {
                        noShakeBoolean = true;
                    }
                }
            }
        };
        sManager.registerListener(myListener,
                sManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);

    }

    private float getStableFloat(float x, float y, float z) {
        float move_Difference = 0.0f;
        float[] floatdata = { x, y, z };
        if (mlist.size() < ListMaxLen) {
            mlist.add(floatdata);
        } else {
            mlist.remove(0);
            mlist.add(floatdata);
        }
        if (mlist.size() < ListMaxLen) {
            return 0.1f;
        }
        float sumx = 0;
        float sumy = 0;
        float sumz = 0;
        int len = mlist.size();
        for (int i = 0; i < len; i++) {
            float[] dd = (float[]) mlist.get(i);
            sumx += dd[0];
            sumy += dd[1];
            sumz += dd[2];
        }
        float avgx = sumx / len;
        float avgy = sumy / len;
        float avgz = sumz / len;
        for (int i = 0; i < len; i++) {
            float[] dd = (float[]) mlist.get(i);
            move_Difference = (dd[0] - avgx) * (dd[0] - avgx) + (dd[1] - avgy)
                    * (dd[1] - avgy) + (dd[2] - avgz) * (dd[2] - avgz);
        }
        return move_Difference;
    }

    @Override
    protected void onStart() {
        // TODO Auto-generated method stub
        super.onStart();

    }

    /**
     * @Title: findview
     * @Description: 界面布局
     * @param 设定文件
     * @return void 返回类型
     * @throws
     */
    private void findview() {
        // TODO Auto-generated method stub
        back_reset_text = (TextView) findViewById(R.id.back_and_reset_text);
        back_reset_text.setTextColor(Color.BLACK);
        int button_width = (int) (height * 0.125);
        int button_distance = (int) (height * 0.1);

        RelativeLayout.LayoutParams lParams = new RelativeLayout.LayoutParams(
                button_width, button_width);
        lParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        lParams.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParams.topMargin = button_distance;
        backbtn = (ImageButton) findViewById(R.id.backbtn);
        backbtn.setLayoutParams(lParams);
        backbtn.setOnClickListener(new mClickListener());
        lParams = new RelativeLayout.LayoutParams(button_width, button_width);
        lParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        lParams.addRule(RelativeLayout.BELOW, R.id.backbtn);
        lParams.topMargin = button_distance;
        takepicbtn = (ImageButton) findViewById(R.id.takepic_btn);
        takepicbtn.setLayoutParams(lParams);
        takepicbtn.setOnClickListener(new mClickListener());
        top_left = (ImageView) findViewById(R.id.topleft);
        top_right = (ImageView) findViewById(R.id.topright);
        bottom_left = (ImageView) findViewById(R.id.bottomleft);
        bottom_right = (ImageView) findViewById(R.id.bottomright);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                (int) (height * 0.18), (int) (height * 0.18));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
                RelativeLayout.TRUE);
        top_left.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams((int) (height * 0.18),
                (int) (height * 0.18));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        top_right.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams((int) (height * 0.18),
                (int) (height * 0.18));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
                RelativeLayout.TRUE);
        bottom_left.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams((int) (height * 0.18),
                (int) (height * 0.18));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        bottom_right.setLayoutParams(layoutParams);

        int margin = 0;
        int cutImageLayoutHeight = 0;
        if (srcwidth == 1280 || srcwidth == 960) {
            margin = (int) ((height * 1.333) * 0.165);
            cutImageLayoutHeight = (int) (height * 0.135);
        }
        if (srcwidth == 1600 || srcwidth == 1200) {
            margin = (int) ((height * 1.333) * 0.19);
            cutImageLayoutHeight = (int) (height * 0.108);
        }
        if (srcwidth == 2048 || srcwidth == 1536) {
            margin = (int) ((height * 1.333) * 0.22);
            cutImageLayoutHeight = (int) (height * 0.13);
        }
        left_cut = (ImageView) findViewById(R.id.leftcut);
        right_cut = (ImageView) findViewById(R.id.rightcut);
        layoutParams = new RelativeLayout.LayoutParams(
                (int) (cutImageLayoutHeight * 0.6), cutImageLayoutHeight);
        layoutParams.addRule(RelativeLayout.CENTER_VERTICAL,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
                RelativeLayout.TRUE);
        layoutParams.leftMargin = margin;
        left_cut.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams(
                (int) (cutImageLayoutHeight * 0.6), cutImageLayoutHeight);
        layoutParams.addRule(RelativeLayout.CENTER_VERTICAL,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        layoutParams.rightMargin = margin;
        right_cut.setLayoutParams(layoutParams);

        // imageView = (ImageView) findViewById(R.id.backimageView);
        surfaceView = (SurfaceView) findViewById(R.id.surfaceViwe);
        textView = (TextView) findViewById(R.id.resulttextview);
        lockImageView = (ImageView) findViewById(R.id.unlockbutton);
        lockTextView = (TextView) findViewById(R.id.locktextview);
        // huangzhen 更改布局start
        if (width == 960 && height == 540) {
            textView.setTextSize(15);
            System.out.println(width + "--" + height);
        }
        if (width >= 1280 && height >= 736) {
            textView.setTextSize(20);
        }
        if (width < 960 && height < 540) {
            textView.setTextSize(13);
        }
        RelativeLayout layout = (RelativeLayout) findViewById(R.id.idcard_showlyaout);
        imageView = new ImageView(this);
        imageView.setId(R.id.backimageView);
        imageView.setBackgroundColor(Color.argb(50, 64, 95, 0xed));
        RelativeLayout.LayoutParams lParam = new RelativeLayout.LayoutParams(
                (int) (srcwidth * 0.76), height / 4);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParam.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        imageView.setLayoutParams(lParam);
        layout.addView(imageView);
        lParam = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParam.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        lockTextView.setLayoutParams(lParam);
        lParam = new RelativeLayout.LayoutParams(70, 70);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParam.addRule(RelativeLayout.LEFT_OF, R.id.locktextview);
        lockImageView.setLayoutParams(lParam);

        // huangzhen 更改布局 end
        rlyaout = (RelativeLayout) findViewById(R.id.idcard_rightlyaout);
        int layout_width = (int) (width - ((height * 4) / 3));
        RelativeLayout.LayoutParams lP = new RelativeLayout.LayoutParams(
                layout_width, height);
        lP.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
        lP.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        rlyaout.setLayoutParams(lP);
        if (nMainID == 1100 || nMainID == 1101) {
            left_cut.setBackgroundResource(R.drawable.leftcut);
            right_cut.setBackgroundResource(R.drawable.rightcut);
            // showTwoCutImageView();
        } else {
            top_left.setBackgroundResource(R.drawable.top_left);
            bottom_left.setBackgroundResource(R.drawable.bottom_left);
            top_right.setBackgroundResource(R.drawable.top_right);
            bottom_right.setBackgroundResource(R.drawable.bottom_right);
            // showFourImageView();
        }
        textView.setText("");
        lockImageView.setBackgroundResource(R.drawable.unlock);
        lockImageView.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (!lockTextView.getText().toString().equals("清空")) {
                    unlockBoolean = false;
                    lockTextView.setText("清空");
                    lockTextView.setTextColor(Color.WHITE);
                    lockImageView.setBackgroundResource(R.drawable.lock);
                } else {
                    lockTextView.setText("");
                    textView.setText("");
                    unlockBoolean = true;
                    lockImageView.setBackgroundResource(R.drawable.unlock);
                }
            }
        });

        lockTextView.setText("");
        lockTextView.setTextColor(Color.WHITE);
        lockTextView.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (!lockTextView.getText().toString().equals("清空")) {
                    lockTextView.setText("清空");
                    unlockBoolean = false;
                    lockImageView.setBackgroundResource(R.drawable.lock);
                } else {
                    lockTextView.setText("");
                    textView.setText("");
                    unlockBoolean = true;
                    lockImageView.setBackgroundResource(R.drawable.unlock);
                }
            }
        });

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // TODO Auto-generated method stub

        // 获得Camera对象
        if (null == camera) {
            camera = Camera.open();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
            int height) {
        // TODO Auto-generated method stub
        if (camera != null) {
            try {
                Camera.Parameters parameters = camera.getParameters();
                parameters.setPictureFormat(PixelFormat.JPEG);
                parameters.setPreviewSize(WIDTH, HEIGHT);
                parameters.setPictureSize(srcwidth, srcheight);
                int minFrameRates = parameters.getSupportedPreviewFrameRates()
                        .get(0);
                int maxFrameRates = parameters
                        .getSupportedPreviewFrameRates()
                        .get(parameters.getSupportedPreviewFrameRates().size() - 1);
                if (3 < maxFrameRates && 3 > minFrameRates)
                    parameters.setPreviewFrameRate(3);
                if (3 < maxFrameRates && 3 < minFrameRates)
                    parameters.setPreviewFrameRate(minFrameRates);
                if (3 > maxFrameRates)
                    parameters.setPreviewFrameRate(maxFrameRates);
                // focusModes = parameters.getSupportedFocusModes();
                camera.setParameters(parameters);
                camera.setPreviewDisplay(surfaceHolder);
                camera.startPreview();
                camera.setPreviewCallback(CameraMRZActivity.this);
                camera.startPreview();
            } catch (IOException e) {
                camera.release();
                camera = null;
                e.printStackTrace();
            }

        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // TODO Auto-generated method stub
        synchronized (this) {
            try {
                if (camera != null) {
                    camera.stopPreview();
                    camera.setPreviewCallback(null);
                    camera.release();
                    // isPreviewRunning = false;
                    camera = null;
                }
            } catch (Exception e) {
                Log.i("TAG", e.getMessage());
            }
        }
    }

    // 读取配置文件
    public String readtxt() throws IOException {
        File sdDir = null;
        boolean sdCardExist = Environment.getExternalStorageState().equals(
                android.os.Environment.MEDIA_MOUNTED); // 判断sd卡是否存在
        if (sdCardExist) {
            sdDir = Environment.getExternalStorageDirectory();// 获取跟目录
        }
        String paths = sdDir.toString();
        if (paths.equals("") || paths == null) {
            return "";
        }
        String path = paths + "/AndroidWT/idcard.cfg";
        File file = new File(path);
        if (!file.exists())
            return "";
        FileReader fileReader = new FileReader(path);
        BufferedReader br = new BufferedReader(fileReader);
        String str = "";
        String r = br.readLine();
        while (r != null) {
            str += r;
            r = br.readLine();
        }
        br.close();
        fileReader.close();
        return str;
    }

    private class mClickListener implements OnClickListener {
        public void onClick(View v) {
            switch (v.getId()) {
            case R.id.backbtn:
                if (myListener != null) {
                    sManager.unregisterListener(myListener);
                    sManager = null;
                    myListener = null;
                }
                closeCamera();
                finish();
                System.out.println("返回");
                break;
            // 拍照
            case R.id.takepic_btn:
                if (unlockBoolean)
                    isHand = true;
                System.out.println("拍照");
                break;

            }

        }
    }

    // 快门按下的时候onShutter()被回调拍照声音
    private ShutterCallback shutterCallback = new ShutterCallback() {
        public void onShutter() {
            if (tone == null)
                // 发出提示用户的声音
                tone = new ToneGenerator(1,// AudioManager.AUDIOFOCUS_REQUEST_GRANTED
                        ToneGenerator.MIN_VOLUME);
            tone.startTone(ToneGenerator.TONE_PROP_BEEP);
        }
    };
    /* 拍照后回显 */
    private PictureCallback PictureCallback = new PictureCallback() {
        public void onPictureTaken(byte[] data, final Camera camera) {
            strCaptureFilePath = PATH + "idcard_" + pictureName + ".jpg";
            startReg = System.currentTimeMillis();
            Intent recogIntent = new Intent(CameraMRZActivity.this,
                    RecogService.class);
            bindService(recogIntent, recogConn, Service.BIND_AUTO_CREATE);
            camera.stopPreview();
            camera.startPreview();// 开始预览
            camera.setPreviewCallback(CameraMRZActivity.this);

        }

    };

    public static int computeSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        int initialSize = computeInitialSampleSize(options, minSideLength,
                maxNumOfPixels);
        int roundedSize;
        if (initialSize <= 8) {
            roundedSize = 1;
            while (roundedSize < initialSize) {
                roundedSize <<= 1;
            }
        } else {
            roundedSize = (initialSize + 7) / 8 * 8;
        }
        return roundedSize;
    }

    private static int computeInitialSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        double w = options.outWidth;
        double h = options.outHeight;
        int lowerBound = (maxNumOfPixels == -1) ? 1 : (int) Math.ceil(Math
                .sqrt(w * h / maxNumOfPixels));
        int upperBound = (minSideLength == -1) ? 128 : (int) Math.min(
                Math.floor(w / minSideLength), Math.floor(h / minSideLength));
        if (upperBound < lowerBound) {
            return lowerBound;
        }
        if ((maxNumOfPixels == -1) && (minSideLength == -1)) {
            return 1;
        } else if (minSideLength == -1) {
            return lowerBound;
        } else {
            return upperBound;
        }
    }

    /* 相机重置 */
    private void resetCamera() {

        synchronized (this) {
            try {
                if (camera != null) {
                    camera.stopPreview();
                    camera.startPreview();
                    // camera.setPreviewCallback(this);
                }
            } catch (Exception e) {
                Log.i("TAG", e.getMessage());
            }
        }
    }

    private void hideFourImageView() {
        top_left.setVisibility(View.INVISIBLE);
        top_right.setVisibility(View.INVISIBLE);
        bottom_left.setVisibility(View.INVISIBLE);
        bottom_right.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onPreviewFrame(final byte[] data, final Camera camera) {
        // TODO Auto-generated method stub
        System.out.println("ss");
        if (unlockBoolean && noShakeBoolean) {
            try {
                if (camera.getParameters().getSupportedFocusModes() != null
                        && camera.getParameters().getSupportedFocusModes()
                                .contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                    if (startFocus == 0)
                        startFocus = System.currentTimeMillis();
                    camera.autoFocus(new AutoFocusCallback() {

                        @Override
                        public void onAutoFocus(boolean success,
                                final Camera camera) {
                            // TODO Auto-generated method stub

                            if (success) {
                                if (!isHand) {
                                    System.out.println("对焦成功");
                                    arrayPos = new int[4];
                                    endFocus = System.currentTimeMillis()
                                            - startFocus;
                                    startFocus = 0;
                                    previewStartTime = System
                                            .currentTimeMillis();
                                    istakePic = idCardHolderAPI
                                            .GetAcquireMRZSignal(data, WIDTH,
                                                    HEIGHT, arrayPos);
                                    // 自定义的toast
                                    Toast toast = new Toast(
                                            getApplicationContext());
                                    LayoutInflater inflater = getLayoutInflater();
                                    View layout = inflater
                                            .inflate(
                                                    R.layout.toast_layout,
                                                    (ViewGroup) findViewById(R.id.toast_layout_root));
                                    TextView text = (TextView) layout
                                            .findViewById(R.id.showToastInformation);

                                    toast.setView(layout);
                                    if (istakePic == 1)
                                        text.setText("对焦成功!" + "--" + "有护照"
                                                + istakePic);
                                    else {
                                        text.setText("对焦成功!" + "--" + "无护照"
                                                + istakePic);
                                    }
                                    toast.show();
                                    // 自定义的toast end
                                    previewEndTime = System.currentTimeMillis()
                                            - previewStartTime;
                                    System.out
                                            .println("istakePic：" + istakePic);
                                    System.out.println("判断是否为机读码:"
                                            + previewEndTime);
                                    if (istakePic == 1 && flag == 1) {
                                        flag = 0;
                                        array = arrayPos;
                                        // huangzhen 测试 start
                                        regSuccess = System.currentTimeMillis()
                                                - previewStartTime;
                                        previewStartTime = 0;
                                        System.out
                                                .println("判断成功:" + regSuccess);

                                        createPreviewData(data);
                                        camera.takePicture(shutterCallback,
                                                null, PictureCallback);
                                        isAutoPic = true;
                                        // isHand = false;
                                    } else if (istakePic == 0) {

                                        flag = 1;
                                    }
                                } else {

                                    createPreviewData(data);
                                    camera.takePicture(shutterCallback, null,
                                            PictureCallback);
                                    isAutoPic = false;

                                }
                            }

                        }
                    });
                }
                // 不支持自动对焦
                if (!isHand
                        && camera.getParameters().getSupportedFocusModes() != null
                        && !(camera.getParameters().getSupportedFocusModes()
                                .contains(Camera.Parameters.FOCUS_MODE_AUTO))) {

                    arrayPos = new int[4];
                    endFocus = System.currentTimeMillis() - startFocus;
                    startFocus = 0;
                    previewStartTime = System.currentTimeMillis();
                    istakePic = idCardHolderAPI.GetAcquireMRZSignal(data,
                            WIDTH, HEIGHT, arrayPos);
                    // 自定义的toast
                    Toast toast = new Toast(getApplicationContext());
                    LayoutInflater inflater = getLayoutInflater();
                    View layout = inflater.inflate(R.layout.toast_layout,
                            (ViewGroup) findViewById(R.id.toast_layout_root));
                    TextView text = (TextView) layout
                            .findViewById(R.id.showToastInformation);

                    toast.setView(layout);
                    if (istakePic == 1)
                        text.setText("有护照" + istakePic);
                    else {
                        text.setText("无护照" + istakePic);
                    }
                    toast.show();
                    // 自定义的toast end
                    previewEndTime = System.currentTimeMillis()
                            - previewStartTime;
                    System.out.println("istakePic：" + istakePic);
                    System.out.println("判断是否为机读码:" + previewEndTime);
                    if (istakePic == 1 && flag == 1) {
                        flag = 0;
                        array = arrayPos;
                        // huangzhen 测试 start
                        regSuccess = System.currentTimeMillis()
                                - previewStartTime;
                        previewStartTime = 0;
                        System.out.println("判断成功:" + regSuccess);

                        createPreviewData(data);
                        camera.takePicture(shutterCallback, null,
                                PictureCallback);
                        isAutoPic = true;
                    } else if (istakePic == 0) {

                        flag = 1;
                    }

                }
                if (isHand
                        && camera.getParameters().getSupportedFocusModes() != null
                        && !(camera.getParameters().getSupportedFocusModes()
                                .contains(Camera.Parameters.FOCUS_MODE_AUTO))) {
                    try {

                        System.out.println("手动拍照");
                        createPreviewData(data);
                        camera.takePicture(shutterCallback, null,
                                PictureCallback);
                        isAutoPic = false;

                    } catch (Exception e) {

                    }
                }
            } catch (Exception e) {

                // System.out.println("自动拍照失败");
            }
            noShakeBoolean = false;
        }
        if (!unlockBoolean) {
            if (camera != null)
                camera.cancelAutoFocus();
        }
    }

    public void closeCamera() {
        synchronized (this) {
            try {
                if (camera != null) {
                    camera.setPreviewCallback(null);
                    camera.release();
                    camera = null;
                }
            } catch (Exception e) {
                Log.i("TAG", e.getMessage());
            }
        }
    }

    // 识别验证
    public ServiceConnection recogConn = new ServiceConnection() {

        public void onServiceDisconnected(ComponentName name) {
            recogBinder = null;
        }

        public void onServiceConnected(ComponentName name, IBinder service) {
            recogBinder = (RecogService.recogBinder) service;

            RecogParameterMessage rpm = new RecogParameterMessage();
            rpm.nTypeInitIDCard = 0;
            rpm.nTypeLoadImageToMemory = 0;
            rpm.nMainID = nMainID;
            rpm.nSubID = null;
            rpm.GetSubID = true;
            rpm.lpHeadFileName = "";
            rpm.GetVersionInfo = true;
            rpm.logo = "";
            rpm.userdata = "";
            rpm.lpFileName = strCaptureFilePath;
            rpm.sn = "";
            rpm.authfile = "";
            rpm.isCut = true;
            rpm.array = new int[4];
            if (isAutoPic) {
                rpm.array[0] = array[0];
                rpm.array[1] = array[1];
                rpm.array[2] = array[2];
                rpm.array[3] = array[3];
                // 自动拍照时将rpm.ncheckmrz赋值为0
                rpm.ncheckmrz = 0;
            } else {
                rpm.array[0] = 0;
                rpm.array[1] = 0;
                rpm.array[2] = 0;
                rpm.array[3] = 0;
                // 手动拍照时将rpm.ncheckmrz赋值为1
                rpm.ncheckmrz = 1;
            }
            try {
                ResultMessage resultMessage;
                resultMessage = recogBinder.getRecogResult(rpm);
                if (resultMessage.ReturnAuthority == 0
                        && resultMessage.ReturnInitIDCard == 0
                        && resultMessage.ReturnLoadImageToMemory == 0
                        && resultMessage.ReturnRecogIDCard > 0) {
                    String iDResultString = "";
                    String[] GetFieldName = resultMessage.GetFieldName;
                    String[] GetRecogResult = resultMessage.GetRecogResult;
                    for (int i = 0; i < GetRecogResult.length; i++) {
                        if (GetFieldName[i] != null
                                && !GetFieldName[i].equals("")
                                && !GetFieldName.equals("null")) {
                            iDResultString += GetFieldName[i] + ":"
                                    + GetRecogResult[i] + "\n";

                        }
                    }
                    if (unlockBoolean) {
                        endReg = System.currentTimeMillis() - startReg;
                        System.out.println("识别花费时间" + endReg);
                        textView.setText("识别结果:" + "\n" + GetFieldName[10]
                                + ":" + GetRecogResult[10] + "\n"
                                + GetFieldName[11] + ":" + GetRecogResult[11]
                                + "\n"
                        );

                        unlockBoolean = false;
                        lockTextView.setText("清空");
                        lockTextView.setTextColor(Color.WHITE);
                        lockImageView.setBackgroundResource(R.drawable.lock);
                        isHand = false;

                    }
                } else {
                    String str = "";
                    if (resultMessage.ReturnAuthority == -100000) {
                        str = "未识别   代码： " + resultMessage.ReturnAuthority;
                    } else if (resultMessage.ReturnAuthority != 0) {
                        str = "激活失败 代码：" + resultMessage.ReturnAuthority;
                    } else if (resultMessage.ReturnInitIDCard != 0) {
                        str = "识别初始化失败 代码：" + resultMessage.ReturnInitIDCard;
                    } else if (resultMessage.ReturnLoadImageToMemory != 0) {
                        if (resultMessage.ReturnLoadImageToMemory == 3) {
                            str = "识别载入图像失败，请重新识别 代码："
                                    + resultMessage.ReturnLoadImageToMemory;
                        } else if (resultMessage.ReturnLoadImageToMemory == 1) {
                            str = "识别载入图像失败，识别初始化失败,请重试 代码："
                                    + resultMessage.ReturnLoadImageToMemory;
                        } else {
                            str = "识别载入图像失败 代码："
                                    + resultMessage.ReturnLoadImageToMemory;
                        }
                    } else if (resultMessage.ReturnRecogIDCard != 0) {
                        str = "识别失败 代码：" + resultMessage.ReturnRecogIDCard;
                    }
                    if (unlockBoolean) {
                        textView.setText("识别结果 :" + str + "\n"
                        );
                        unlockBoolean = false;

                        lockTextView.setText("清空");
                        lockTextView.setTextColor(Color.WHITE);
                        lockImageView.setBackgroundResource(R.drawable.lock);
                        isHand = false;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), "识别服务调用失败",
                        Toast.LENGTH_SHORT).show();

            } finally {
                if (recogBinder != null) {
                    unbindService(recogConn);
                }
            }

        }
    };

    /**
     * 
     * @Title: createPreviewData
     * @Description: 将预览的图片和.nv21文件存入test文件夹中
     * @param @param data 实时预览的数据
     * @return void 返回类型
     * @throws
     */
    public void createPreviewData(byte[] data) {
        String str = "";
        size = camera.getParameters().getPreviewSize();
        str = pictureName();
        pictureName = str;
        // 记录yuv420sp
        try {
            File dir = new File(PATH);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            // File file = new File("/sdcard/wtimage/idcard_" + str +
            // ".nv21");//
            // if (!file.exists())
            // file.createNewFile();
            // RandomAccessFile raf = new RandomAccessFile(file, "rw");
            // raf.write(data);
            // raf.close();
        } catch (Exception ex) {
            Log.e("TAG", ex.toString());
        }

        // YuvImage处理
        try {
            YuvImage yuvimage = new YuvImage(data, Format, size.width,
                    size.height, null);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            yuvimage.compressToJpeg(new Rect(0, 0, size.width, size.height),
                    quality, baos);
            FileOutputStream outStream = new FileOutputStream(String.format(
                    "/sdcard/wtimage/idcard_" + str + ".jpg",
                    System.currentTimeMillis()));
            outStream.write(baos.toByteArray());
            outStream.close();
            baos.close();
            // // 黄震 测试 start
            // System.out.println("array[0]:" + array[0] + "array[1]" + array[1]
            // + "array[2]:" + array[2] + "array[3]:" + array[2]);
            //
            // Bitmap bitmap = BitmapFactory.decodeFile(PATH + "/idcard_" + str
            // + ".jpg");
            // bitmap = Bitmap.createBitmap(bitmap, array[0], array[1], array[2]
            // - array[0], array[3] - array[1]);
            // try {
            // File file = new File(PATH + "idcard_" + str + "_direct.jpg");
            // if (file.exists()) {
            // file.delete();
            // }
            // file.createNewFile();
            // BufferedOutputStream bos = new BufferedOutputStream(
            // new FileOutputStream(file));
            // bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos);
            // System.out.println("存入图片");
            // bos.flush();
            // bos.close();
            // if (!bitmap.isRecycled()) {
            // bitmap.recycle();
            // bitmap = null;
            // }
            // } catch (Exception e) {
            // e.printStackTrace();
            // Toast.makeText(getApplicationContext(), "抛出异常",
            // Toast.LENGTH_SHORT).show();
            // }
            // // 黄震 测试 end

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
        }
    }

    /**
     * 
     * @Title: pictureName
     * @Description: 将文件命名
     * @param @return 设定文件
     * @return String 文件以时间命的名字
     * @throws
     */
    public String pictureName() {
        String str = "";
        Time t = new Time();
        t.setToNow(); // 取得系统时间。
        int year = t.year;
        int month = t.month + 1;
        int date = t.monthDay;
        int hour = t.hour; // 0-23
        int minute = t.minute;
        int second = t.second;
        if (month < 10)
            str = String.valueOf(year) + "0" + String.valueOf(month);
        else {
            str = String.valueOf(year) + String.valueOf(month);
        }
        if (date < 10)
            str = str + "0" + String.valueOf(date);
        else {
            str = str + String.valueOf(date);
        }
        if (hour < 10)
            str = str + "0" + String.valueOf(hour);
        else {
            str = str + String.valueOf(hour);
        }
        if (minute < 10)
            str = str + "0" + String.valueOf(minute);
        else {
            str = str + String.valueOf(minute);
        }
        if (second < 10)
            str = str + "0" + String.valueOf(second);
        else {
            str = str + String.valueOf(second);
        }
        return str;
    }

}
