package checkauto.camera.com;


import com.wintone.demo.idcard.R;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
/**
 * 
*    
* 项目名称：idcard_sample_sdk  
* 类名称：Html5Activity  
* 类描述： 用html5调用activtiy  
* 创建人：yujin  
* 创建时间：2015-3-30 上午11:38:17  
* 修改人：yujin  
* 修改时间：2015-3-30 上午11:38:17  
* 修改备注：   
* @version    
*
 */
public class Html5Activity extends Activity {
	private WebView webView;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// 加载页面
		webView = (WebView) findViewById(R.id.webview);
		// 允许JavaScript执行
		webView.getSettings().setJavaScriptEnabled(true);
		// 找到Html文件，也可以用网络上的文件
		webView.loadUrl("file:///android_asset/html5/index.html");
		// 添加一个对象, 让JS可以访问该对象的方法, 该对象中可以调用JS中的方法
		webView.addJavascriptInterface(new Contact(), "contact");
	}

	private final class Contact {
		// JavaScript调用此方法拨打电话
		public void call() {
			Intent intent=new Intent(Html5Activity.this,ImageChooser.class);
			Html5Activity.this.finish();
			startActivity(intent);
		}

	}
}
