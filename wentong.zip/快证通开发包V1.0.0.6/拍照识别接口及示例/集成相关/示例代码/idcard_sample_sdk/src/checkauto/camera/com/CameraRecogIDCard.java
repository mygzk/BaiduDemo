package checkauto.camera.com;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import wintone.idcard.android.IDCardCfg;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Camera.Size;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import checkauto.photo.com.CutPhoto;

import com.wintone.demo.idcard.R;

//用户可直接调用此类获得拍照+识别二代证、行驶证和驾照的功能，识别结果会返回到用户调用的界面上；
public class CameraRecogIDCard extends Activity implements
        SurfaceHolder.Callback {
    private static final String TAG = "CameraRecogIDCard";
    public static final String PATH = Environment.getExternalStorageDirectory()
            .toString() + "/wtimage/";
    public static final String PATH_EXSDCARD = Environment
            .getExternalStorageDirectory().toString();
    private String strCaptureFilePath = PATH + "/camera_snap.jpg";
    public static final Uri IMAGE_URI = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
    // 预览尺寸 默认设置
    public int WIDTH = 320;// 640;//1024;
    public int HEIGHT = 240;// 480;//768;
    // 拍摄尺寸 默认设置
    public int srcwidth = 2048;// 1600;//2048;final
    public int srcheight = 1536;// 1200;//1536;final
    // 裁切尺寸
    private int cutwidth = 1300;// 1845;//1100;
    private int cutheight = 200;// 1155;//750;
    // 证件类型
    private int nMainID = 0;
    String imagename = "";
    private Button backbtn, confirmbtn, resetbtn, takepicbtn, tbtn, light1,
            light2, cutButton, typeButton;
    private TextView text1;
    private Camera camera;
    private SurfaceView surfaceView;
    private SurfaceHolder surfaceHolder;
    private ToneGenerator tone;
    private ImageView BimageView, SimageView, view, lightView,
            imagexingshizheng;
    private OnCameraStatusListener listener;
    private boolean isTaking = false;
    private Bitmap bm;
    public Map<Object, Object> imagemap = new HashMap<Object, Object>();
    private byte[] imagedata;
    private RelativeLayout rlyaout;
    private Boolean cut = true;
    // private final static int CWJ_HEAP_SIZE = 20* 1024* 1024 ;
    // private final static float TARGET_HEAP_UTILIZATION = 0.75f;
    private DisplayMetrics dm;
    private String path = "";
    public long fastClick = 0;
    private boolean isCatchPreview = false;
    private boolean isCatchPicture = false;
    private String selectPath;
    private String lpFileName;
    private int nTypeInitIDCard = 0;
    private int nTypeLoadImageToMemory = 0;

    private int nSubID[] = null;
    private Boolean GetSubID = true;
    private String lpHeadFileName = "";
    private Boolean GetVersionInfo = true;
    private String sn = "";
    private String server = "";
    private String authfile = "";
    private String devcode;
    private String datefile;
    private String logo = "";
    private String picpathString = "";
    private String deviceId, androId;
    public static int DIALOG_ID = -1;
    public int quality = 50;
    private String[] type = { "一代身份证", "二代身份证正面", "二代身份证证背面", "临时身份证", "驾照",
            "行驶证", "军官证", "士兵证", "港澳通行证", "大陆通行证", "台湾通行证", "签证", "护照",
            "内地通行证正面", "内地通行证背面", "户口本", "车辆识别代号", "广东省居住证", "边防证A", "边防证B",
            "银行卡" };

    public void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);// 去掉标题栏
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);// 去掉信息栏
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int recogcamera_layout_id = getResources().getIdentifier(
                "recogcamera480800", "layout", this.getPackageName());
        setContentView(recogcamera_layout_id);
        // 横屏
        TelephonyManager telephonyManager;
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        // 获取deviceId
        StringBuilder sb = new StringBuilder();
        sb.append(telephonyManager.getDeviceId());
        deviceId = sb.toString();
        // 获取androId
        StringBuilder sb1 = new StringBuilder();
        sb1.append(Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ANDROID_ID));
        androId = sb1.toString();
        Intent intent = this.getIntent();
        nMainID = intent.getIntExtra("nMainID", 0);
        nTypeInitIDCard = intent.getIntExtra("nTypeInitIDCard", 0);
        nTypeLoadImageToMemory = intent
                .getIntExtra("nTypeLoadImageToMemory", 0);
        nSubID = intent.getIntArrayExtra("nSubID");
        GetSubID = intent.getBooleanExtra("GetSubID", true);
        lpHeadFileName = intent.getStringExtra("lpHeadFileName");
        GetVersionInfo = intent.getBooleanExtra("GetVersionInfo", true);
        sn = intent.getStringExtra("sn");
        server = intent.getStringExtra("server");
        authfile = intent.getStringExtra("authfile");
        Log.i(TAG, "authfile=" + authfile);
        logo = intent.getStringExtra("logo");
        lpFileName = intent.getStringExtra("lpFileName");
        devcode = intent.getStringExtra("devcode");
        datefile = intent.getStringExtra("datefile");
        quality = intent.getIntExtra("quality", 50);
        if (sn == null) {
            sn = "";
        }
        if (nMainID == 0) {
            nMainID = getMainId();
        }
        // 考虑用户传lpFileName和没传lpFileName的情况，没传就不保存文件，直接覆盖。
        if (null != lpFileName && !lpFileName.equals("")) {
            Log.i(TAG, "lpFileName is not null");
            File lpFile = new File(lpFileName);
            String lpFilePath = lpFile.getParent();
            File lpPath = new File(lpFilePath);
            if (!lpPath.exists()) {
                boolean success = lpPath.mkdirs();
                Log.i(TAG, "success:" + success);
            }
        } else {
            Log.i(TAG, "lpFileName is null");
            String defaultPath = PATH + "wt.jpg";
            lpFileName = defaultPath;
            File file = new File(lpFileName);
            String parentPath = file.getParent();
            File parentFile = new File(parentPath);
            if (!parentFile.exists()) {
                parentFile.mkdirs();
            }
        }
        findViews();
        isCallCustomCamera();
        if (isCatchPreview == false && isCatchPicture == false) {
            String partpath = Environment.getExternalStorageDirectory()
                    + "/wtimage";
            File dir = new File(partpath);
            if (!dir.exists()) {
                dir.mkdir();
            }
            Date date = new Date();
            selectPath = partpath + "/idcard" + date.getTime() + ".jpg";
            Intent takePictureFromCameraIntent = new Intent(
                    MediaStore.ACTION_IMAGE_CAPTURE);
            takePictureFromCameraIntent.putExtra(
                    android.provider.MediaStore.EXTRA_OUTPUT,
                    Uri.fromFile(new File(selectPath)));
            startActivityForResult(takePictureFromCameraIntent, 1);
            overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
        }
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(CameraRecogIDCard.this);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

    }

    // 读取配置文件
    public String readtxt() throws IOException {
        File sdDir = null;
        boolean sdCardExist = Environment.getExternalStorageState().equals(
                android.os.Environment.MEDIA_MOUNTED); // 判断sd卡是否存在
        if (sdCardExist) {
            sdDir = Environment.getExternalStorageDirectory();// 获取跟目录
        }
        String paths = sdDir.toString();
        if (paths.equals("") || paths == null) {
            return "";
        }
        String path = paths + "/AndroidWT/idcard.cfg";
        File file = new File(path);
        if (!file.exists())
            return "";
        FileReader fileReader = new FileReader(path);
        BufferedReader br = new BufferedReader(fileReader);
        String str = "";
        String r = br.readLine();
        while (r != null) {
            str += r;
            r = br.readLine();
        }
        br.close();
        fileReader.close();
        return str;
    }

    private void isCallCustomCamera() {
        Camera camera = null;
        try {
            camera = Camera.open();
            if (camera != null) {
                // 读取支持的预览尺寸,优先选择640后320
                Camera.Parameters parameters = camera.getParameters();
                Log.i(TAG,
                        "preview-size-values:"
                                + parameters.get("preview-size-values"));
                List<Camera.Size> previewSizes = splitSize(
                        parameters.get("preview-size-values"), camera);// parameters.getSupportedPreviewSizes();
                for (int i = 0; i < previewSizes.size(); i++) {
                    if (previewSizes.get(i).width == 640
                            && previewSizes.get(i).height == 480) {
                        isCatchPreview = true;
                        WIDTH = 640;
                        HEIGHT = 480;
                        break;
                    }
                    if (previewSizes.get(i).width == 320
                            && previewSizes.get(i).height == 240) {// 640 //480
                        isCatchPreview = true;
                        WIDTH = 320;
                        HEIGHT = 240;
                    }
                }
                // Log.i(TAG, "isCatchPreview="+isCatchPreview);
                // 读取支持的相机尺寸,优先选择1280后1600后2048
                Log.i(TAG,
                        "picture-size-values:"
                                + parameters.get("picture-size-values"));
                List<Camera.Size> PictureSizes = splitSize(
                        parameters.get("picture-size-values"), camera);// parameters.getSupportedPictureSizes();
                for (int i = 0; i < PictureSizes.size(); i++) {
                    if (PictureSizes.get(i).width == 2048
                            && PictureSizes.get(i).height == 1536) {
                        if (isCatchPicture == true) {
                            break;
                        }
                        isCatchPicture = true;
                        srcwidth = 2048;
                        srcheight = 1536;
                    }
                    if (PictureSizes.get(i).width == 1600
                            && PictureSizes.get(i).height == 1200) {
                        isCatchPicture = true;
                        srcwidth = 1600;
                        srcheight = 1200;
                    }
                    if (PictureSizes.get(i).width == 1280
                            && PictureSizes.get(i).height == 960) {
                        isCatchPicture = true;
                        srcwidth = 1280;
                        srcheight = 960;
                        break;
                    }
                }
                // Log.i(TAG, "isCatchPicture="+isCatchPicture);
            }
            camera.release();
            camera = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (camera != null) {
                try {
                    camera.release();
                    camera = null;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void findViews() {
        int backbtn_id = getResources().getIdentifier("recogbackbtn", "id",
                this.getPackageName());
        backbtn = (Button) findViewById(backbtn_id);
        backbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        });
        int takepicbtn_id = getResources().getIdentifier("recogtakepic_btn",
                "id", this.getPackageName());
        takepicbtn = (Button) findViewById(takepicbtn_id);
        takepicbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                takepicbtn.setEnabled(false);
                takePicture();
            }
        });
        int resetbtn_id = getResources().getIdentifier("recogreset_btn", "id",
                this.getPackageName());
        resetbtn = (Button) findViewById(resetbtn_id);
        resetbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                camera.startPreview();
                imagexingshizheng.setVisibility(View.VISIBLE);
                takepicbtn.setVisibility(View.VISIBLE);
                backbtn.setVisibility(View.VISIBLE);
                BimageView.setImageDrawable(null);
                resetbtn.setVisibility(View.GONE);
                confirmbtn.setVisibility(View.GONE);
                takepicbtn.setEnabled(true);
            }
        });
        int confirmbtn_id = getResources().getIdentifier("recogconfirm_btn",
                "id", this.getPackageName());
        confirmbtn = (Button) findViewById(confirmbtn_id);
        confirmbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (isEffectClick()) {
                    confirmbtn.setEnabled(false);
                    imagexingshizheng.setVisibility(View.VISIBLE);
                    takepicbtn.setVisibility(View.VISIBLE);
                    backbtn.setVisibility(View.VISIBLE);
                    resetbtn.setVisibility(View.INVISIBLE);
                    confirmbtn.setVisibility(View.INVISIBLE);
                    BimageView.setImageDrawable(null);
                    if (null != lpFileName) {
                        Log.i(TAG, "lpFileName=" + lpFileName);
                        savephoto(lpFileName);
                    } else {
                        Toast.makeText(getApplicationContext(), "文件件名为空",
                                Toast.LENGTH_SHORT).show();
                        Log.i(TAG, "文件名为空！");
                    }
                    displayResult();
                } else {
                    Log.i(TAG, "confirmbtn click invalid");
                }
            }
        });
        int light1_id = getResources().getIdentifier("recoglight1", "id",
                this.getPackageName());
        light1 = (Button) findViewById(light1_id);
        light1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                light2.setVisibility(View.VISIBLE);
                light1.setVisibility(View.INVISIBLE);
                // 开启闪光灯
                Camera.Parameters parameters = camera.getParameters();
                // parameters.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
                // //2.2
                parameters.set("flash-mode", "on");
                camera.setParameters(parameters);
            }
        });
        int light2_id = getResources().getIdentifier("recoglight2", "id",
                this.getPackageName());
        light2 = (Button) findViewById(light2_id);
        light2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                light1.setVisibility(View.VISIBLE);
                light2.setVisibility(View.INVISIBLE);
                // 关闭闪光灯
                Camera.Parameters parameters2 = camera.getParameters();
                // parameters2.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                // //2.2
                parameters2.set("flash-mode", "off");
                camera.setParameters(parameters2);
            }
        });
        // text1 = (TextView) findViewById(R.id.text1);
        int cutButton_id = getResources().getIdentifier("recogcutbut", "id",
                this.getPackageName());
        cutButton = (Button) findViewById(cutButton_id);
        cutButton.setVisibility(View.INVISIBLE);// 先暂时隐藏。
        cutButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (cutButton.getText().toString().equals("关闭裁切")) {
                    cutButton.setText("打开裁切");
                    cut = false;
                } else {
                    cutButton.setText("关闭裁切");
                    cut = true;
                }
            }
        });

        int recogtypebut_id = getResources().getIdentifier("recogtypebut",
                "id", this.getPackageName());
        typeButton = (Button) findViewById(recogtypebut_id);
        if (nMainID != 0) {
            typeButton.setVisibility(View.INVISIBLE);
        }
        typeButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                selectTypeDialog();
            }
        });
        int imagexingshizheng_id = getResources().getIdentifier(
                "recogimagexingshizheng", "id", this.getPackageName());
        imagexingshizheng = (ImageView) findViewById(imagexingshizheng_id);
        if (1100 == nMainID || 1101 == nMainID) {
            final int vin_photo_id = getResources().getIdentifier("vin_photo",
                    "drawable", this.getPackageName());
            imagexingshizheng.setBackgroundResource(vin_photo_id);
        } else {
            final int xingshizheng_photo_id = getResources().getIdentifier(
                    "xingshizheng_photo", "drawable", this.getPackageName());
            imagexingshizheng.setBackgroundResource(xingshizheng_photo_id);
            RelativeLayout.LayoutParams lP = new RelativeLayout.LayoutParams(
                    (int) (0.75*dm.widthPixels), dm.heightPixels);
            lP.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
            lP.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
            imagexingshizheng.setLayoutParams(lP);
        }
        int lightView_id = getResources().getIdentifier("light", "id",
                this.getPackageName());
        lightView = (ImageView) findViewById(lightView_id);
        int BimageView_id = getResources().getIdentifier("recogBimageView",
                "id", this.getPackageName());
        BimageView = (ImageView) findViewById(BimageView_id);
        int SimageView_id = getResources().getIdentifier("recogSImageView",
                "id", this.getPackageName());
        SimageView = (ImageView) findViewById(SimageView_id);
        int view_id = getResources().getIdentifier("recogfocusView", "id",
                this.getPackageName());
        view = (ImageView) findViewById(view_id);
        final int surfaceView_id = getResources().getIdentifier(
                "recogsurfaceViwe", "id", this.getPackageName());
        surfaceView = (SurfaceView) findViewById(surfaceView_id);
        int rlyaout_id = getResources().getIdentifier("recogrlyaout", "id",
                this.getPackageName());
        rlyaout= (RelativeLayout) findViewById(rlyaout_id) ;
        int relalayoutwidth = (int) (dm.widthPixels - ((dm.heightPixels * 4) / 3));
        RelativeLayout.LayoutParams lP = new RelativeLayout.LayoutParams(
                dm.widthPixels/4, dm.heightPixels);
        lP.leftMargin=3*dm.widthPixels/4;
        lP.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        rlyaout.setLayoutParams(lP);

    }

    public boolean isEffectClick() {
        long lastClick = System.currentTimeMillis();
        long diffTime = lastClick - fastClick;
        if (diffTime > 5000) {
            fastClick = lastClick;
            return true;
        }
        return false;
    }

    protected void selectTypeDialog() {
        int checkedItem = -1;
        if (nMainID == 1100) {
            checkedItem = 16;
        } else {
            checkedItem = nMainID - 1;
        }

        AlertDialog.Builder dialog = createAlertDialog("选择证件类型", null);
        dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                String cfg = "";
                cfg += nMainID + "==##";
                cfg += "END";
                IDCardCfg cardCfg = new IDCardCfg();
                try {
                    cardCfg.StringBufferDemo(cfg);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                cfg = "";
                dialog.dismiss();
            }
        });
        dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }

        });
        dialog.setSingleChoiceItems(type, checkedItem,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        IDCardCfg cardCfg = new IDCardCfg();
                        if (which == 16) {
                            nMainID = 1100;
                            String cfg = "";
                            cfg += nMainID + "==##";
                            cfg += "END";
                            try {
                                cardCfg.StringBufferDemo(cfg);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } else if (which == 20) {
                            nMainID = 1101;
                            String cfg = "";
                            cfg += nMainID + "==##";
                            cfg += "END";
                            try {
                                cardCfg.StringBufferDemo(cfg);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } else if (which == 18) {
                            nMainID = 1003;
                        } else if (which == 19) {
                            nMainID = 1004;
                        } else {
                            nMainID = which + 1;
                        }
                    }
                });
        dialog.show();
    }

    public AlertDialog.Builder createAlertDialog(String title, String message) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(title);
        dialog.setMessage(message);
        dialog.create();
        return dialog;
    }

    protected void writePreferences(String perferencesName, String key,
            String value) {
        SharedPreferences preferences = getSharedPreferences(perferencesName,
                MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public void takePicture() {
        if (camera != null) {
            try {
                // 自动对焦
                camera.autoFocus(new AutoFocusCallback() {
                    public void onAutoFocus(boolean success, Camera camera) {
                        if (null != listener) {
                            listener.onAutoFocus(success);
                        }
                        // 自动对焦成功后才拍摄
                        if (success) {
                            try {

                                camera.takePicture(shutterCallback, null,
                                        PictureCallback);
                            } catch (Exception e) {
                                e.printStackTrace();
                                camera.stopPreview();
                                camera.startPreview();
                                takepicbtn.setEnabled(true);
                            }

                        } else {

                            camera.takePicture(shutterCallback, null,
                                    PictureCallback);
                        }

                    }
                });
            } catch (Exception e) {
                camera.release();
                camera = null;
                takepicbtn.setEnabled(false);
                showDialog();
                Log.i(TAG, "exception:" + e.getMessage());

            }

        }
    }

    public void showDialog() {
        new AlertDialog.Builder(this).setTitle("证件识别")
                .setMessage("自动对焦失败，请重新拍摄")
                .setPositiveButton("确定", new OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        dialog.dismiss();
                    }
                }).create().show();
    };

    // 快门按下的时候onShutter()被回调拍照声音
    private ShutterCallback shutterCallback = new ShutterCallback() {
        public void onShutter() {
            if (tone == null)
                // 发出提示用户的声音
                tone = new ToneGenerator(1,// AudioManager.AUDIOFOCUS_REQUEST_GRANTED
                        ToneGenerator.MIN_VOLUME);
            tone.startTone(ToneGenerator.TONE_PROP_BEEP);
        }
    };

    /* 拍照后回显 */
    private PictureCallback PictureCallback = new PictureCallback() {
        public void onPictureTaken(byte[] data, Camera camera) {
            Log.i(TAG, "onPictureTaken");
            BitmapFactory.Options opts = new BitmapFactory.Options();
            // 设置成了true,不占用内存，只获取bitmap宽高
            opts.inJustDecodeBounds = true;
            // 根据内存大小设置采样率
            // 需要测试！
            int SampleSize = computeSampleSize(opts, -1, 2048 * 1536);
            opts.inSampleSize = SampleSize;
            opts.inJustDecodeBounds = false;

            bm = BitmapFactory.decodeByteArray(data, 0, data.length, opts);
            if (srcwidth == 2048 && srcheight == 1536) {
                Matrix matrix = new Matrix();
                matrix.postScale(0.625f, 0.625f);
                bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(),
                        bm.getHeight(), matrix, true);
            }
            if (srcwidth == 1600 && srcheight == 1200) {
                Matrix matrix = new Matrix();
                matrix.postScale(0.8f, 0.8f);
                bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(),
                        bm.getHeight(), matrix, true);
            }
            imagedata = data;
            /* 创建文件 */
            File dir = new File(PATH);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            File myCaptureFile = new File(strCaptureFilePath);
            try {
                BufferedOutputStream bos = new BufferedOutputStream(
                        new FileOutputStream(myCaptureFile));
                /* 采用压缩转档方法 */
                bm.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                /* 调用flush()方法，更新BufferStream */
                bos.flush();
                /* 结束OutputStream */
                bos.close();
                // 隐藏焦点图片和行驶证外框
                imagexingshizheng.setVisibility(View.GONE);
                // hepx 131215
                // view.setVisibility(View.GONE);

//                int relalayoutwidth = (int) (dm.widthPixels - ((surfaceView
//                        .getHeight() * 4) / 3));
//                RelativeLayout.LayoutParams lP = new RelativeLayout.LayoutParams(
//                        relalayoutwidth, dm.heightPixels);
//                lP.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,
//                        RelativeLayout.TRUE);
//                lP.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
//                rlyaout.setLayoutParams(lP);
                /* 将拍照下来且保存完毕的图文件，显示出来 */
                //BimageView.setImageBitmap(bm);
                takepicbtn.setVisibility(View.GONE);
                backbtn.setVisibility(View.GONE);
                resetbtn.setVisibility(View.VISIBLE);
                confirmbtn.setVisibility(View.VISIBLE);
                confirmbtn.setEnabled(true);
                /* 显示完图片，并关闭预览 */
                camera.stopPreview();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    };

    /* 保存图片并送识别 */
    private void savephoto(String SavePath) {
        Log.i(TAG, "savephoto");
        // 创建图像
        File file = new File(SavePath);
        Bitmap bitmap = BitmapFactory.decodeByteArray(imagedata, 0,
                imagedata.length);
        Bitmap bmp = Bitmap.createScaledBitmap(bitmap, 1280, 960, true);
        BufferedOutputStream bos = null;
        try {
            bos = new BufferedOutputStream(new FileOutputStream(file));
            bmp.compress(Bitmap.CompressFormat.JPEG, quality, bos);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                bos.flush();
                bos.close();
                if (null != bmp) {
                    bmp.recycle();
                    bmp = null;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        // 系统时间
        long datetime = System.currentTimeMillis();
        // 图像名称
        Date date = new Date();
        String name = file.getName();
        picpathString = name;
        Log.i(TAG, "name=" + name);
        Log.i(TAG, "picpathString1=" + picpathString);
        // 存储图像（PATH目录）
        // Uri uri = insertImage(getContentResolver(), name, datetime,
        // file.getParent(), name,
        // bm, imagedata);//bm bitmap
        // 裁切
        if (1100 == nMainID || 1101 == nMainID) {
            // if(srcwidth==1280||srcwidth==960){
            // cutwidth = 750;
            // cutheight = 130;
            // }
            // if(srcwidth==2048||srcwidth==1536){
            // cutwidth = 1300;
            // cutheight = 200;
            // }
            cutwidth = 750;
            cutheight = 130;
            CutPhoto cutPhoto = new CutPhoto(CameraRecogIDCard.this, cutwidth,
                    cutheight);
            path = cutPhoto.getCutPhotoPath(bm, name.replace(".jpg", "_cut"),
                    file.getParent() + "/");
            Log.i(TAG, "save path=" + path);
        } else {
            path = file.getParent() + "/" + name;
            Log.i(TAG, "save path=" + path);
        }
        if (bm != null) {
            bm.recycle();
            bm = null;
        }
    }

    // 存储图像并将信息添加入媒体数据库
    private Uri insertImage(ContentResolver cr, String name, long dateTaken,
            String directory, String filename, Bitmap source, byte[] jpegData) {
        OutputStream outputStream = null;
        String filePath = directory + filename;
        try {
            File dir = new File(directory);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            File file = new File(directory, filename);
            if (file.createNewFile()) {
                System.out.println("save");
                outputStream = new FileOutputStream(file);
                if (source != null) {
                    source.compress(CompressFormat.JPEG, 100, outputStream);
                } else {
                    outputStream.write(jpegData);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (Throwable t) {
                }
            }
        }
        ContentValues values = new ContentValues(7);
        values.put(MediaStore.Images.Media.TITLE, name);
        values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Images.Media.DATE_TAKEN, dateTaken);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.DATA, filePath);
        return cr.insert(IMAGE_URI, values);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // TODO Auto-generated method stub

        Log.i(TAG, "surfaceCreated");
        // 获得Camera对象
        takepicbtn.setEnabled(true);
        if (null == camera) {
            camera = Camera.open();
        }

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
            int height) {
        // TODO Auto-generated method stub

        Log.i(TAG, "surfaceChanged");
        Log.i(TAG, "holder=" + holder);
        if (camera != null) {
            initCamera(holder);

        }

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
        }

    }

    // 设置监听事件
    public void setOnCameraStatusListener(OnCameraStatusListener listener) {
        this.listener = listener;
    }

    // 相机拍照监听接口
    public interface OnCameraStatusListener {
        // 相机拍照结束事件
        void onCameraStopped(byte[] data);

        // 拍摄时自动对焦事件
        void onAutoFocus(boolean success);
    }

    public void onAutoFocus(boolean success) {
        // 改变对焦状态图像
        if (success) {

        } else {

            isTaking = false;
        }
    }

    /* 相机重置 */
    private void resetCamera() {
        if (camera != null) {
            camera.stopPreview();
            camera.startPreview();
        }
    }

    public static int computeSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        int initialSize = computeInitialSampleSize(options, minSideLength,
                maxNumOfPixels);
        int roundedSize;
        if (initialSize <= 8) {
            roundedSize = 1;
            while (roundedSize < initialSize) {
                roundedSize <<= 1;
            }
        } else {
            roundedSize = (initialSize + 7) / 8 * 8;
        }
        return roundedSize;
    }

    private static int computeInitialSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        double w = options.outWidth;
        double h = options.outHeight;
        int lowerBound = (maxNumOfPixels == -1) ? 1 : (int) Math.ceil(Math
                .sqrt(w * h / maxNumOfPixels));
        int upperBound = (minSideLength == -1) ? 128 : (int) Math.min(
                Math.floor(w / minSideLength), Math.floor(h / minSideLength));
        if (upperBound < lowerBound) {
            return lowerBound;
        }
        if ((maxNumOfPixels == -1) && (minSideLength == -1)) {
            return 1;
        } else if (minSideLength == -1) {
            return lowerBound;
        } else {
            return upperBound;
        }
    }

    public void displayResult() {
        Log.i(TAG, "displayResult");
        if (lpFileName != null && !lpFileName.equals("")) {
            try {
                // String logopath = "";
                // String logopath = getSDPath() + "/photo_logo.png";
                Intent intent = new Intent("wintone.idcard");
                Bundle bundle = new Bundle();
                // int nSubID[] = null;//{0x0001};
                // bundle.putString("cls", "checkauto.com.IdcardRunner");
                bundle.putInt("nTypeInitIDCard", nTypeInitIDCard); // 保留，传0即可
                Log.i(TAG, "displayResult lpFileName=" + path);
                bundle.putString("lpFileName", path);// 指定的图像路径
                bundle.putInt("nTypeLoadImageToMemory", nTypeLoadImageToMemory);// 0不确定是哪种图像，1可见光图，2红外光图，4紫外光图
                bundle.putInt("nMainID", nMainID); // 证件的主类型。6是行驶证，2是二代证，这里只可以传一种证件主类型。每种证件都有一个唯一的ID号，可取值见证件主类型说明
                bundle.putIntArray("nSubID", nSubID); // 保存要识别的证件的子ID，每个证件下面包含的子类型见证件子类型说明。nSubID[0]=null，表示设置主类型为nMainID的所有证件。
                bundle.putBoolean("GetSubID", GetSubID); // GetSubID得到识别图像的子类型id
                bundle.putString("lpHeadFileName", lpHeadFileName);// 保存路径名，后缀只能为jpg、bmp、tif
                bundle.putBoolean("GetVersionInfo", GetVersionInfo); // 获取开发包的版本信息
                // 读设置到文件里的sn
                File file = new File(PATH);
                String snString = null;
                if (file.exists()) {
                    String filePATH = PATH + "/idcard.sn";
                    File newFile = new File(filePATH);
                    if (newFile.exists()) {
                        BufferedReader bfReader = new BufferedReader(
                                new FileReader(newFile));
                        snString = bfReader.readLine().toUpperCase();
                        bfReader.close();
                    } else {
                        bundle.putString("sn", sn);
                    }
                    if (snString != null && !snString.equals("")) {
                        bundle.putString("sn", snString);
                    } else {
                        bundle.putString("sn", sn);
                    }
                } else {
                    bundle.putString("sn", sn);
                }

                // bundle.putString("sn", sn);
                // //序列号激活方式,XS4XAYRWEFRY248YY4LHYY178已使用
                bundle.putString("server", server);
                if (authfile != null && !authfile.equals("")
                        && authfile.equals("guangda")) {
                    if (deviceId == null || deviceId.equals("")
                            || deviceId.equals("null")) {
                        authfile = getExtPath() + "/wintone/" + androId
                                + "_zj.txt";
                    } else {
                        authfile = getExtPath() + "/wintone/" + deviceId
                                + "_zj.txt";
                    }
                    bundle.putString("authfile", authfile);
                } else {
                    bundle.putString("authfile", authfile);
                }
                // 文件激活方式
                // String logopath = "";
                bundle.putString("logo", logo); // logo路径，logo显示在识别等待页面右上角
                bundle.putBoolean("isCut", cut); // 如不设置此项默认自动裁切
                bundle.putString("devcode", devcode);
                bundle.putString("datefile", datefile);
                bundle.putString("returntype", "withvalue");// 返回值传递方式withvalue带参数的传值方式（新传值方式）
                intent.putExtras(bundle);
                startActivityForResult(intent, 9);
                overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(),
                        "没有找到应用程序" + "wintone.idcard", 0).show();
            }
        } else {
            Toast.makeText(getApplicationContext(), "图片路径为空！",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public static List<String> getStoragePath() {
        List<String> mounts = new ArrayList<String>();
        try {
            Runtime runtime = Runtime.getRuntime();
            Process proc = runtime.exec("mount");
            InputStream is = proc.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            String line;
            BufferedReader br = new BufferedReader(isr);
            while ((line = br.readLine()) != null) {
                if (line.contains("secure"))
                    continue;
                if (line.contains("asec"))
                    continue;

                if (line.contains("fat")) {
                    String columns[] = line.split(" ");
                    if (columns != null && columns.length > 1) {
                        if (columns[1] != null && !columns[1].equals("")) {
                            mounts.add(columns[1]);
                        }
                    }
                } else if (line.contains("fuse")) {
                    String columns[] = line.split(" ");
                    if (columns != null && columns.length > 1) {
                        if (columns[1] != null && !columns[1].equals("")) {
                            mounts.add(columns[1]);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mounts;
    }

    // 获取外置存储卡路径
    public static String getExtPath() {
        for (String path : getStoragePath()) {
            if (path.contains("ext")) {
                return path;
            }
        }
        return "";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.i(TAG, "onActivityResult");
        if (requestCode == 9 && resultCode == RESULT_OK) {
            // 读识别返回值
            // setContentView(R.layout.idcardrunner);
            int ReturnAuthority = data.getIntExtra("ReturnAuthority", -100000);// 取激活状态
            int ReturnInitIDCard = data
                    .getIntExtra("ReturnInitIDCard", -100000);// 取初始化返回值
            int ReturnLoadImageToMemory = data.getIntExtra(
                    "ReturnLoadImageToMemory", -100000);// 取读图像的返回值
            int ReturnRecogIDCard = data.getIntExtra("ReturnRecogIDCard",
                    -100000);// 取识别的返回值
            String[] fieldname = (String[]) data
                    .getSerializableExtra("GetFieldName");
            String[] fieldvalue = (String[]) data
                    .getSerializableExtra("GetRecogResult");
            Log.i(TAG, "识别返回");
            Log.i(TAG, "ReturnAuthority==" + ReturnAuthority);
            Log.i(TAG, "ReturnInitIDCard==" + ReturnInitIDCard);
            Log.i(TAG, "ReturnLoadImageToMemory==" + ReturnLoadImageToMemory);
            Log.i(TAG, "ReturnRecogIDCard==" + ReturnRecogIDCard);
            Log.i(TAG, "获取到识别结果");
            Log.i(TAG, fieldname[1] + ":" + fieldvalue[1]);
            Log.i(TAG, fieldname[2] + ":" + fieldvalue[2]);
            Log.i(TAG, fieldname[3] + ":" + fieldvalue[3]);
            Log.i(TAG, fieldname[4] + ":" + fieldvalue[4]);
            Log.i(TAG, fieldname[5] + ":" + fieldvalue[5]);
            // Intent intent = new Intent();
            Intent intent = new Intent("wintone.idcard");
            Bundle bundle = new Bundle();
            bundle.putStringArray("GetFieldName", fieldname);
            bundle.putStringArray("GetRecogResult", fieldvalue);
            bundle.putInt("ReturnAuthority", ReturnAuthority);
            bundle.putInt("ReturnInitIDCard", ReturnInitIDCard);
            bundle.putInt("ReturnLoadImageToMemory", ReturnLoadImageToMemory);
            bundle.putInt("ReturnRecogIDCard", ReturnRecogIDCard);
            intent.putExtras(bundle);
            // hepx 131215
            setResult(Activity.RESULT_OK, intent);
            // startActivity(intent);
            CameraRecogIDCard.this.finish();
        }

    }

    private ArrayList<Size> splitSize(String str, Camera camera) {
        if (str == null)
            return null;
        StringTokenizer tokenizer = new StringTokenizer(str, ",");
        ArrayList<Size> sizeList = new ArrayList<Size>();
        while (tokenizer.hasMoreElements()) {
            Size size = strToSize(tokenizer.nextToken(), camera);
            if (size != null)
                sizeList.add(size);
        }
        if (sizeList.size() == 0)
            return null;
        return sizeList;
    }

    private Size strToSize(String str, Camera camera) {
        if (str == null)
            return null;
        int pos = str.indexOf('x');
        if (pos != -1) {
            String width = str.substring(0, pos);
            String height = str.substring(pos + 1);
            return camera.new Size(Integer.parseInt(width),
                    Integer.parseInt(height));
        }
        return null;
    }

    private int getMainId() {
        if (nMainID == 0) {
            String cfg = "";
            try {
                cfg = readtxt();
            } catch (Exception e) {
                e.printStackTrace();
            }
            String cfgs[] = cfg.split("==##");
            if (cfgs != null && cfgs.length >= 2) {
                if (null != cfgs[0] && !cfgs[0].equals("")) {
                    nMainID = Integer.parseInt(cfgs[0]);
                }
            }
        }
        if (nMainID == 0) {
            nMainID = 2;
        }
        return nMainID;
    }

    private void initCamera(SurfaceHolder holder) {
        Camera.Parameters parameters = camera.getParameters();
        List<Camera.Size> list = parameters.getSupportedPreviewSizes();
        Camera.Size size;
        int length = list.size();
        int previewWidth = 640;
        int previewheight = 480;
        int second_previewWidth = 0;
        int second_previewheight = 0;
        if (length == 1) {
            size = list.get(0);
            previewWidth = size.width;
            previewheight = size.height;
        } else {
            for (int i = 0; i < length; i++) {
                size = list.get(i);
                if (size.height <= 960 || size.width <= 1280) {
                    second_previewWidth = size.width;
                    second_previewheight = size.height;
                    if (previewWidth < second_previewWidth) {
                        previewWidth = second_previewWidth;
                        previewheight = second_previewheight;
                    }
                }
            }
        }
        int preWidth = previewWidth;
        int preHeight = previewheight;

        parameters.setPictureFormat(PixelFormat.JPEG);
        parameters.setPreviewSize(preWidth, preHeight);
        // parameters.setFlashMode(Parameters.FLASH_MODE_TORCH); //闪光灯
        parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);// 1连续对焦
        // setDispaly(parameters,camera);
        parameters.setExposureCompensation(0);

        camera.setParameters(parameters);
        try {
            camera.setPreviewDisplay(holder);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        camera.startPreview();
        // camera.cancelAutoFocus();// 2如果要实现连续的自动对焦，这一句必须加上
    }

    public void displayPopuWindow(String message) {
        int relalayoutwidth = (int) (dm.widthPixels - ((dm.heightPixels * 4) / 3));
        int scWidth = this.getWindow().getWindowManager().getDefaultDisplay()
                .getWidth();
        int scHeight = this.getWindow().getWindowManager().getDefaultDisplay()
                .getHeight();
        int popuWidth = scWidth - relalayoutwidth;
        EditText et = new EditText(this);
        et.setWidth(scWidth);
        et.setHeight(popuWidth);
        PopupWindow popuWindow = new PopupWindow(et, popuWidth, 200, true);
        popuWindow.setWidth(popuWidth);
        popuWindow.setHeight(200);
        popuWindow.setContentView(et);
        ColorDrawable color = new ColorDrawable(Color.BLACK);
        color.setAlpha(60);
        popuWindow.setBackgroundDrawable(color);
        popuWindow.setOutsideTouchable(true);
        popuWindow.setFocusable(true);
        popuWindow.showAtLocation(surfaceView, Gravity.LEFT, 0, scHeight - 200);
        et.setText(message);
    }

}
