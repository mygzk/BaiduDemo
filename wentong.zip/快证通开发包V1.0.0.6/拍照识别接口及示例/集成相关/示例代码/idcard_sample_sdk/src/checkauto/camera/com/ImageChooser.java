package checkauto.camera.com;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import checkauto.photo.com.FileManageActivity;

import com.wintone.demo.idcard.R;
import wintone.idcard.android.AuthParameterMessage;
import wintone.idcard.android.AuthService;
import wintone.idcard.android.IDCardCfg;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Service;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.hardware.Camera.Size;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

//首页
public class ImageChooser extends Activity {
    public static final String PATH = Environment.getExternalStorageDirectory()
            .toString() + "/AndroidWT";
    public static final String TAG = "ImageChooser";
    private Button mbutsel, handTakePic, autoTakePic;
    // private Button mbutcap;
    private Button mbutquit;
    private Button mbutcfg, mbutCode;
    // private Button mbutCamera, mbutConfirm, mbutOffLine;
    private String selectPath;
    private String sn = "";
    private String[][] type1 = { { "一代身份證", "1" }, { "二代身份證正面", "2" },
            { "二代身份證背面", "3" }, { "臨時身份證", "4" }, { "駕照", "5" },
            { "行駛證", "6" }, { "軍官證", "7" }, { "士兵證", "8" }, { "港澳通行證", "9" },
            { "大陸通行證", "10" },{ "新版台胞證(正面)", "25" },{ "新版台胞證(背面)", "26" }, { "台灣通行證", "11" }, { "簽證", "12" },
            { "護照", "13" }, { "內地通行證正面", "14" }, { "內地通行證背面", "15" },
            { "戶口本", "16" }, { "車輛識別代號", "1100" }, { "廣東省居住證", "1000" },
            { "邊防證A", "1003" }, { "邊防證B", "1004" }, { "銀行卡", "1101" },
            { "香港永久性居民身份證", "1001" }, { "澳門身份證", "1005" }, { "護照機讀碼", "1020" },
            { "三行機讀碼(1033)", "1033" }, { "身份證號碼", "1102" },
            { "新版港澳通行證", "22" }, { "港澳通行證機讀碼", "1034" } };
    private String[][] type2 = { { "一代身份证", "1" }, { "二代身份证正面", "2" },
            { "二代身份证证背面", "3" }, { "临时身份证", "4" }, { "驾照", "5" },
            { "行驶证", "6" }, { "军官证", "7" }, { "士兵证", "8" }, { "港澳通行证", "9" },
            { "大陆通行证", "10" },{ "新版台胞证(正面)", "25" },{ "新版台胞证(背面)", "26" }, { "台湾通行证", "11" }, { "签证", "12" },
            { "护照", "13" }, { "内地通行证正面", "14" }, { "内地通行证背面", "15" },
            { "户口本", "16" }, { "车辆识别代号", "1100" }, { "广东省居住证", "1000" },
            { "边防证A", "1003" }, { "边防证B", "1004" }, { "银行卡", "1101" },
            { "香港永久性居民身份证", "1001" }, { "澳门身份证", "1005" }, { "护照机读码", "1020" },
            { "三行机读码(1033)", "1033" }, { "身份证号码", "1102" },
            { "新版港澳通行证", "22" }, { "港澳通行证机读码", "1034" } };
    private String[][] type3 = { { "MRZ(30*3)", "1033" },
            { "MRZ (44*2)", "1034" }, { "MRZ (36*2)", "1036" }
    /*
     * { "New Exit-Entry Permit to HK/Macau", "22" }, { "HK ID card", "1001" },
     * { "Macau ID card", "1005" }, { "Home Permit Card(Obverse)", "14" }
     */};
    private RelativeLayout llLayout;
    private EditText editText;
    private boolean isCatchPreview = false;
    private boolean isCatchPicture = false;
    private int srcwidth;
    private int srcheight;
    private int WIDTH;
    private int HEIGHT;
    int nMainID = 0;
    int[] nSubID;
    private String[] type;
    private String[] recogTypes = new String[2];
    public static int DIALOG_ID = -1;
    public boolean isVINRecog = false;
    public int recogType = -1;// 1代表自动识别，2代表划框识别，3代表划线识别
    private AlertDialog dialog;
    private AuthService.authBinder authBinder;
    private int ReturnAuthority = -1;
    private boolean isCopyFiles = true;
    private boolean international = false;
    public ServiceConnection authConn = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
            authBinder = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            authBinder = (AuthService.authBinder) service;
            try {

                AuthParameterMessage apm = new AuthParameterMessage();
                // apm.datefile = "";//预留
                 apm.devcode = "5YYX5LQS5PAH6YC";// 预留
                apm.sn = sn;// WU9H5VSSDVXYB6KYYI52YYICW
                            // WUB7RVSN1JVYHFBYY7P9YYC37
                            // apm.authfile = "";//
                            // /mnt/sdcard/auth/A1000038AB08A2_zj.txt
                ReturnAuthority = authBinder.getIDCardAuth(apm);
                TextView textView = (TextView) findViewById(R.id.meijihuoTextView);
                System.out.println("ReturnAuthority："+ReturnAuthority);
                if (ReturnAuthority != 0) {

                    // 刚开始程序会将相关文件复制进对应路径，点击在线激活时，就会报错误信息
                    if (!isCopyFiles) {
                        String exception = getString(R.string.exception1)
                                + ReturnAuthority;
                        Toast.makeText(getApplicationContext(), exception,
                                Toast.LENGTH_LONG).show();
                        isCopyFiles = true;
                    }
                    textView.setVisibility(View.VISIBLE);
                } else {
                    textView.setVisibility(View.INVISIBLE);
                    if (!isCopyFiles) {
                        Toast.makeText(getApplicationContext(),
                                R.string.toast_already_setting,
                                Toast.LENGTH_LONG).show();
                        isCopyFiles = true;
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(),
                        getString(R.string.license_verification_failed),
                        Toast.LENGTH_LONG).show();

            } finally {
                if (authBinder != null) {
                    unbindService(authConn);
                }
            }
        }

    };

    @Override
    protected void onStart() {
        super.onStart();
        // 如果是国际版就将自动拍照按钮隐藏 start
        try {
            String[] fileNames = this.getAssets().list("");
            // String[] filename = new String[fileNames.length];
            for (int i = 0; i < fileNames.length; i++) {
                if (fileNames[i].equals("English.txt")) {
                    autoTakePic.setVisibility(View.GONE);
                    international = true;
                    break;
                }
                ;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 如果是国际版就将自动拍照按钮隐藏 end
        recogTypes[0] = getString(R.string.AutoRecognition);
        recogTypes[1] = getString(R.string.LineRecognition);
        if (getResources().getConfiguration().locale.getLanguage().equals("zh")
                && getResources().getConfiguration().locale.getCountry()
                        .equals("CN") && !international) {
            type = new String[type2.length];

            for (int i = 0; i < type2.length; i++) {
                type[i] = type2[i][0];
            }
            // type = type2;
            mbutCode.setWidth(250);
            handTakePic.setWidth(250);
            autoTakePic.setWidth(250);
            mbutsel.setWidth(250);
            mbutquit.setWidth(250);
            mbutcfg.setWidth(250);
        } else if (getResources().getConfiguration().locale.getLanguage()
                .equals("zh")
                && getResources().getConfiguration().locale.getCountry()
                        .equals("TW") && !international) {
            // type = type1;
            type = new String[type1.length];

            for (int i = 0; i < type1.length; i++) {
                type[i] = type1[i][0];
            }
            mbutCode.setWidth(250);
            handTakePic.setWidth(250);
            autoTakePic.setWidth(250);
            mbutsel.setWidth(250);
            mbutquit.setWidth(250);
            mbutcfg.setWidth(250);
        } else if (getResources().getConfiguration().locale.getLanguage()
                .equals("en")
                && getResources().getConfiguration().locale.getCountry()
                        .equals("US") || international) {
            type = new String[type3.length];
            for (int i = 0; i < type3.length; i++) {
                type[i] = type3[i][0];

            }
            // type = type3;
            mbutCode.setWidth(400);
            handTakePic.setWidth(400);
            autoTakePic.setWidth(400);
            mbutsel.setWidth(400);
            mbutquit.setWidth(400);
            mbutcfg.setWidth(400);
        }
        if (nMainID == 0 && international)
            nMainID = 1033;
    }

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imagechooser);
        checkCameraParameters();
        nMainID = readMainID();

        llLayout = (RelativeLayout) findViewById(R.id.llayout);
        mbutCode = (Button) findViewById(R.id.butcode);
        handTakePic = (Button) findViewById(R.id.handTakePic);
        autoTakePic = (Button) findViewById(R.id.autoTakePic);
        mbutCode.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v) {
                DIALOG_ID = 1;
                View view = getLayoutInflater().inflate(R.layout.serialdialog,
                        null);
                editText = (EditText) view
                        .findViewById(R.id.serialdialogEdittext);
                dialog = new AlertDialog.Builder(ImageChooser.this)
                        .setView(view)
                        .setPositiveButton(
                                getString(R.string.online_activation),
                                new DialogInterface.OnClickListener() {

                                    public void onClick(DialogInterface dialog,
                                            int which) {
                                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                                        if (imm.isActive()) {
                                            imm.toggleSoftInput(
                                                    InputMethodManager.SHOW_IMPLICIT,
                                                    InputMethodManager.HIDE_NOT_ALWAYS);
                                        }
                                        String editsString = editText.getText()
                                                .toString().toUpperCase();
                                        createSnFile(editsString);
                                        try {// 读设置到文件里的sn
                                            File file = new File(PATH);
                                            if (file.exists()) {
                                                String filePATH = PATH
                                                        + "/IdCard.sn";
                                                File newFile = new File(
                                                        filePATH);
                                                if (newFile.exists()) {
                                                    BufferedReader bfReader;

                                                    bfReader = new BufferedReader(
                                                            new FileReader(
                                                                    newFile));
                                                    sn = bfReader.readLine()
                                                            .toUpperCase();

                                                    bfReader.close();

                                                }
                                            } else {
                                                sn = "";
                                            }
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                        isCopyFiles = false;
                                        startAuthService();
                                        dialog.dismiss();

                                    }

                                })
                        .setNegativeButton(
                                getString(R.string.offline_activation),
                                new DialogInterface.OnClickListener() {

                                    public void onClick(DialogInterface dialog,
                                            int which) {
                                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                                        if (imm.isActive()) {
                                            imm.toggleSoftInput(
                                                    InputMethodManager.SHOW_IMPLICIT,
                                                    InputMethodManager.HIDE_NOT_ALWAYS);
                                        }
                                        createDevFile();
                                        dialog.dismiss();
                                        AlertDialog.Builder dialogSend = createAlertDialog(
                                                getString(R.string.dialog_alert),
                                                getString(R.string.dialog_message_send_admin));
                                        dialogSend
                                                .setPositiveButton(
                                                        getString(R.string.confirm),
                                                        new DialogInterface.OnClickListener() {
                                                            @Override
                                                            public void onClick(
                                                                    DialogInterface dialog,
                                                                    int which) {
                                                                dialog.dismiss();
                                                            }
                                                        });
                                        dialogSend.show();

                                    }

                                }).create();
                dialog.show();
            }
        });

        // 拍摄识别
        // mbutcap = (Button) this.findViewById(R.id.butcap);
        autoTakePic.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v) {
                // writePreferences("Button", "Height", mbutcap.getHeight());
                Log.i(TAG, "isCatchPreview=" + isCatchPreview
                        + " isCatchPicture=" + isCatchPicture);
                // 如果刚开始不选择证件类型选项就会报-5异常，所以这里默认为1033
                nMainID = readMainID();
                if (nMainID == 0 && international)
                    nMainID = 1033;
                if (isCatchPreview == true && isCatchPicture == true) {
                    Intent intent = new Intent();
                    if (readMainID() != -1
                            && (1100 == nMainID || 1101 == nMainID)) {
                        AlertDialog.Builder recogTypeDialog = createAlertDialog(
                                getString(R.string.chooseRecogType), null);
                        recogTypeDialog.setSingleChoiceItems(recogTypes, -1,
                                dialogListener);
                        DIALOG_ID = 3;
                        recogTypeDialog.show();
                    } else {
                        // 如果为身份证号码识别和护照MRZ码识别就进入CameraIDCardNoActivity类型为1033为三行MRZ码
                        if (nMainID == 1020 || nMainID == 1102
                                || nMainID == 1033 || nMainID == 1034
                                || nMainID == 1036) {
                            intent.setClass(ImageChooser.this,
                                    CameraIDCardNoActivity.class);
                        } else {
                            intent.setClass(ImageChooser.this,
                                    CameraActivity.class);
                        }
                        Log.i(TAG, "拍摄分辨率为: " + srcwidth + " * " + srcheight);
                        Log.i(TAG, "预览分辨率为: " + WIDTH + " * " + HEIGHT);
                        writePreferences("", "WIDTH", WIDTH);
                        writePreferences("", "HEIGHT", HEIGHT);
                        writePreferences("", "srcwidth", srcwidth);
                        writePreferences("", "srcheight", srcheight);
                        writePreferences("", "isAutoTakePic", 1);
                        intent.putExtra("WIDTH", WIDTH);
                        intent.putExtra("HEIGHT", HEIGHT);
                        intent.putExtra("srcwidth", srcwidth);
                        intent.putExtra("srcheight", srcheight);
                        intent.putExtra("nMainID", nMainID);
                        ImageChooser.this.finish();
                        startActivity(intent);
                        overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                    }
                } else {
                    if (readMainID() != -1
                            && (1100 == nMainID || 1101 == nMainID)) {
                        AlertDialog.Builder recogTypeDialog = createAlertDialog(
                                getString(R.string.chooseRecogType), null);
                        recogTypeDialog.setSingleChoiceItems(recogTypes, 0,
                                dialogListener);
                        DIALOG_ID = 4;
                        recogTypeDialog.show();
                    } else {
                        String partpath = Environment
                                .getExternalStorageDirectory() + "/wtimage";
                        File dir = new File(partpath);
                        if (!dir.exists()) {
                            dir.mkdir();
                        }
                        Date date = new Date();
                        selectPath = partpath + "/idcard" + date.getTime()
                                + ".jpg";
                        Intent takePictureFromCameraIntent = new Intent(
                                MediaStore.ACTION_IMAGE_CAPTURE);
                        takePictureFromCameraIntent.putExtra(
                                android.provider.MediaStore.EXTRA_OUTPUT,
                                Uri.fromFile(new File(selectPath)));
                        startActivityForResult(takePictureFromCameraIntent, 1);
                        overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                    }
                }
            }
        });
        handTakePic.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v) {
                // writePreferences("Button", "Height", mbutcap.getHeight());
                Log.i(TAG, "isCatchPreview=" + isCatchPreview
                        + " isCatchPicture=" + isCatchPicture);
                // 如果刚开始不选择证件类型选项就会报-5异常，所以这里默认为1033
                nMainID = readMainID();
                if (nMainID == 0 && international)
                    nMainID = 1033;
                System.out.println("isCatchPreview"+isCatchPreview+"    isCatchPicture"+isCatchPicture);
                if (isCatchPreview == true && isCatchPicture == true) {
                    Intent intent = new Intent();
                    if (readMainID() != -1
                            && (1100 == nMainID || 1101 == nMainID)) {
                        AlertDialog.Builder recogTypeDialog = createAlertDialog(
                                getString(R.string.chooseRecogType), null);
                        recogTypeDialog.setSingleChoiceItems(recogTypes, -1,
                                dialogListener);
                        DIALOG_ID = 3;
                        recogTypeDialog.show();
                    } else {
                        // 如果为身份证号码识别和护照MRZ码识别就进入CameraIDCardNoActivity类型为1033为三行MRZ码
                        if (nMainID == 1020 || nMainID == 1102
                                || nMainID == 1033 || nMainID == 1034
                                || nMainID == 1036) {
                            intent.setClass(ImageChooser.this,
                                    CameraIDCardNoActivity.class);
                        } else {
                            intent.setClass(ImageChooser.this,
                                    CameraActivity.class);
                        }
                        Log.i(TAG, "拍摄分辨率为: " + srcwidth + " * " + srcheight);
                        Log.i(TAG, "预览分辨率为: " + WIDTH + " * " + HEIGHT);
                        writePreferences("", "WIDTH", WIDTH);
                        writePreferences("", "HEIGHT", HEIGHT);
                        writePreferences("", "srcwidth", srcwidth);
                        writePreferences("", "srcheight", srcheight);
                        writePreferences("", "isAutoTakePic", 0);
                        intent.putExtra("WIDTH", WIDTH);
                        intent.putExtra("HEIGHT", HEIGHT);
                        intent.putExtra("srcwidth", srcwidth);
                        intent.putExtra("srcheight", srcheight);
                        intent.putExtra("nMainID", nMainID);
                        ImageChooser.this.finish();
                        startActivity(intent);
                        overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                    }
                } else {
                    if (readMainID() != -1
                            && (1100 == nMainID || 1101 == nMainID)) {
                        AlertDialog.Builder recogTypeDialog = createAlertDialog(
                                getString(R.string.chooseRecogType), null);
                        recogTypeDialog.setSingleChoiceItems(recogTypes, 0,
                                dialogListener);
                        DIALOG_ID = 4;
                        recogTypeDialog.show();
                    } else {
                        String partpath = Environment
                                .getExternalStorageDirectory() + "/wtimage";
                        File dir = new File(partpath);
                        if (!dir.exists()) {
                            dir.mkdir();
                        }
                        Date date = new Date();
                        selectPath = partpath + "/idcard" + date.getTime()
                                + ".jpg";
                        Intent takePictureFromCameraIntent = new Intent(
                                MediaStore.ACTION_IMAGE_CAPTURE);
                        takePictureFromCameraIntent.putExtra(
                                android.provider.MediaStore.EXTRA_OUTPUT,
                                Uri.fromFile(new File(selectPath)));
                        startActivityForResult(takePictureFromCameraIntent, 1);
                        overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                    }
                }
            }
        });

        // mbutCamera = (Button) findViewById(R.id.butcamera);
        // mbutCamera.setOnClickListener(new Button.OnClickListener() {
        //
        // @Override
        // public void onClick(View v) {
        //
        // String partpath = Environment.getExternalStorageDirectory() +
        // "/wintoneimage";
        // File dir = new File(partpath);
        // if (!dir.exists()) {
        // dir.mkdir();
        // }
        // Date date = new Date();
        // selectPath = partpath + "/idcard" + date.getTime() + ".jpg";
        // Intent takePictureFromCameraIntent = new
        // Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // takePictureFromCameraIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
        // Uri.fromFile(new File(selectPath)));
        // startActivityForResult(takePictureFromCameraIntent, 1);
        // }
        // });

        // 选择文件
        mbutsel = (Button) this.findViewById(R.id.butlog);
        mbutsel.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v) {
                // 如果刚开始不选择证件类型选项就会报-5异常，所以这里默认为1033
                nMainID = readMainID();
                if (nMainID == 0 && international)
                    nMainID = 1033;
                if (readMainID() != -1 && (1100 == nMainID || 1101 == nMainID)) {
                    String[] recogTypes = new String[1];
                    recogTypes[0] = getString(R.string.LineRecognition);

                    AlertDialog.Builder recogTypeDialog = createAlertDialog(
                            getString(R.string.chooseRecogType), null);
                    recogTypeDialog.setSingleChoiceItems(recogTypes, -1,
                            dialogListener);
                    DIALOG_ID = 5;
                    recogTypeDialog.show();
                } else {
                    // Intent innerIntentX = new
                    // Intent(Intent.ACTION_GET_CONTENT);
                    // innerIntentX.addCategory(Intent.CATEGORY_OPENABLE);
                    // innerIntentX.setType("image/*");
                    // Intent wrapperIntentX =
                    // Intent.createChooser(innerIntentX,
                    // "Select Picture");
                    // startActivityForResult(wrapperIntentX, 9);
                    // overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                    Intent intent = new Intent();
                    intent.putExtra("title", getString(R.string.fileManage));
                    intent.setDataAndType(Uri.fromFile(new File(Environment
                            .getExternalStorageDirectory().toString())),
                            "image/*");

                    intent.setClass(ImageChooser.this, FileManageActivity.class);
                    // ImageChooser.this.finish();
                    startActivityForResult(intent, 9);
                }

            }
        });

        Button buttonService = (Button) findViewById(R.id.butservice);
        buttonService.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),
                        IDCardServiceActivity.class);
                startActivity(intent);
                ImageChooser.this.finish();

            }
        });

        mbutquit = (Button) this.findViewById(R.id.butlog3);
        mbutquit.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v) {

                android.os.Process.killProcess(android.os.Process.myPid());
                // overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
            }
        });

        // Button mbutvideo = (Button) findViewById(R.id.butvideocamera);
        // mbutvideo.setOnClickListener(new OnClickListener() {
        //
        // public void onClick(View v) {
        // Intent intent = new Intent();
        // intent.setClass(ImageChooser.this, VideoCameraActivity.class);
        // intent.putExtra("preWidth", WIDTH);
        // intent.putExtra("preHeight", HEIGHT);
        // intent.putExtra("picWidth", srcwidth);
        // intent.putExtra("picHeight", srcheight);
        // startActivity(intent);
        //
        // }
        // });

        // Button holderCamera = (Button) findViewById(R.id.holdercamera);
        // holderCamera.setOnClickListener(new OnClickListener() {
        // public void onClick(View v) {
        // Intent intent = new Intent();
        // intent.setClass(ImageChooser.this, CameraHolderActivity.class);
        //
        // writePreferences("HolderCamera", "preWidth", WIDTH);
        // writePreferences("HolderCamera", "preHeight", HEIGHT);
        // writePreferences("HolderCamera", "picWidth", srcwidth);
        // writePreferences("HolderCamera", "picHeight", srcheight);
        // startActivity(intent);
        // ImageChooser.this.finish();
        // }
        // });
        // 已有配置文件时读
        IDCardCfg cardCfg = new IDCardCfg();
        String cfg = "";
        try {
            cfg = cardCfg.readtxt();
        } catch (Exception e) {
            e.printStackTrace();
        }
        String cfgs[] = cfg.split("==##");
        Log.i(TAG, "cfg=" + cfg);
        if (cfgs != null && cfgs.length >= 2) {
            nMainID = Integer.valueOf(cfgs[0]);// cardCfg.String2Int(cfgs[0]);
        }
        // 配置
        mbutcfg = (Button) this.findViewById(R.id.butcfg);
        mbutcfg.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                dialog();
            }
        });
    }

    protected void onResume() {
        super.onResume();
        startAuthService();
    }

    private void startAuthService() {
        Intent authIntent = new Intent(ImageChooser.this, AuthService.class);
        bindService(authIntent, authConn, Service.BIND_AUTO_CREATE);
    }

    protected void writePreferences(String perferencesName, String key,
            int value) {
        SharedPreferences preferences = getSharedPreferences(perferencesName,
                MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public void checkCameraParameters() {
        // 读取支持的预览尺寸
        Camera camera = null;
        try {
            camera = Camera.open();
            if (camera != null) {
                // 读取支持的预览尺寸,优先选择640后320
                Camera.Parameters parameters = camera.getParameters();
                List<Integer> SupportedPreviewFormats = parameters
                        .getSupportedPreviewFormats();
                for (int i = 0; i < SupportedPreviewFormats.size(); i++) {
                    System.out.println("PreviewFormats="
                            + SupportedPreviewFormats.get(i));
                }
                Log.i(TAG,
                        "preview-size-values:"
                                + parameters.get("preview-size-values"));
                List<Camera.Size> previewSizes = splitSize(
                        parameters.get("preview-size-values"), camera);// parameters.getSupportedPreviewSizes();

                // 冒泡排序算法 实现分辨率从小到大排列
                // 该算法以分辨率的宽度为准，如果宽度相等，则判断高度
                int tempWidth = 0;
                int tempHeight = 0;
                for (int i = 0; i < previewSizes.size(); i++) {
                    for (int j = i + 1; j < previewSizes.size(); j++) {
                        if (previewSizes.get(i).width > previewSizes.get(j).width) {

                            tempWidth = previewSizes.get(i).width;
                            tempHeight = previewSizes.get(i).height;
                            previewSizes.get(i).width = previewSizes.get(j).width;
                            previewSizes.get(i).height = previewSizes.get(j).height;
                            previewSizes.get(j).width = tempWidth;
                            previewSizes.get(j).height = tempHeight;

                        } else if (previewSizes.get(i).width == previewSizes
                                .get(j).width
                                && previewSizes.get(i).height > previewSizes
                                        .get(j).height) {
                            tempWidth = previewSizes.get(i).width;
                            tempHeight = previewSizes.get(i).height;
                            previewSizes.get(i).width = previewSizes.get(j).width;
                            previewSizes.get(i).height = previewSizes.get(j).height;
                            previewSizes.get(j).width = tempWidth;
                            previewSizes.get(j).height = tempHeight;
                        }
                    }
                }
                for (int i = 0; i < previewSizes.size(); i++) {
                    System.out.println("宽度:" + previewSizes.get(i).width + "--"
                            + "高度:" + previewSizes.get(i).height);
                }
                // 冒泡排序算法
                // 该段程序主要目的是为了遵循:优先选择比640*480大的并且是最接近的而且是比例为4:3的原则编写的。
                for (int i = 0; i < previewSizes.size(); i++) {
                    // 当预览宽度和高度分别大于640和480并且宽和高的比为4:3时。
                    if (previewSizes.get(i).width > 640
                            && previewSizes.get(i).height > 480
                            && (((float) previewSizes.get(i).width / previewSizes
                                    .get(i).height) == (float) 4 / 3)) {
                        isCatchPreview = true;
                        WIDTH = previewSizes.get(i).width;
                        HEIGHT = previewSizes.get(i).height;
                        break;
                    }
                    // 如果在640*480前没有满足的值，WIDTH和HEIGHT就都为0，然后进行如下判断，看是否有640*480，如果有则赋值，如果没有则进行下一步验证。
                    if (previewSizes.get(i).width == 640
                            && previewSizes.get(i).height == 480 && WIDTH < 640
                            && HEIGHT < 480) {
                        isCatchPreview = true;
                        WIDTH = 640;
                        HEIGHT = 480;
                    }
                    if (previewSizes.get(i).width == 320
                            && previewSizes.get(i).height == 240 && WIDTH < 320
                            && HEIGHT < 240) {// 640 //480
                        isCatchPreview = true;
                        WIDTH = 320;
                        HEIGHT = 240;
                    }
                }
                Log.i(TAG, "isCatchPreview=" + isCatchPreview);

                // 读取支持的相机尺寸,优先选择1280后1600后2048
                List<Integer> SupportedPictureFormats = parameters
                        .getSupportedPictureFormats();
                for (int i = 0; i < SupportedPictureFormats.size(); i++) {
                    System.out.println("PictureFormats="
                            + SupportedPictureFormats.get(i));
                }
                Log.i(TAG,
                        "picture-size-values:"
                                + parameters.get("picture-size-values"));
                List<Camera.Size> PictureSizes = splitSize(
                        parameters.get("picture-size-values"), camera);// parameters.getSupportedPictureSizes();
                for (int i = 0; i < PictureSizes.size(); i++) {
//                    if (PictureSizes.get(i).width == 3264
//                            && PictureSizes.get(i).height == 1840) {
//                        // 优先选择小的照片分辨率
//                        isCatchPicture = true;
//                        srcwidth = 3264;
//                        srcheight = 1840;
//
//                    }
                    if (PictureSizes.get(i).width == 2048
                            && PictureSizes.get(i).height == 1536) {
                        // 优先选择小的照片分辨率
                        if ((srcwidth == 0 && srcheight == 0)
                                || (srcwidth > 2048 && srcheight > 1536)) {
                            isCatchPicture = true;
                            srcwidth = 2048;
                            srcheight = 1536;
                        }

                    }
                    if (PictureSizes.get(i).width == 1600
                            && PictureSizes.get(i).height == 1200) {
                        if ((srcwidth == 0 && srcheight == 0)
                                || (srcwidth > 1600 && srcheight > 1200)) {
                            isCatchPicture = true;
                            srcwidth = 1600;
                            srcheight = 1200;
                        }

                    }
                    if (PictureSizes.get(i).width == 1280
                            && PictureSizes.get(i).height == 960) {
                        if ((srcwidth == 0 && srcheight == 0)
                                || (srcwidth > 1280 && srcheight > 960)) {
                            isCatchPicture = true;
                            srcwidth = 1280;
                            srcheight = 960;
                        }
                    }
                    if (PictureSizes.get(i).width == 640
                            && PictureSizes.get(i).height == 480) {
                        if ((srcwidth == 0 && srcheight == 0)
                                || (srcwidth > 640 && srcheight > 480)) {
                            isCatchPicture = true;
                            srcwidth = 640;
                            srcheight = 480;
                        }
                    }
                }
                Log.i(TAG, "isCatchPicture=" + isCatchPicture);
            }
            camera.release();
            camera = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (camera != null) {
                try {
                    camera.release();
                    camera = null;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public int readMainID() {
        int mainID = 0;
        String cfgPath = Environment.getExternalStorageDirectory().toString()
                + "/AndroidWT/idcard.cfg";
        File cfgFile = new File(cfgPath);
        char[] buf = new char[14];
        if (!cfgFile.exists()) {
            return 0;
        } else {
            try {
                FileReader fr = new FileReader(cfgFile);
                fr.read(buf);
                String str = String.valueOf(buf);
                String[] splits = str.split("==##");
                mainID = Integer.valueOf(splits[0]);
                Log.i(TAG, "readMainID mainID=" + mainID);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return mainID;
    }

    public AlertDialog.Builder createAlertDialog(String title, String message) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(title);
        dialog.setMessage(message);
        dialog.create();
        return dialog;
    }

    public void createDevFile() {
        String sdDir = null;
        boolean sdCardExist = Environment.getExternalStorageState().equals(
                android.os.Environment.MEDIA_MOUNTED); // 判断sd卡是否存在
        if (sdCardExist) {
            File file = new File(PATH);
            if (!file.exists()) {
                file.mkdir();
            }
            sdDir = PATH + "/idcard.dev";
            String deviceId;
            String androId;
            TelephonyManager telephonyManager;
            telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            StringBuilder sb = new StringBuilder();
            sb.append(telephonyManager.getDeviceId());
            deviceId = sb.toString();// 由15位数字组成
            StringBuilder sb1 = new StringBuilder();
            sb1.append(Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ANDROID_ID));
            androId = sb1.toString();
            File newFile = new File(sdDir);
            String idString = deviceId + ";" + androId;
            try {
                newFile.delete();
                newFile.createNewFile();
                FileOutputStream fos = new FileOutputStream(newFile);
                StringBuffer sBuffer = new StringBuffer();
                sBuffer.append(idString);
                fos.write(sBuffer.toString().getBytes());
                fos.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void createSnFile(String editsString) {
        if (editsString != null && !editsString.equals("")) {
            File file = new File(PATH);
            if (!file.exists()) {
                file.mkdir();
            }
            String filePATH = PATH + "/idcard.sn";
            File newFile = new File(filePATH);
            try {
                newFile.delete();
                newFile.createNewFile();
                FileOutputStream fos = new FileOutputStream(newFile);
                StringBuffer sBuffer = new StringBuffer();
                sBuffer.append(editsString);
                fos.write(sBuffer.toString().toUpperCase().getBytes());
                fos.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public DialogInterface.OnClickListener dialogListener = new DialogInterface.OnClickListener() {

        @Override
        public void onClick(DialogInterface dialog, int which) {
            Log.i(TAG, " DIALOG_ID=" + DIALOG_ID + " which=" + which);
            switch (DIALOG_ID) {
            case 1:
                Log.i(TAG, "which=" + which);
                if (dialog.BUTTON_POSITIVE == which) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm.isActive()) {
                        imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT,
                                InputMethodManager.HIDE_NOT_ALWAYS);
                    }
                    String editsString = editText.getText().toString()
                            .toUpperCase();
                    createSnFile(editsString);

                    Toast.makeText(getApplicationContext(),
                            R.string.toast_already_setting, Toast.LENGTH_LONG)
                            .show();
                    dialog.dismiss();
                } else if (dialog.BUTTON_NEGATIVE == which) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm.isActive()) {
                        imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT,
                                InputMethodManager.HIDE_NOT_ALWAYS);
                    }
                    createDevFile();
                    dialog.dismiss();
                    AlertDialog.Builder dialogSend = createAlertDialog(
                            getString(R.string.dialog_alert),
                            getString(R.string.dialog_message_send_admin));
                    dialogSend.setPositiveButton(getString(R.string.confirm),
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog,
                                        int which) {
                                    dialog.dismiss();
                                }
                            });
                    dialogSend.show();
                }
                break;
            case 2:
                if (dialog.BUTTON_POSITIVE == which) {
                    String cfg = "";
                    cfg += nMainID + "==##";
                    cfg += "END";
                    IDCardCfg cardCfg = new IDCardCfg();
                    try {
                        cardCfg.StringBufferDemo(cfg);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    cfg = "";
                    dialog.dismiss();
                } else if (dialog.BUTTON_NEGATIVE == which) {
                    dialog.dismiss();
                }
                break;
            case 3:
                Intent intent = new Intent();
                intent.setClass(ImageChooser.this, CameraActivity.class);
                if (which == 0) {
                    recogType = 1;
                } else {
                    recogType = 3;
                }
                Log.i(TAG, "拍摄分辨率为: " + srcwidth + " * " + srcheight);
                Log.i(TAG, "预览分辨率为: " + WIDTH + " * " + HEIGHT);
                intent.putExtra("srcwidth", srcwidth);
                intent.putExtra("srcheight", srcheight);
                intent.putExtra("recogType", recogType);
                intent.putExtra("nMainID", nMainID);
                startActivity(intent);
                dialog.dismiss();
                break;
            case 4:
                if (which == 0) {
                    recogType = 1;
                } else {
                    recogType = 3;
                }
                String partpath = Environment.getExternalStorageDirectory()
                        + "/wtimage";
                File dir = new File(partpath);
                if (!dir.exists()) {
                    dir.mkdir();
                }
                Date date = new Date();
                selectPath = partpath + "/idcard" + date.getTime() + ".jpg";
                Intent takePictureFromCameraIntent = new Intent(
                        MediaStore.ACTION_IMAGE_CAPTURE);
                takePictureFromCameraIntent.putExtra(
                        android.provider.MediaStore.EXTRA_OUTPUT,
                        Uri.fromFile(new File(selectPath)));
                startActivityForResult(takePictureFromCameraIntent, 1);
                overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                dialog.dismiss();
                break;
            case 5:
                if (which == 0) {
                    recogType = 3;
                } else {
                    recogType = 3;
                }
                /* ACTION_GET_CONTENT */
                Intent innerIntentX = new Intent(Intent.ACTION_GET_CONTENT);
                innerIntentX.addCategory(Intent.CATEGORY_OPENABLE);
                innerIntentX.setType("image/*");
                Intent wrapperIntentX = Intent.createChooser(innerIntentX,
                        "Select Picture");

                startActivityForResult(wrapperIntentX, 9);
                overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                dialog.dismiss();
                break;
            }

        }
    };

    protected void dialog() {
        int checkedItem = -1;
        // 能够使类型列表的选中效果不消失
        if (getResources().getConfiguration().locale.getLanguage().equals("en")
                && getResources().getConfiguration().locale.getCountry()
                        .equals("US") || international) {
            for (int i = 0; i < type3.length; i++) {

                if (Integer.valueOf(type3[i][1]) == nMainID) {
                    checkedItem = i;
                    break;
                }
            }
        }
        if (getResources().getConfiguration().locale.getLanguage().equals("zh")
                && getResources().getConfiguration().locale.getCountry()
                        .equals("TW") && !international) {
            for (int i = 0; i < type1.length; i++) {

                if (Integer.valueOf(type1[i][1]) == nMainID) {
                    checkedItem = i;
                    break;
                }
            }
        } else if (getResources().getConfiguration().locale.getLanguage()
                .equals("zh")
                && getResources().getConfiguration().locale.getCountry()
                        .equals("CN") && !international) {
            for (int i = 0; i < type2.length; i++) {

                if (Integer.valueOf(type2[i][1]) == nMainID) {
                    checkedItem = i;
                    break;
                }
            }

        }
        // 能够使类型列表的选中效果不消失
        DIALOG_ID = 2;
        AlertDialog.Builder dialog = createAlertDialog(
                getString(R.string.chooseRecogType), null);
        dialog.setPositiveButton(getString(R.string.confirm), dialogListener);
        dialog.setNegativeButton(getString(R.string.cancel), dialogListener);
        dialog.setSingleChoiceItems(type, checkedItem,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (getResources().getConfiguration().locale
                                .getLanguage().equals("en")
                                && getResources().getConfiguration().locale
                                        .getCountry().equals("US")
                                || international) {

                            for (int i = 0; i < type3.length; i++) {
                                if (which == i) {
                                    nMainID = Integer.valueOf(type3[i][1]);
                                    break;
                                }
                            }

                        }
                        if (getResources().getConfiguration().locale
                                .getLanguage().equals("zh")
                                && getResources().getConfiguration().locale
                                        .getCountry().equals("TW")
                                && !international) {
                            for (int i = 0; i < type1.length; i++) {
                                if (which == i) {
                                    nMainID = Integer.valueOf(type1[i][1]);
                                    break;
                                }
                            }
                        } else if (getResources().getConfiguration().locale
                                .getLanguage().equals("zh")
                                && getResources().getConfiguration().locale
                                        .getCountry().equals("CN")
                                && !international) {
                            for (int i = 0; i < type2.length; i++) {
                                if (which == i) {
                                    nMainID = Integer.valueOf(type2[i][1]);
                                    break;
                                }
                            }

                        }
                    }
                });
        dialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 9 && resultCode == Activity.RESULT_OK) {
            // // 选择后识别
            // Uri uri = data.getData();
            // Cursor cursor = getContentResolver().query(uri, null, null, null,
            // null);
            // if (cursor == null) {
            // selectPath = uri.getPath();
            // } else {
            // cursor.moveToFirst();
            // String imgPath = cursor.getString(1);
            // selectPath = imgPath;
            // }
            Uri uri = data.getData();
            String selectPath = uri.getPath();
            System.out.println("selectPath:" + selectPath);
            // selectPath = "/mnt/sdcard/001005.jsp";
            if (readMainID() != -1
                    && (1100 == readMainID() || 1101 == readMainID())) {
                if (recogType == 1) {
                    Intent intentto = new Intent(ImageChooser.this,
                            IdcardRunner.class);
                    intentto.putExtra("path", selectPath);
                    intentto.putExtra("nMainID", nMainID);
                    this.startActivity(intentto);
                    overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                } else {
                    Intent intent = new Intent(ImageChooser.this,
                            RecognizeActivity.class);
                    intent.putExtra("selectPath", selectPath);
                    intent.putExtra("recogType", recogType);
                    intent.putExtra("nMainID", nMainID);
                    ImageChooser.this.finish();
                    startActivity(intent);
                    overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                }
            } else {
                Intent intentto = new Intent(ImageChooser.this,
                        IdcardRunner.class);
                intentto.putExtra("path", selectPath);
                intentto.putExtra("nMainID", nMainID);
                ImageChooser.this.finish();
                this.startActivity(intentto);
                overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
            }
        } else if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            // 拍照后存图片
            boolean go = false;
            if (selectPath == null) {
                Log.i(TAG, "selectPath:" + selectPath);
                selectPath = getLatestImage();
                File file = new File(selectPath);
                if (file.exists()) {
                    go = true;
                }
                // else {
                // Toast.makeText(getApplicationContext(),
                // getString(R.string.toast_please_retake), 0).show();
                // }
            } else {
                go = true;
            }
            if (go) {
                // 跳转
                File file = new File(selectPath);
                Bitmap source = BitmapFactory.decodeFile(selectPath);
                Bitmap bmp = Bitmap.createScaledBitmap(source, 1280, 960, true);
                BufferedOutputStream bos = null;
                try {
                    bos = new BufferedOutputStream(new FileOutputStream(file));
                    bmp.compress(Bitmap.CompressFormat.JPEG, 75, bos);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        bos.flush();
                        bos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (readMainID() != -1
                        && (1100 == readMainID() || 1101 == readMainID())) {
                    Intent intent = new Intent(ImageChooser.this,
                            CameraActivity.class);
                    intent.putExtra("srcwidth", srcwidth);
                    intent.putExtra("srcheight", srcheight);
                    intent.putExtra("recogType", recogType);
                    intent.putExtra("nMainID", nMainID);
                    startActivity(intent);
                    overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
                } else {

                    Intent intent = new Intent(ImageChooser.this,
                            IdcardRunner.class);
                    intent.putExtra("path", selectPath);
                    intent.putExtra("nMainID", nMainID);
                    ImageChooser.this.finish();
                    this.startActivity(intent);
                    overridePendingTransition(R.anim.zoomin, R.anim.zoomout);

                }
            }

        }
    }

    @SuppressWarnings("unused")
    protected String getLatestImage() {
        String latestImage = null;
        String[] items = { MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, items, null,
                null, MediaStore.Images.Media._ID + " desc");
        if (cursor != null && cursor.getCount() > 0) {
            cursor.moveToFirst();
            for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor
                    .moveToNext()) {
                latestImage = cursor.getString(1);
                break;
            }
        }
        return latestImage;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // land
        } else if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            // port
        }
    }

    private ArrayList<Size> splitSize(String str, Camera camera) {
        if (str == null)
            return null;
        StringTokenizer tokenizer = new StringTokenizer(str, ",");
        ArrayList<Size> sizeList = new ArrayList<Size>();
        while (tokenizer.hasMoreElements()) {
            Size size = strToSize(tokenizer.nextToken(), camera);
            if (size != null)
                sizeList.add(size);
        }
        if (sizeList.size() == 0)
            return null;
        return sizeList;
    }

    private Size strToSize(String str, Camera camera) {
        if (str == null)
            return null;
        int pos = str.indexOf('x');
        if (pos != -1) {
            String width = str.substring(0, pos);
            String height = str.substring(pos + 1);
            return camera.new Size(Integer.parseInt(width),
                    Integer.parseInt(height));
        }
        return null;
    }

}