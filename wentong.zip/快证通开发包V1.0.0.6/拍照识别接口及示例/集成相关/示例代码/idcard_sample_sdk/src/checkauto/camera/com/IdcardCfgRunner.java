package checkauto.camera.com;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.Toast;

//该类已废弃
//用户不用集成这个类，证件类型可以识别时作为参数给出
public class IdcardCfgRunner extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); 
        
        Intent intentget = this.getIntent();
 		try { 
        		Intent intent = new Intent("wintone.idcardconfig");  
        		Bundle bundle = new Bundle();  
        		bundle.putString("cls", "com.wintone.run.IdcardCfgRunner");
        		intent.putExtras(bundle);  
        		startActivity(intent);  
        } catch (Exception e) {  
        		Toast.makeText(getApplicationContext(), "未找到" + "wintone.idcardconfig", 0).show();  
        } 

	}
	
	//璺宠浆鍚庣粨鏉熸湰Activity
    @Override      
    protected void onStop() 
    {          
    	super.onStop();           
    	finish();
    }   
    
    @Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
			// land
		} else if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
			// port
		}
	}

}
