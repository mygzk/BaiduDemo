package checkauto.camera.com;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;

import wintone.idcard.android.RecogParameterMessage;
import wintone.idcard.android.RecogService;
import wintone.idcard.android.ResultMessage;

import com.wintone.demo.idcard.R;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Camera.Size;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.format.Time;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 
 * 
 * 项目名称：idcard_sample_sdk 类名称：CameraRecogActivity
 * 类描述：手动拍照护照MRZ码和身份证号码识别的类。创建人：huangzhen 创建时间：2014年7月10日 下午3:22:10 修改人：huanzhen
 * 修改时间：2014年7月10日 下午3:22:10 修改备注：
 * 
 * @version
 * 
 */
public class CameraIDCardNoActivity extends Activity implements
        SurfaceHolder.Callback {
    public static final String PATH = Environment.getExternalStorageDirectory()
            .toString() + "/wtimage/";
    private String strCaptureFilePath;
    private int width, height, srcwidth, srcheight, WIDTH, HEIGHT, nMainID;
    private Camera camera;
    public int recogType = -1;// 自动识别、划线识别
    private TextView back_reset_text, take_recog_text, light_text, cut_text,
            lockTextView, textView, takepic__text;
    private ImageButton backbtn, resetbtn, takepicbtn, confirmbtn, lighton,
            cutoff;
    private ImageView top_left, top_right, bottom_left, bottom_right, left_cut,
            right_cut, imageView, lockImageView;
    private RelativeLayout rlyaout;
    private SurfaceView surfaceView;
    private SurfaceHolder surfaceHolder;
    private boolean unlockBoolean = true;
    private RelativeLayout rlayout;
    private boolean isPort = false;// 判断是否是竖屏
    private RelativeLayout rightlyaout;
    private ToneGenerator tone;
    public RecogService.recogBinder recogBinder;
    private Bitmap bitmap;
    private byte[] imageData;
    private Canvas canvas;
    private int rotation;
    private DisplayMetrics displayMetrics = new DisplayMetrics();
    private boolean istakePic = false;// 判断是否已经拍照，如果已经拍照则提示正在识别中请稍等
    private int uiRot = 0;
    private int rotationWidth, rotationHeight;
    private float widthScale = (float) 1.0;
    private float heightScale = (float) 1.0;
    private float scale = 1;
    private int index = 0;
    private ProgressBar progressBar;
    private long time, recogTime;
    private boolean isCompress = false;// 是否将分辨率大的图片压缩成小的图片
    private boolean horizontal;
    private boolean international = false;
    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            // TODO Auto-generated method stub
            // 三星在对焦设置为两秒的时候会抛出异常
            handler.postDelayed(this, 3000);
            autoFocus();

        }
    };

    @Override
    protected void onStart() {
        // TODO Auto-generated method stub
        super.onStart();
        findView();
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(CameraIDCardNoActivity.this);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        handler.postDelayed(runnable, 3000);// 每三秒执行一次runnable.启动程序
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        remove(CameraIDCardNoActivity.this, "CameraIDCardNoActivity", "result");
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        setContentView(R.layout.wintone_autocamera);
        width = displayMetrics.widthPixels;
        height = displayMetrics.heightPixels;
        // 设置拍摄尺寸
        Intent intent = this.getIntent();
        // 照片的分辨率2048--1536
        srcwidth = intent.getIntExtra("srcwidth", 2048);
        srcheight = intent.getIntExtra("srcheight", 1536);
        System.out.println("srcwidth:" + srcwidth + "--" + "srcheight:"
                + srcheight);
        WIDTH = intent.getIntExtra("WIDTH", 640);
        HEIGHT = intent.getIntExtra("HEIGHT", 480);
        recogType = intent.getIntExtra("recogType", 1);
        nMainID = intent.getIntExtra("nMainID", 1100);

    }

    /**
     * 
     * @Title: findView
     * @Description: 总界面布局
     * @param 设定文件
     * @return void 返回类型
     * @throws
     */
    public void findView() {
        textView = (TextView) findViewById(R.id.resulttextview);
        surfaceView = (SurfaceView) findViewById(R.id.surfaceViwe);
        rightlyaout = (RelativeLayout) findViewById(R.id.idcard_rightlyaout);
        back_reset_text = new TextView(this);
        back_reset_text.setId(R.id.back_and_reset_text);
        back_reset_text.setText(getString(R.string.backbtn_string));
        back_reset_text.setTextSize(20);
        back_reset_text.setTextColor(Color.BLACK);
        takepic__text = new TextView(this);
        takepic__text.setText(getString(R.string.takepic_btn_string));
        takepic__text.setTextSize(20);
        takepic__text.setTextColor(Color.BLACK);

        rightlyaout.addView(back_reset_text);
        rightlyaout.addView(takepic__text);
        RelativeLayout layout = (RelativeLayout) findViewById(R.id.idcard_showlyaout);
        imageView = new ImageView(this);
        progressBar = (ProgressBar) findViewById(R.id.progress_horizontal);
        imageView.setId(R.id.backimageView);
        imageView.setVisibility(View.INVISIBLE);
        layout.addView(imageView);
        backbtn = (ImageButton) findViewById(R.id.backbtn);
        takepicbtn = (ImageButton) findViewById(R.id.takepic_btn);
        backbtn.setOnClickListener(new mClickListener());
        takepicbtn.setOnClickListener(new mClickListener());
        int uiRot = getWindowManager().getDefaultDisplay().getRotation();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        rotation = uiRot;
        rotationWidth = displayMetrics.widthPixels;
        rotationHeight = displayMetrics.heightPixels;
        setViewByRotation(uiRot, displayMetrics.widthPixels,
                displayMetrics.heightPixels);
    }

    @Override
    public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
        // TODO Auto-generated method stub
        if (camera != null) {
            try {
                Camera.Parameters parameters = camera.getParameters();

                // parameters.getSupportedPictureSizes();
                parameters.setPictureFormat(PixelFormat.JPEG);       
                //parameters.setPreviewSize(WIDTH, HEIGHT);  
                parameters.setPictureSize(srcwidth, srcheight);
                camera.setParameters(parameters);
                camera.setPreviewDisplay(surfaceHolder);
                camera.startPreview();

            } catch (IOException e) {
                camera.release();
                camera = null;
                e.printStackTrace();
            }

        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder arg0) {
        // TODO Auto-generated method stub
        // 获得Camera对象
        if (null == camera) {
            camera = Camera.open();
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder arg0) {
        // TODO Auto-generated method stub
        synchronized (this) {
            try {
                if (camera != null) {
                    camera.stopPreview();
                    camera.release();
                    camera = null;
                }
            } catch (Exception e) {
                Log.i("TAG", e.getMessage());
            }
        }
    }

    private class mClickListener implements OnClickListener {
        public void onClick(View v) {
            switch (v.getId()) {
            case R.id.backbtn:
                if (back_reset_text.getText().equals(
                        getString(R.string.backbtn_string))) {
                    closeCamera();
                    handler.removeCallbacks(runnable);// 停止计时器，每当拍照或退出时都要执行这段代码。
                    Intent intent = new Intent();
                    intent.setClass(CameraIDCardNoActivity.this,
                            ImageChooser.class);
                    CameraIDCardNoActivity.this.finish();
                    startActivity(intent);

                }
                break;
            // 拍照
            case R.id.takepic_btn:
                if (!istakePic) {
                    handler.removeCallbacks(runnable);// 停止计时器，每当拍照或退出时都要执行这段代码。
                    istakePic = true;
                    takePicture();
                } else {
                    Toast.makeText(getApplicationContext(),
                            getString(R.string.Please_wait), Toast.LENGTH_SHORT)
                            .show();
                }
                break;

            }

        }
    }

    public void closeCamera() {
        synchronized (this) {
            try {
                if (camera != null) {
                    camera.stopPreview();
                    camera.release();
                    camera = null;
                }
            } catch (Exception e) {
                Log.i("TAG", e.getMessage());
            }
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        // TODO Auto-generated method stub
        super.onConfigurationChanged(newConfig);
        int uiRot = getWindowManager().getDefaultDisplay().getRotation();
        System.out.println("uiRot===" + uiRot);
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        rotation = uiRot;
        rotationWidth = displayMetrics.widthPixels;
        rotationHeight = displayMetrics.heightPixels;
        setViewByRotation(uiRot, displayMetrics.widthPixels,
                displayMetrics.heightPixels);
        textView.setText(readPreferences(CameraIDCardNoActivity.this,
                "CameraIDCardNoActivity", "result"));
    }

    // 快门按下的时候onShutter()被回调拍照声音
    private ShutterCallback shutterCallback = new ShutterCallback() {
        public void onShutter() {
            if (tone == null)
                // 发出提示用户的声音
                tone = new ToneGenerator(1,// AudioManager.AUDIOFOCUS_REQUEST_GRANTED
                        ToneGenerator.MIN_VOLUME);
            tone.startTone(ToneGenerator.TONE_PROP_BEEP);
        }
    };
    /* 拍照后回显 */
    private PictureCallback PictureCallback = new PictureCallback() {
        public void onPictureTaken(byte[] data, final Camera camera) {
            imageData = data;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inInputShareable = true;
            opts.inPurgeable = true;
            bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, opts);
            progressBar.setProgress(30);
            switch (uiRot) {
            case 0:
                if (rotationWidth > rotationHeight) {
                    System.out.println("---Nothing---");
                } else {
                    Matrix matrix = new Matrix();
                    matrix.preRotate(90);
                    Bitmap rotate_bitmap = Bitmap
                            .createBitmap(bitmap, 0, 0, bitmap.getWidth(),
                                    bitmap.getHeight(), matrix, true);
                    if (bitmap != rotate_bitmap) {
                        if (!bitmap.isRecycled()) {
                            bitmap.recycle();
                            bitmap = null;
                        }
                        bitmap = rotate_bitmap;
                    }

                    if (bitmap.getWidth() > 2048 && bitmap.getHeight() > 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 2048 / bitmap.getWidth();
                        heightScale = (float) 1536 / bitmap.getHeight();
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                2048, 1536, matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    } else if (bitmap.getWidth() > 2048
                            && bitmap.getHeight() <= 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 2048 / bitmap.getWidth();
                        heightScale = (float) 1.0;
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                2048, bitmap.getHeight(), matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    } else if (bitmap.getWidth() <= 2048
                            && bitmap.getHeight() > 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 1.0;
                        heightScale = (float) 1536 / bitmap.getHeight();
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                bitmap.getWidth(), 1536, matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    }
                }
                break;
            case 1:
                if (rotationWidth > rotationHeight) {
                    System.out.println("---Nothing---");
                } else {

                    Matrix matrix = new Matrix();
                    matrix.preRotate(0);
                    Bitmap rotate_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                            bitmap.getWidth(), bitmap.getHeight(), matrix,
                            false);
                    if (bitmap != rotate_bitmap) {
                        if (!bitmap.isRecycled()) {
                            bitmap.recycle();
                            bitmap = null;
                        }
                        bitmap = rotate_bitmap;
                    }

                    if (bitmap.getWidth() > 2048 && bitmap.getHeight() > 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 2048 / bitmap.getWidth();
                        heightScale = (float) 1536 / bitmap.getHeight();
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                2048, 1536, matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    } else if (bitmap.getWidth() > 2048
                            && bitmap.getHeight() <= 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 2048 / bitmap.getWidth();
                        heightScale = (float) 1.0;
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                2048, bitmap.getHeight(), matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    } else if (bitmap.getWidth() <= 2048
                            && bitmap.getHeight() > 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 1.0;
                        heightScale = (float) 1536 / bitmap.getHeight();
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                bitmap.getWidth(), 1536, matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    }

                }
                break;
            case 2:
                if (rotationWidth > rotationHeight) {
                    Matrix matrix = new Matrix();
                    matrix.preRotate(270);
                    Bitmap rotate_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                            bitmap.getWidth(), bitmap.getHeight(), matrix,
                            false);
                    if (bitmap != rotate_bitmap) {
                        if (!bitmap.isRecycled()) {
                            bitmap.recycle();
                            bitmap = null;
                        }
                        bitmap = rotate_bitmap;
                    }
                } else {

                    Matrix matrix = new Matrix();
                    matrix.preRotate(270);
                    Bitmap rotate_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                            bitmap.getWidth(), bitmap.getHeight(), matrix,
                            false);
                    if (bitmap != rotate_bitmap) {
                        if (!bitmap.isRecycled()) {
                            bitmap.recycle();
                            bitmap = null;
                        }
                        bitmap = rotate_bitmap;
                    }

                    if (bitmap.getWidth() > 2048 && bitmap.getHeight() > 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 2048 / bitmap.getWidth();
                        heightScale = (float) 1536 / bitmap.getHeight();
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                2048, 1536, matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    } else if (bitmap.getWidth() > 2048
                            && bitmap.getHeight() <= 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 2048 / bitmap.getWidth();
                        heightScale = (float) 1.0;
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                2048, bitmap.getHeight(), matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    } else if (bitmap.getWidth() <= 2048
                            && bitmap.getHeight() > 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 1.0;
                        heightScale = (float) 1536 / bitmap.getHeight();
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                bitmap.getWidth(), 1536, matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    }

                }
                break;
            case 3:
                if (rotationWidth > rotationHeight) {
                    Matrix matrix = new Matrix();
                    matrix.preRotate(180);
                    Bitmap rotate_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                            bitmap.getWidth(), bitmap.getHeight(), matrix,
                            false);

                    if (bitmap != rotate_bitmap) {
                        if (!bitmap.isRecycled()) {
                            bitmap.recycle();
                            bitmap = null;
                        }
                        bitmap = rotate_bitmap;
                    }
                } else {

                    Matrix matrix = new Matrix();
                    matrix.preRotate(180);
                    Bitmap rotate_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                            bitmap.getWidth(), bitmap.getHeight(), matrix,
                            false);
                    if (bitmap != rotate_bitmap) {
                        if (!bitmap.isRecycled()) {
                            bitmap.recycle();
                            bitmap = null;
                        }
                        bitmap = rotate_bitmap;
                    }

                    if (bitmap.getWidth() > 2048 && bitmap.getHeight() > 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 2048 / bitmap.getWidth();
                        heightScale = (float) 1536 / bitmap.getHeight();
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                2048, 1536, matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    } else if (bitmap.getWidth() > 2048
                            && bitmap.getHeight() <= 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 2048 / bitmap.getWidth();
                        heightScale = (float) 1.0;
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                2048, bitmap.getHeight(), matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    } else if (bitmap.getWidth() <= 2048
                            && bitmap.getHeight() > 1536) {
                        matrix = new Matrix();
                        widthScale = (float) 1.0;
                        heightScale = (float) 1536 / bitmap.getHeight();
                        matrix.postScale(widthScale, heightScale);
                        Bitmap cut_bitmap = Bitmap.createBitmap(bitmap, 0, 0,
                                bitmap.getWidth(), 1536, matrix, true);
                        if (bitmap != cut_bitmap) {
                            if (!bitmap.isRecycled()) {
                                bitmap.recycle();
                                bitmap = null;
                            }
                            bitmap = cut_bitmap;
                        }
                    }

                }
                break;

            }
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(30);
            // 压缩图片start
            if (isCompress) {
                Matrix matrix = new Matrix();
                widthScale = (float) 600 / bitmap.getWidth();
                heightScale = (float) 800 / bitmap.getHeight();
                matrix.postScale(widthScale, heightScale);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),
                        bitmap.getHeight(), matrix, false);
            }
            // 压缩图片end
            savePicture();
            progressBar.setProgress(50);
            /*
             * new Thread() { public void run() {
             */
            time = System.currentTimeMillis();
            Intent recogIntent = new Intent(CameraIDCardNoActivity.this,
                    RecogService.class);
            bindService(recogIntent, recogConn, Service.BIND_AUTO_CREATE);
            /*
             * }; }.start();
             */

        }

    };

    public void savePicture() {
        strCaptureFilePath = PATH + "idcard_" + pictureName() + ".jpg";
        File dir = new File(PATH);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File file = new File(strCaptureFilePath);
        if (file.exists()) {
            file.delete();
        }
        try {
            file.createNewFile();
            BufferedOutputStream bos = new BufferedOutputStream(
                    new FileOutputStream(file));

            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos);
            bos.flush();
            bos.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 
     * @Title: pictureName
     * @Description: 将文件命名
     * @param @return 设定文件
     * @return String 文件以时间命的名字
     * @throws
     */
    public String pictureName() {
        String str = "";
        Time t = new Time();
        t.setToNow(); // 取得系统时间。
        int year = t.year;
        int month = t.month + 1;
        int date = t.monthDay;
        int hour = t.hour; // 0-23
        int minute = t.minute;
        int second = t.second;
        if (month < 10)
            str = String.valueOf(year) + "0" + String.valueOf(month);
        else {
            str = String.valueOf(year) + String.valueOf(month);
        }
        if (date < 10)
            str = str + "0" + String.valueOf(date);
        else {
            str = str + String.valueOf(date);
        }
        if (hour < 10)
            str = str + "0" + String.valueOf(hour);
        else {
            str = str + String.valueOf(hour);
        }
        if (minute < 10)
            str = str + "0" + String.valueOf(minute);
        else {
            str = str + String.valueOf(minute);
        }
        if (second < 10)
            str = str + "0" + String.valueOf(second);
        else {
            str = str + String.valueOf(second);
        }
        return str;
    }

    // 识别验证
    public ServiceConnection recogConn = new ServiceConnection() {

        public void onServiceDisconnected(ComponentName name) {
            recogBinder = null;
        }

        public void onServiceConnected(ComponentName name, IBinder service) {

            recogBinder = (RecogService.recogBinder) service;

            RecogParameterMessage rpm = new RecogParameterMessage();

            rpm.devcode = "5YYX5LQS5PAH6YC";// 项目授权 所需参数

            rpm.nTypeInitIDCard = 0;
            rpm.nTypeLoadImageToMemory = 0;
            rpm.nMainID = nMainID;
            rpm.nSubID = null;
            rpm.GetSubID = true;
            rpm.lpHeadFileName = "";
            rpm.GetVersionInfo = true;
            rpm.logo = "";
            rpm.userdata = "";
            rpm.lpFileName = strCaptureFilePath;
            rpm.sn = "";
            rpm.authfile = "";
            rpm.isCut = true;
            if (nMainID == 1020) {
                // 护照机读码识别
                rpm.array = new int[4];
                rpm.array[0] = 0;
                rpm.array[1] = 0;
                rpm.array[2] = 0;
                rpm.array[3] = 0;
                // 手动拍照时将rpm.ncheckmrz赋值为1
                rpm.ncheckmrz = 1;
            }

            try {
                ResultMessage resultMessage;
                resultMessage = recogBinder.getRecogResult(rpm);
                if (resultMessage.ReturnAuthority == 0
                        && resultMessage.ReturnInitIDCard == 0
                        && resultMessage.ReturnLoadImageToMemory == 0
                        && resultMessage.ReturnRecogIDCard > 0) {
                    String iDResultString = "";
                    String[] GetFieldName = resultMessage.GetFieldName;
                    String[] GetRecogResult = resultMessage.GetRecogResult;
                    // takepicbtn.setBackgroundResource(R.drawable.takepic);
                    progressBar.setProgress(80);
                    progressBar.setVisibility(View.GONE);
                    if (nMainID == 1020) {
                        for (int i = 10; i < 12; i++) {
                            if (GetFieldName[i] != null
                                    && !GetFieldName[i].equals("")
                                    && !GetFieldName.equals("null")) {
                                iDResultString += GetFieldName[i] + ":"
                                        + GetRecogResult[i] + "\n";
                            }
                        }
                    } else if (nMainID == 1034) {
                        for (int i = 1; i <= 2; i++) {
                            if (GetFieldName[i] != null
                                    && !GetFieldName[i].equals("")
                                    && !GetFieldName.equals("null")) {
                                iDResultString += GetFieldName[i] + ":"
                                        + GetRecogResult[i] + "\n";
                            }
                        }
                    } else {
                        for (int i = 1; i < GetRecogResult.length; i++) {
                            if (GetFieldName[i] != null
                                    && !GetFieldName[i].equals("")
                                    && !GetFieldName.equals("null")) {
                                iDResultString += GetFieldName[i] + ":"
                                        + GetRecogResult[i] + "\n";
                            }
                        }
                    }
                    recogTime = System.currentTimeMillis() - time;
                    progressBar.setProgress(100);
                    textView.setText(iDResultString + recogTime + "ms");
                    writeStrPreferences(CameraIDCardNoActivity.this,
                            "CameraIDCardNoActivity", "result", iDResultString
                                    + recogTime + "ms");
                    imageView.setVisibility(View.VISIBLE);
                    istakePic = false;
                    handler.postDelayed(runnable, 3000);// 每三秒执行一次runnable.启动程序
                    camera.startPreview();
                } else {
                    String str = "";
                    if (resultMessage.ReturnAuthority == -100000) {
                        str = getString(R.string.exception)
                                + resultMessage.ReturnAuthority;
                    } else if (resultMessage.ReturnAuthority != 0) {
                        str = getString(R.string.exception1)
                                + resultMessage.ReturnAuthority;
                    } else if (resultMessage.ReturnInitIDCard != 0) {
                        str = getString(R.string.exception2)
                                + resultMessage.ReturnInitIDCard;
                    } else if (resultMessage.ReturnLoadImageToMemory != 0) {
                        if (resultMessage.ReturnLoadImageToMemory == 3) {
                            str = getString(R.string.exception3)
                                    + resultMessage.ReturnLoadImageToMemory;
                        } else if (resultMessage.ReturnLoadImageToMemory == 1) {
                            str = getString(R.string.exception4)
                                    + resultMessage.ReturnLoadImageToMemory;
                        } else {
                            str = getString(R.string.exception5)
                                    + resultMessage.ReturnLoadImageToMemory;
                        }
                    } else if (resultMessage.ReturnRecogIDCard != 0) {
                        str = getString(R.string.exception6)
                                + resultMessage.ReturnRecogIDCard;
                    }
                    recogTime = System.currentTimeMillis() - time;
                    textView.setText(getString(R.string.recogResult2) + str
                            + "\n" + recogTime + "ms");
                    writeStrPreferences(CameraIDCardNoActivity.this,
                            "CameraIDCardNoActivity", "result",
                            getString(R.string.recogResult2) + str + "\n"
                                    + recogTime + "ms");
                    camera.startPreview();
                    imageView.setVisibility(View.VISIBLE);
                    istakePic = false;
                    progressBar.setProgress(100);
                    progressBar.setVisibility(View.GONE);
                    handler.postDelayed(runnable, 3000);// 每三秒执行一次runnable.启动程序
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(),
                        getString(R.string.recognized_failed),
                        Toast.LENGTH_SHORT).show();

            } finally {
                if (recogBinder != null) {
                    unbindService(recogConn);
                }
            }

        }
    };

    /* 拍照对焦 */
    /* 拍照 */
    public void takePicture() {
        if (camera != null) {
            try {
                if (camera.getParameters().getSupportedFocusModes() != null
                        && camera.getParameters().getSupportedFocusModes()
                                .contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                    camera.autoFocus(new AutoFocusCallback() {
                        public void onAutoFocus(boolean success, Camera camera) {
                            if (success) {
                                camera.takePicture(shutterCallback, null,
                                        PictureCallback);
                            } else {
                                camera.takePicture(shutterCallback, null,
                                        PictureCallback);
                            }
                        }
                    });
                } else {
                    camera.takePicture(shutterCallback, null, PictureCallback);
                    Toast.makeText(getBaseContext(),
                            getString(R.string.unsupport_auto_focus),
                            Toast.LENGTH_LONG).show();
                }

            } catch (Exception e) {
                e.printStackTrace();
                camera.stopPreview();
                camera.startPreview();
                takepicbtn.setEnabled(true);
                Toast.makeText(this, R.string.toast_autofocus_failure,
                        Toast.LENGTH_SHORT).show();

            }
        }
    }

    public static int computeSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        int initialSize = computeInitialSampleSize(options, minSideLength,
                maxNumOfPixels);
        int roundedSize;
        if (initialSize <= 8) {
            roundedSize = 1;
            while (roundedSize < initialSize) {
                roundedSize <<= 1;
            }
        } else {
            roundedSize = (initialSize + 7) / 8 * 8;
        }
        return roundedSize;
    }

    private static int computeInitialSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        double w = options.outWidth;
        double h = options.outHeight;
        int lowerBound = (maxNumOfPixels == -1) ? 1 : (int) Math.ceil(Math
                .sqrt(w * h / maxNumOfPixels));
        int upperBound = (minSideLength == -1) ? 128 : (int) Math.min(
                Math.floor(w / minSideLength), Math.floor(h / minSideLength));
        if (upperBound < lowerBound) {
            return lowerBound;
        }
        if ((maxNumOfPixels == -1) && (minSideLength == -1)) {
            return 1;
        } else if (minSideLength == -1) {
            return lowerBound;
        } else {
            return upperBound;
        }
    }

    /**
     * 
     * @Title: writeStrPreferences
     * @Description: 将字符串型数据写入SharedPreferences中
     * @param @param context
     * @param @param perferencesName
     * @param @param key
     * @param @param value 设定文件
     * @return void 返回类型
     * @throws
     */
    public static void writeStrPreferences(Context context,
            String perferencesName, String key, String value) {
        SharedPreferences preferences = getSharedPreferences(context,
                perferencesName);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    /**
     * 
     * @Title: readPreferences
     * @Description: 从SharedPreferences中读取整形数据
     * @param @param context
     * @param @param perferencesName
     * @param @param key
     * @param @return 设定文件
     * @return int 返回类型
     * @throws
     */
    public static String readPreferences(Context context,
            String perferencesName, String key) {
        SharedPreferences preferences = getSharedPreferences(context,
                perferencesName);
        String result = preferences.getString(key, "");
        return result;
    }

    /**
     * 获取SharedPreferences实例对象
     * 
     * @param context
     * @return
     */
    public static SharedPreferences getSharedPreferences(Context context,
            String perferencesName) {
        return context.getSharedPreferences(perferencesName,
                Context.MODE_PRIVATE);
    }

    /**
     * 
     * @Title: remove
     * @Description: 删除对应的 SharedPreferences的记录
     * @param @param context
     * @param @param key
     * @param @param perferencesName
     * @param @return 设定文件
     * @return boolean 返回类型
     * @throws
     */
    public static boolean remove(Context context, String perferencesName,
            String key) {
        SharedPreferences sharedPreference = getSharedPreferences(context,
                perferencesName);
        Editor editor = sharedPreference.edit();
        editor.remove(key);
        return editor.commit();
    }

    public void autoFocus() {
        if (camera != null) {
            try {
                if (camera.getParameters().getSupportedFocusModes() != null
                        && camera.getParameters().getSupportedFocusModes()
                                .contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                    camera.autoFocus(new AutoFocusCallback() {
                        public void onAutoFocus(boolean success, Camera camera) {
                            if (success) {

                            } else {

                            }
                        }
                    });
                } else {

                    Toast.makeText(getBaseContext(),
                            getString(R.string.unsupport_auto_focus),
                            Toast.LENGTH_LONG).show();
                }

            } catch (Exception e) {
                e.printStackTrace();
                camera.stopPreview();
                camera.startPreview();
                takepicbtn.setEnabled(true);
                Toast.makeText(this, R.string.toast_autofocus_failure,
                        Toast.LENGTH_SHORT).show();

            }
        }
    }

    private void setViewByRotation(int rotation, int width, int height) {
        if (camera == null) {
            try {
                camera = Camera.open();

            } catch (Exception e) {

                camera = Camera.open();

            }
        }
        switch (rotation) {
        case 0:

            if (camera != null) {
                camera.stopPreview();
            }
            if (width > height) {
                horizontal = true;
                camera.setDisplayOrientation(0);
                findViewLandscape(width, height);
                System.out.println("width > height--------" + 0);
            } else {
                camera.setDisplayOrientation(90);
                findViewPortrait(width, height);
                System.out.println("width <= height--------" + 0);
            }
            break;

        case 1:

            if (camera != null) {
                camera.stopPreview();
            }
            if (width > height) {
                camera.setDisplayOrientation(0);
                findViewLandscape(width, height);
                System.out.println("width > height--------" + 0);
            } else {
                horizontal = false;
                camera.setDisplayOrientation(270);
                findViewPortrait(width, height);
                System.out.println("width <= height--------" + 0);
            }
            break;
        case 2:
            if (camera != null) {
                camera.stopPreview();
            }

            if (width > height) {
                horizontal = true;
                camera.setDisplayOrientation(180);
                findViewLandscape(width, height);
                System.out.println("width > height--------" + 0);
            } else {

                camera.setDisplayOrientation(270);
                findViewPortrait(width, height);
                System.out.println("width <= height--------" + 0);
            }
            break;
        case 3:

            if (camera != null) {
                camera.stopPreview();
            }
            if (width > height) {
                camera.setDisplayOrientation(180);
                findViewLandscape(width, height);
                System.out.println("width > height--------" + 0);
            } else {
                horizontal = false;
                camera.setDisplayOrientation(90);
                findViewPortrait(width, height);
                System.out.println("width <= height--------" + 0);
            }
            break;
        }

        camera.startPreview();
    }

    /**
     * 
     * @Title: findViewPortrait
     * @Description: 竖屏界面布局
     * @param 设定文件
     * @return void 返回类型
     * @throws
     */
    private void findViewPortrait(int width, int height) {
        rlyaout = (RelativeLayout) findViewById(R.id.idcard_rightlyaout);
        int layout_height = (int) (width - ((width * 3) / 4));
        RelativeLayout.LayoutParams lP = new RelativeLayout.LayoutParams(width,
                layout_height);
        lP.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
        rlyaout.setLayoutParams(lP);
        RelativeLayout.LayoutParams progressBarlParams = new RelativeLayout.LayoutParams(
                width, RelativeLayout.LayoutParams.WRAP_CONTENT);
        progressBarlParams.addRule(RelativeLayout.ABOVE,
                R.id.idcard_rightlyaout);
        progressBar.setLayoutParams(progressBarlParams);
        System.out.println("竖直长度:" + width + "\n" + "竖直高度:" + height);
        int button_width = (int) (height * 0.125);
        int button_distance = (int) (height * 0.1);
        surfaceView = (SurfaceView) findViewById(R.id.surfaceViwe);
        takepicbtn = (ImageButton) findViewById(R.id.takepic_btn);
        backbtn = (ImageButton) findViewById(R.id.backbtn);
        // 黄震布局修改 start
        textView = (TextView) findViewById(R.id.resulttextview);
        RelativeLayout.LayoutParams textViewParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        textView.setTextColor(Color.WHITE);
        textView.setLayoutParams(textViewParams);
        RelativeLayout.LayoutParams backlParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        backlParams.addRule(RelativeLayout.BELOW, R.id.backbtn);
        try {
            String[] fileNames = this.getAssets().list("");
            String[] filename = new String[fileNames.length];
            for (int i = 0; i < fileNames.length; i++) {
                if (fileNames[i].equals("English.txt")) {
                    international = true;
                    break;
                }
                ;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (international) {

            backlParams.leftMargin = (3 * button_distance) / 3;
        } else {
            backlParams.leftMargin = (4 * button_distance) / 3;
        }

        back_reset_text.setLayoutParams(backlParams);

        // 拍照的textview的布局
        RelativeLayout.LayoutParams takepiclParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        takepiclParams.addRule(RelativeLayout.BELOW, R.id.takepic_btn);
        takepiclParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,
                RelativeLayout.TRUE);
        if (international) {

            takepiclParams.rightMargin = (3 * button_distance) / 3;
        } else {
            takepiclParams.rightMargin = (4 * button_distance) / 3;
        }

        takepic__text.setLayoutParams(takepiclParams);
        // 黄震布局修改 end
        if (((float) width / height == (float) 4 / 3)
                || ((float) width / height == (float) 3 / 4)) {
            // 如果屏幕的分辨率的比例为4/3或3/4则进入执行如下代码
            lP = new RelativeLayout.LayoutParams(width, height);
            lP.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
            lP.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
            surfaceView.setLayoutParams(lP);
            lP = new RelativeLayout.LayoutParams(width, height / 8);
            // lP.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
            // RelativeLayout.TRUE);
            lP.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
            rightlyaout.setLayoutParams(lP);

        } else {
            RelativeLayout.LayoutParams surfaceViewlParams = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
            surfaceViewlParams.addRule(RelativeLayout.ABOVE,
                    R.id.idcard_rightlyaout);
            surfaceView.setLayoutParams(surfaceViewlParams);
        }
        RelativeLayout.LayoutParams lParams = new RelativeLayout.LayoutParams(
                button_distance, button_distance);
        lParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        lParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
        lParams.leftMargin = button_distance;
        backbtn.setLayoutParams(lParams);
        backbtn.setOnClickListener(new mClickListener());
        lParams = new RelativeLayout.LayoutParams(button_distance,
                button_distance);
        lParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        lParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
        lParams.rightMargin = button_distance;
        takepicbtn.setLayoutParams(lParams);
        takepicbtn.setOnClickListener(new mClickListener());
        top_left = (ImageView) findViewById(R.id.topleft);
        top_right = (ImageView) findViewById(R.id.topright);
        bottom_left = (ImageView) findViewById(R.id.bottomleft);
        bottom_right = (ImageView) findViewById(R.id.bottomright);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                (int) (height * 0.08), (int) (height * 0.08));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
                RelativeLayout.TRUE);
        layoutParams.topMargin = height / 6;
        top_left.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams((int) (height * 0.08),
                (int) (height * 0.08));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,
                RelativeLayout.TRUE);
        layoutParams.topMargin = height / 6;
        top_right.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams((int) (height * 0.08),
                (int) (height * 0.08));
        layoutParams
                .addRule(RelativeLayout.ALIGN_LEFT, R.id.idcard_rightlyaout);
        layoutParams.addRule(RelativeLayout.ABOVE, R.id.idcard_rightlyaout);
        layoutParams.bottomMargin = height / 6;
        bottom_left.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams((int) (height * 0.08),
                (int) (height * 0.08));
        layoutParams.addRule(RelativeLayout.ABOVE, R.id.idcard_rightlyaout);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,
                RelativeLayout.TRUE);
        layoutParams.bottomMargin = height / 6;
        bottom_right.setLayoutParams(layoutParams);

        int margin = 0;
        int cutImageLayoutHeight = 0;
        if (srcwidth == 1280 || srcwidth == 960) {
            margin = (int) ((height * 1.333) * 0.165);
            cutImageLayoutHeight = (int) (height * 0.135);
        }
        if (srcwidth == 1600 || srcwidth == 1200) {
            margin = (int) ((height * 1.333) * 0.19);
            cutImageLayoutHeight = (int) (height * 0.108);
        }
        if (srcwidth == 2048 || srcwidth == 1536) {
            margin = (int) ((height * 1.333) * 0.22);
            cutImageLayoutHeight = (int) (height * 0.13);
        }
        lockImageView = (ImageView) findViewById(R.id.unlockbutton);
        lockImageView.setVisibility(View.GONE);
        lockTextView = (TextView) findViewById(R.id.locktextview);
        lockTextView.setVisibility(View.GONE);
        // huangzhen 更改布局start
        switch (nMainID) {
        // 身份证
        case 1102:

            if (width >= 736 && height >= 1280) {
                textView.setTextSize(20);
            } else {
                textView.setTextSize(20);
            }

            break;
        // 护照
        case 1020:
            if (height == 540 && width == 960) {
                textView.setTextSize(15);
                textView.setWidth(height * 3 / 5);
                System.out.println(width + "--" + height);
            }
            if (height >= 736 || width >= 1280) {
                textView.setTextSize(20);
                textView.setWidth(height * 3 / 5);
            }
            if (height < 540 && width < 960) {
                textView.setTextSize(13);
                textView.setWidth(height * 3 / 5);
            }
            if (height == 720 && width == 1280) {
                textView.setTextSize(15);
                textView.setWidth(height * 3 / 5);
            }
            if (height == 960 && width == 1280) {
                textView.setTextSize(15);
                textView.setWidth(height * 3 / 5);
            }
            break;
        // 三行护照机读码
        case 1033:
            if (height == 540 && width == 960) {
                textView.setTextSize(15);
                System.out.println(width + "--" + height);
            }
            if (height >= 736 || width >= 1280) {
                textView.setTextSize(20);
            }
            if (height < 540 && width < 960) {
                textView.setTextSize(13);
            }
            if (height == 720 && width == 1280) {
                textView.setTextSize(15);
            }
            if (height == 960 && width == 1280) {
                textView.setTextSize(15);
            }
            break;
        // 老板港澳通行证MRZ码
        case 1034:
            if (height == 540 && width == 960) {
                textView.setTextSize(15);
                textView.setWidth(height * 3 / 5);
            }
            if (height >= 736 || width >= 1280) {
                textView.setTextSize(20);
                textView.setWidth(height * 3 / 5);
            }
            if (height < 540 && width < 960) {
                textView.setTextSize(13);
                textView.setWidth(height * 3 / 5);
            }
            if (height == 720 && width == 1280) {
                textView.setTextSize(15);
                textView.setWidth(height * 3 / 5);
            }
            if (height == 960 && width == 1280) {
                textView.setTextSize(15);
                textView.setWidth(height * 3 / 5);
            }
            break;
        // MRZ 2*36
        case 1036:
            if (height == 540 && width == 960) {
                textView.setTextSize(15);
                textView.setWidth(height * 3 / 5);
            }
            if (height >= 736 || width >= 1280) {
                textView.setTextSize(20);
                textView.setWidth(height * 3 / 5);
            }
            if (height < 540 && width < 960) {
                textView.setTextSize(13);
                textView.setWidth(height * 3 / 5);
            }
            if (height == 720 && width == 1280) {
                textView.setTextSize(15);
                textView.setWidth(height * 3 / 5);
            }
            if (height == 960 && width == 1280) {
                textView.setTextSize(15);
                textView.setWidth(height * 3 / 5);
            }
            break;
        default:
            break;
        }

        RelativeLayout.LayoutParams lParam = new RelativeLayout.LayoutParams(
                (int) (srcwidth * 0.9/* 0.76 */), height / 6);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        imageView.setLayoutParams(lParam);
        lParam = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
        lockTextView.setLayoutParams(lParam);
        lParam = new RelativeLayout.LayoutParams(70, 70);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParam.addRule(RelativeLayout.LEFT_OF, R.id.locktextview);
        lockImageView.setLayoutParams(lParam);

        // huangzhen 更改布局 end

        if (nMainID == 1100 || nMainID == 1101) {
            left_cut.setBackgroundResource(R.drawable.leftcut);
            right_cut.setBackgroundResource(R.drawable.rightcut);
            // showTwoCutImageView();
        } else {
            top_left.setBackgroundResource(R.drawable.top_left);
            bottom_left.setBackgroundResource(R.drawable.bottom_left);
            top_right.setBackgroundResource(R.drawable.top_right);
            bottom_right.setBackgroundResource(R.drawable.bottom_right);
            // showFourImageView();
        }
        textView.setText("");
    }

    /**
     * @Title: findViewLandscape
     * @Description: 横屏界面布局
     * @param 设定文件
     * @return void 返回类型
     * @throws
     */
    private void findViewLandscape(int width, int height) {
        rlyaout = (RelativeLayout) findViewById(R.id.idcard_rightlyaout);
        int layout_width = (int) (width - ((width * 3) / 4));
        RelativeLayout.LayoutParams lP = new RelativeLayout.LayoutParams(
                layout_width, height);
        lP.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
        lP.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        rlyaout.setLayoutParams(lP);
        RelativeLayout.LayoutParams progressBarlParams = new RelativeLayout.LayoutParams(
                width, RelativeLayout.LayoutParams.WRAP_CONTENT);
        progressBarlParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM,
                RelativeLayout.TRUE);
        progressBarlParams.addRule(RelativeLayout.LEFT_OF,
                R.id.idcard_rightlyaout);
        progressBar.setLayoutParams(progressBarlParams);
        System.out.println("水平长度:" + width + "\n" + "水平高度:" + height);
        int uiRot = getWindowManager().getDefaultDisplay().getRotation();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        rotation = uiRot;
        int button_width = (int) (height * 0.125);
        int button_distance = (int) (width * 0.1);
        textView = (TextView) findViewById(R.id.resulttextview);
        RelativeLayout.LayoutParams textViewParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        textViewParams.leftMargin = (int) (height * 0.08);
        textView.setTextColor(Color.WHITE);
        textView.setLayoutParams(textViewParams);
        // 黄震布局修改 start
        RelativeLayout.LayoutParams backlParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        backlParams.addRule(RelativeLayout.BELOW, R.id.backbtn);
        backlParams.addRule(RelativeLayout.CENTER_HORIZONTAL,
                RelativeLayout.TRUE);
        backlParams.leftMargin = (4 * button_distance) / 3;
        back_reset_text.setLayoutParams(backlParams);
        // 拍照的textview的布局
        RelativeLayout.LayoutParams takepiclParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        takepiclParams.addRule(RelativeLayout.BELOW, R.id.takepic_btn);
        takepiclParams.addRule(RelativeLayout.CENTER_HORIZONTAL,
                RelativeLayout.TRUE);
        takepiclParams.rightMargin = (4 * button_distance) / 3;
        takepic__text.setLayoutParams(takepiclParams);
        // 黄震布局修改 end
        RelativeLayout.LayoutParams lParams = new RelativeLayout.LayoutParams(
                button_distance, button_distance);
        lParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        lParams.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParams.topMargin = button_distance;
        backbtn = (ImageButton) findViewById(R.id.backbtn);
        backbtn.setLayoutParams(lParams);
        backbtn.setOnClickListener(new mClickListener());
        lParams = new RelativeLayout.LayoutParams(button_distance,
                button_distance);
        lParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        lParams.addRule(RelativeLayout.BELOW, R.id.backbtn);
        lParams.topMargin = button_distance;
        takepicbtn = (ImageButton) findViewById(R.id.takepic_btn);
        takepicbtn.setLayoutParams(lParams);
        takepicbtn.setOnClickListener(new mClickListener());
        top_left = (ImageView) findViewById(R.id.topleft);
        top_right = (ImageView) findViewById(R.id.topright);
        bottom_left = (ImageView) findViewById(R.id.bottomleft);
        bottom_right = (ImageView) findViewById(R.id.bottomright);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                (int) (height * 0.08), (int) (height * 0.08));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
                RelativeLayout.TRUE);
        top_left.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams((int) (height * 0.08),
                (int) (height * 0.08));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        top_right.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams((int) (height * 0.08),
                (int) (height * 0.08));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
                RelativeLayout.TRUE);
        bottom_left.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams((int) (height * 0.08),
                (int) (height * 0.08));
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        bottom_right.setLayoutParams(layoutParams);

        int margin = 0;
        int cutImageLayoutHeight = 0;
        if (srcwidth == 1280 || srcwidth == 960) {
            margin = (int) ((height * 1.333) * 0.165);
            cutImageLayoutHeight = (int) (height * 0.135);
        }
        if (srcwidth == 1600 || srcwidth == 1200) {
            margin = (int) ((height * 1.333) * 0.19);
            cutImageLayoutHeight = (int) (height * 0.108);
        }
        if (srcwidth == 2048 || srcwidth == 1536) {
            margin = (int) ((height * 1.333) * 0.22);
            cutImageLayoutHeight = (int) (height * 0.13);
        }
        left_cut = (ImageView) findViewById(R.id.leftcut);
        right_cut = (ImageView) findViewById(R.id.rightcut);
        layoutParams = new RelativeLayout.LayoutParams(
                (int) (cutImageLayoutHeight * 0.6), cutImageLayoutHeight);
        layoutParams.addRule(RelativeLayout.CENTER_VERTICAL,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
                RelativeLayout.TRUE);
        layoutParams.leftMargin = margin;
        left_cut.setLayoutParams(layoutParams);

        layoutParams = new RelativeLayout.LayoutParams(
                (int) (cutImageLayoutHeight * 0.6), cutImageLayoutHeight);
        layoutParams.addRule(RelativeLayout.CENTER_VERTICAL,
                RelativeLayout.TRUE);
        layoutParams.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        layoutParams.rightMargin = margin;
        right_cut.setLayoutParams(layoutParams);
        surfaceView = (SurfaceView) findViewById(R.id.surfaceViwe);
        if (((float) width / height == (float) 4 / 3)
                || ((float) width / height == (float) 3 / 4)) { // 如果屏幕的分辨率的比例为4/3或3/4则进入执行如下代码
            lP = new RelativeLayout.LayoutParams(width, height);
            lP.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
            lP.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
            surfaceView.setLayoutParams(lP);
            lP = new RelativeLayout.LayoutParams(width / 5, height);
            // lP.addRule(RelativeLayout.ALIGN_PARENT_LEFT,
            // RelativeLayout.TRUE);
            lP.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
            rightlyaout.setLayoutParams(lP);

        } else {
            RelativeLayout.LayoutParams surfaceViewlParams = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
            surfaceViewlParams.addRule(RelativeLayout.LEFT_OF,
                    R.id.idcard_rightlyaout);
            surfaceView.setLayoutParams(surfaceViewlParams);
        }

        lockImageView = (ImageView) findViewById(R.id.unlockbutton);
        lockTextView = (TextView) findViewById(R.id.locktextview);
        lockImageView.setVisibility(View.GONE);
        lockTextView.setVisibility(View.GONE);

        // huangzhen 更改布局start
        switch (nMainID) {
        case 1102:

            if (width >= 736 || height >= 1280) {
                textView.setTextSize(25);
            } else {
                textView.setTextSize(20);
            }

            break;
        case 1020:
            if (width == 540 && height == 960) {
                textView.setTextSize(13);
                textView.setWidth(width * 3 / 5);
                System.out.println(width + "--" + height);
            }
            if (width >= 736 || height >= 1280) {
                textView.setTextSize(20);
                textView.setWidth(width * 3 / 5);
            }
            if (width < 540 && height < 960) {
                textView.setTextSize(13);
                textView.setWidth(width * 3 / 5);
            }
            if (width == 720 && height == 1280) {
                textView.setTextSize(13);
                textView.setWidth(width * 3 / 5);
            }
            if (width == 960 && height == 1280) {
                textView.setTextSize(13);
                textView.setWidth(width * 3 / 5);
            }
            break;
        case 1033:
            // 三行护照机读码
            if (width == 540 && height == 960) {
                textView.setTextSize(13);
                System.out.println(width + "--" + height);
            }
            if (width >= 736 || height >= 1280) {
                textView.setTextSize(20);
            }
            if (width < 540 && height < 960) {
                textView.setTextSize(13);
            }
            if (width == 720 && height == 1280) {
                textView.setTextSize(13);
            }
            if (width == 960 && height == 1280) {
                textView.setTextSize(13);
            }
            break;
        // 老板港澳通行证MRZ码
        case 1034:
            if (width == 540 && height == 960) {
                textView.setTextSize(15);
                textView.setWidth(width * 3 / 5);
                System.out.println(width + "--" + height);
            }
            if (width >= 736 || height >= 1280) {
                textView.setTextSize(20);
                textView.setWidth(width * 3 / 5);
            }
            if (width < 540 && height < 960) {
                textView.setTextSize(13);
                textView.setWidth(width * 3 / 5);
            }
            if (width == 720 && height == 1280) {
                textView.setTextSize(15);
                textView.setWidth(width * 3 / 5);
            }
            if (width == 960 && height == 1280) {
                textView.setTextSize(15);
                textView.setWidth(width * 3 / 5);
            }
            break;
        // MRZ 2*36
        case 1036:
            if (width == 540 && height == 960) {
                textView.setTextSize(15);
                textView.setWidth(width * 3 / 5);
                System.out.println(width + "--" + height);
            }
            if (width >= 736 || height >= 1280) {
                textView.setTextSize(20);
                textView.setWidth(width * 3 / 5);
            }
            if (width < 540 && height < 960) {
                textView.setTextSize(13);
                textView.setWidth(width * 3 / 5);
            }
            if (width == 720 && height == 1280) {
                textView.setTextSize(15);
                textView.setWidth(width * 3 / 5);
            }
            if (width == 960 && height == 1280) {
                textView.setTextSize(15);
                textView.setWidth(width * 3 / 5);
            }
            break;
        default:
            break;
        }
        RelativeLayout.LayoutParams lParam = new RelativeLayout.LayoutParams(
                (int) (height * 0.9), height / 6);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParam.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        imageView.setLayoutParams(lParam);
        lParam = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParam.addRule(RelativeLayout.LEFT_OF, R.id.idcard_rightlyaout);
        lockTextView.setLayoutParams(lParam);
        lParam = new RelativeLayout.LayoutParams(70, 70);
        lParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        lParam.addRule(RelativeLayout.LEFT_OF, R.id.locktextview);
        lockImageView.setLayoutParams(lParam);

        // huangzhen 更改布局 end

        if (nMainID == 1100 || nMainID == 1101) {
            left_cut.setBackgroundResource(R.drawable.leftcut);
            right_cut.setBackgroundResource(R.drawable.rightcut);
        } else {
            top_left.setBackgroundResource(R.drawable.top_left);
            bottom_left.setBackgroundResource(R.drawable.bottom_left);
            top_right.setBackgroundResource(R.drawable.top_right);
            bottom_right.setBackgroundResource(R.drawable.bottom_right);
        }
        textView.setText("");
    }
}
