package checkauto.camera.com;

import wintone.idcard.android.AuthParameterMessage;
import wintone.idcard.android.AuthService;
import wintone.idcard.android.RecogParameterMessage;
import wintone.idcard.android.RecogService;
import wintone.idcard.android.ResultMessage;
import com.wintone.demo.idcard.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Service;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

//该类示例如何调用识别service，而不是调用识别activity
//该类已废弃
public class IDCardServiceActivity extends Activity {
	private int MainID = 0;
	private AuthService.authBinder authBinder;
    public RecogService.recogBinder recogBinder;
    private RecogParameterMessage rpm;
    private String selectPath = "";
    private EditText resultEditText;
    private int ReturnAuthority = -1;
    private int width;
    public static final String PATH = Environment.getExternalStorageDirectory().toString() + "/AndroidWT";
    private String[] type = { "一代身份证", "二代身份证正面", "二代身份证证背面", "临时身份证",
            "驾照", "行驶证", "军官证", "士兵证", "港澳通行证", "大陆通行证", "台湾通行证", "签证", "护照",
            "内地通行证正面", "内地通行证背面", "户口本" ,"车辆识别代号","广东省居住证","边防证A","边防证B","银行卡"};
	

    public ServiceConnection authConn = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
            authBinder = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            authBinder = (AuthService.authBinder) service;
            try {
            	ReturnAuthority = -1;
            	AuthParameterMessage apm = new AuthParameterMessage();
            	apm.sn = "";// WU9H5VSSDVXYB6KYYI52YYICW WUB7RVSN1JVYHFBYY7P9YYC37
            	apm.authfile = "";// /mnt/sdcard/auth/A1000038AB08A2_zj.txt
                ReturnAuthority = authBinder.getIDCardAuth(apm);
                
                if (ReturnAuthority != 0) {
                	Toast.makeText(getApplicationContext(), "授权验证失败，返回错误码："+ReturnAuthority, Toast.LENGTH_SHORT).show();
                }else {
                	Toast.makeText(getApplicationContext(), "授权验证成功", Toast.LENGTH_SHORT).show();
				} 
            }catch (Exception e) {
            	Toast.makeText(getApplicationContext(), "授权验证失败", Toast.LENGTH_SHORT).show();

            }finally{
                if (authBinder != null) {
                    unbindService(authConn);
                }
            }
        }


    };
    
    protected int readIntPreferences(String perferencesName, String key) {
    	SharedPreferences preferences = getSharedPreferences(perferencesName, MODE_PRIVATE);
	    int result = preferences.getInt(key, 0);
	    return result;
    }
    
    protected void writeIntPreferences(String perferencesName, String key, int value) {
        SharedPreferences preferences = getSharedPreferences(perferencesName, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(key, value);
        editor.commit();
    }
    
    public ServiceConnection recogConn = new ServiceConnection() {

        public void onServiceDisconnected(ComponentName name) {
        	recogBinder = null;
        }

        public void onServiceConnected(ComponentName name, IBinder service) {
        	recogBinder = (RecogService.recogBinder) service;
            try {
            	int nMainID = readIntPreferences("IDCardServiceActivity","MainID");
                if (nMainID == 0) {
                    nMainID = 2;
                }
                rpm.nTypeInitIDCard = 0;
                rpm.nTypeLoadImageToMemory = 0;
                rpm.nMainID = nMainID;
                rpm.nSubID = null;
                rpm.GetSubID = true;
                rpm.lpHeadFileName = "";
                rpm.GetVersionInfo = true;
                rpm.logo = "";
                rpm.array = null;
                rpm.userdata = "";
                rpm.lpFileName = selectPath;
                rpm.sn = ""; 
                rpm.authfile = "";
                rpm.isCut = true;
                ResultMessage resultMessage = recogBinder.getRecogResult(rpm);
                if (resultMessage.ReturnAuthority == 0 && resultMessage.ReturnInitIDCard == 0
                        && resultMessage.ReturnLoadImageToMemory == 0 && resultMessage.ReturnRecogIDCard > 0) {
                    String iDResultString = "";
                	String[] GetFieldName = resultMessage.GetFieldName;
                	String[] GetRecogResult = resultMessage.GetRecogResult;
                	for (int i = 0; i < GetRecogResult.length; i++) {
                		if (GetFieldName[i] != null && !GetFieldName[i].equals("") && !GetFieldName.equals("null")) {
                			iDResultString += GetFieldName[i]+":"+GetRecogResult[i]+"\n";
    					}
    				}
                	resultEditText.setText(iDResultString);
                } else {
                    String str = "";
                    if (resultMessage.ReturnAuthority == -100000) {
                        str = "未识别   代码： " + resultMessage.ReturnAuthority;
                    } else if (resultMessage.ReturnAuthority != 0) {
                        str = "激活失败 代码：" + resultMessage.ReturnAuthority;
                    } else if (resultMessage.ReturnInitIDCard != 0) {
                        str = "识别初始化失败 代码：" + resultMessage.ReturnInitIDCard; 
                    } else if (resultMessage.ReturnLoadImageToMemory != 0) {
                        if (resultMessage.ReturnLoadImageToMemory == 3) {
                            str = "识别载入图像失败，请重新识别 代码：" + resultMessage.ReturnLoadImageToMemory;
                        } else if(resultMessage.ReturnLoadImageToMemory == 1){
                            str = "识别载入图像失败，识别初始化失败,请重试 代码：" + resultMessage.ReturnLoadImageToMemory;
                        } else {
                            str = "识别载入图像失败 代码：" + resultMessage.ReturnLoadImageToMemory;
                        }
                    } else if (resultMessage.ReturnRecogIDCard != 0) {
                        str = "识别失败 代码：" + resultMessage.ReturnRecogIDCard;
                    }
                    resultEditText.setText("识别结果 :" + str + "\n");
                }


            }catch (Exception e) {
            	e.printStackTrace();
                Toast.makeText(getApplicationContext(), "识别服务调用失败", Toast.LENGTH_SHORT).show();

            }finally{
                if (recogBinder != null) {
                    unbindService(recogConn);
                }
            }
        }
    };
    
    
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		setContentView(R.layout.service);
        DisplayMetrics dm = new DisplayMetrics();  
        getWindowManager().getDefaultDisplay().getMetrics(dm); 
        width = dm.widthPixels;
        int edit_width = width/2;
		resultEditText = (EditText) findViewById(R.id.serviceEditText);
		RelativeLayout.LayoutParams lParams= new RelativeLayout.LayoutParams(edit_width,RelativeLayout.LayoutParams.WRAP_CONTENT);
        lParams.addRule(RelativeLayout.BELOW, R.id.recogservice);
        lParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        lParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
        lParams.topMargin = 50;
        lParams.bottomMargin = 10;
		resultEditText.setLayoutParams(lParams);
		Button authServiceButton = (Button) findViewById(R.id.authservice);
		authServiceButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
	            Intent authIntent = new Intent(IDCardServiceActivity.this, AuthService.class);
	            bindService(authIntent, authConn, Service.BIND_AUTO_CREATE);
			}
		});
		
		
		Button selectButton = (Button) findViewById(R.id.selecttype);
		selectButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				int mainID = readIntPreferences("IDCardServiceActivity","MainID");
				int choose = 0;
				if(mainID == 1000){
					choose = 17;
				}else if (mainID == 1003) {
					choose = 18;
				}else if (mainID == 1004) {
					choose = 19;
				}else if (mainID == 1100) {
					choose = 16;
				}else if (mainID == 1101) {
					choose = 20;
				}else{
					choose = mainID - 1;
				}
				new AlertDialog.Builder(IDCardServiceActivity.this)
				.setTitle("请选择证件类型")
				.setIcon(android.R.drawable.ic_dialog_info)
				.setSingleChoiceItems(type, choose,
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int which) {
								if(which == 16){
									MainID = 1100;
								}else if (which == 17) {
									MainID = 1000;
								}else if (which == 18) {
									MainID = 1003;
								}else if (which == 19) {
									MainID = 1004;
								}else if (which == 20) {
									MainID = 1101;
								}else{
									MainID = which + 1;
								}
							}
						})
				.setPositiveButton("确定", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						writeIntPreferences("IDCardServiceActivity","MainID",MainID);
						dialog.dismiss();
					}
				})
				.setNegativeButton("取消", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}})
				.show();
			}
		});
		
		Button recogButton = (Button) findViewById(R.id.recogservice);
		recogButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                Intent wrapperIntent = Intent.createChooser(intent, "Select Picture");
                startActivityForResult(wrapperIntent, 9);
                overridePendingTransition(R.anim.zoomin, R.anim.zoomout);
			}
		});
		
	}
	

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 9 && resultCode == Activity.RESULT_OK) {
        	rpm = new RecogParameterMessage();

            Uri uri = data.getData();
            Cursor cursor = getContentResolver().query(uri, null, null, null,null);
            if(cursor == null){
                 selectPath = uri.getPath();
            }else{
                cursor.moveToFirst();
                String imgPath = cursor.getString(1); 
                selectPath = imgPath;
            }
            if(selectPath != null && !selectPath.equals("") && !selectPath.equals("null")){
            	resultEditText.setText("");
            }
            new Thread(){
            	public void run() {
        		  	Intent recogIntent = new Intent(IDCardServiceActivity.this, RecogService.class);
                    bindService(recogIntent, recogConn, Service.BIND_AUTO_CREATE);
            	};
            }.start();
        }
	}
	
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			Intent intent = new Intent(getApplicationContext(), ImageChooser.class);
			startActivity(intent);
			IDCardServiceActivity.this.finish();
		}
		return super.onKeyDown(keyCode, event);
	}
	
	
}
