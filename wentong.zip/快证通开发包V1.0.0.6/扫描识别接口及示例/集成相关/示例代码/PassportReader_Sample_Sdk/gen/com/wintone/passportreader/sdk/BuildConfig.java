/** Automatically generated file. DO NOT MODIFY */
package com.wintone.passportreader.sdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}