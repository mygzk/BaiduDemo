package com.wintone.passportreader.sdk;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import wintone.idcard.android.AuthParameterMessage;
import wintone.idcard.android.AuthService;
import wintone.idcard.android.RecogParameterMessage;
import wintone.idcard.android.RecogService;
import wintone.idcard.android.ResultMessage;

import com.wintone.passport.sdk.utils.Devcode;
import com.wintone.passport.sdk.utils.FileManageActivity;
import com.wintone.passport.sdk.utils.SharedPreferencesHelper;
import com.wintone.passportreader.sdk.R;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Service;
import android.app.AlertDialog.Builder;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	private DisplayMetrics displayMetrics = new DisplayMetrics();
	private int srcWidth, srcHeight;
	private Button btn_chooserIdCardType, btn_takePicture, btn_exit,
			btn_importRecog, btn_ActivationProgram;
	private boolean isQuit = false;
	private Timer timer = new Timer();
	private String[][] type2 = { { "������", "3000" }, { "����", "13" },
			{ "��������֤", "2" }, { "�۰�ͨ��֤", "9" }, { "��½��������̨��ͨ��֤", "11" },
			{ "ǩ֤", "12" }, { "�°�۰�ͨ��֤", "22" }, { "�й�����", "5" },
			{ "�й���ʻ֤", "6" }, { "�������֤", "1001" }, { "����֤(����)", "14" },
			{ "����֤(����)", "15" }, { "��������֤", "1005" }, { "̨��֤", "10" },
			{ "�°�̨��֤(����)", "25" }, { "�°�̨��֤(����)", "26" },
			{ "̨������֤(����)", "1031" }, { "̨������֤(����)", "1032" },
			{ "ȫ�񽡿����տ�", "1030" }, { "������������֤", "2001" }, { "�¼�������֤", "2004" },
			{ "����������", "2003" }, { "���������Ǽ���", "2002" } };
	private int nMainID = 0;
	public static int DIALOG_ID = -1;
	private String[] type;
	public RecogService.recogBinder recogBinder;
	private String recogResultString = "";
	private String selectPath = "";
	private int nMainId = 2;
	private String[] recogTypes = { "������(2*44)", "������(2*36)", "������(3*30)" };
	private String[] IDCardTypes = { "����֤�����棩", "����֤�����棩" };
	private AuthService.authBinder authBinder;
	private int ReturnAuthority = -1;
	private String sn = "";
	private AlertDialog dialog;
	private EditText editText;
	private String devcode = Devcode.devcode;// ��Ŀ��Ȩ������
	public ServiceConnection authConn = new ServiceConnection() {
		@Override
		public void onServiceDisconnected(ComponentName name) {
			authBinder = null;
		}

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			authBinder = (AuthService.authBinder) service;
			try {

				AuthParameterMessage apm = new AuthParameterMessage();
				// apm.datefile = "assets"; // PATH+"/IDCard/wtdate.lsc";//Ԥ��
				apm.devcode = devcode;// Ԥ��
				apm.sn = sn;
				ReturnAuthority = authBinder.getIDCardAuth(apm);
				if (ReturnAuthority != 0) {
					Toast.makeText(getApplicationContext(),
							"ReturnAuthority:" + ReturnAuthority,
							Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(getApplicationContext(),
							getString(R.string.activation_success),
							Toast.LENGTH_SHORT).show();
				}

			} catch (Exception e) {
				e.printStackTrace();
				Toast.makeText(getApplicationContext(),
						getString(R.string.license_verification_failed),
						Toast.LENGTH_LONG).show();

			} finally {
				if (authBinder != null) {
					unbindService(authConn);
				}
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// ���ر���
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);// ����ȫ��
		// ��Ļ����
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
				WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
		srcWidth = displayMetrics.widthPixels;
		srcHeight = displayMetrics.heightPixels;
		setContentView(R.layout.activity_main);
		findView();
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		/*
		 * if
		 * (getResources().getConfiguration().locale.getLanguage().equals("zh")
		 * && getResources().getConfiguration().locale.getCountry()
		 * .equals("CN")) {
		 */
		type = new String[type2.length];

		for (int i = 0; i < type2.length; i++) {
			type[i] = type2[i][0];
		}

		// }
	}

	/**
	 * @Title: findView
	 * @Description: TODO(������һ�仰�����������������)
	 * @param �趨�ļ�
	 * @return void ��������
	 * @throws
	 */
	private void findView() {
		// TODO Auto-generated method stub
		btn_chooserIdCardType = (Button) this
				.findViewById(R.id.btn_chooserIdCardType);
		btn_takePicture = (Button) this.findViewById(R.id.btn_takePicture);
		btn_exit = (Button) this.findViewById(R.id.btn_exit);
		btn_importRecog = (Button) this.findViewById(R.id.btn_importRecog);
		btn_ActivationProgram = (Button) this
				.findViewById(R.id.btn_ActivationProgram);
		btn_ActivationProgram.setOnClickListener(this);
		btn_chooserIdCardType.setOnClickListener(this);
		btn_takePicture.setOnClickListener(this);
		btn_exit.setOnClickListener(this);
		btn_importRecog.setOnClickListener(this);
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
				srcWidth / 2, RelativeLayout.LayoutParams.WRAP_CONTENT);
		params.topMargin = (int) (srcHeight * 0.25);
		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		btn_ActivationProgram.setLayoutParams(params);
		params = new RelativeLayout.LayoutParams(srcWidth / 2,
				RelativeLayout.LayoutParams.WRAP_CONTENT);
		params.addRule(RelativeLayout.BELOW, R.id.btn_ActivationProgram);
		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		btn_chooserIdCardType.setLayoutParams(params);
		params = new RelativeLayout.LayoutParams(srcWidth / 2,
				RelativeLayout.LayoutParams.WRAP_CONTENT);
		params.addRule(RelativeLayout.BELOW, R.id.btn_chooserIdCardType);
		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		btn_takePicture.setLayoutParams(params);
		params = new RelativeLayout.LayoutParams(srcWidth / 2,
				RelativeLayout.LayoutParams.WRAP_CONTENT);
		params.addRule(RelativeLayout.BELOW, R.id.btn_takePicture);
		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		btn_importRecog.setLayoutParams(params);
		params = new RelativeLayout.LayoutParams(srcWidth / 2,
				RelativeLayout.LayoutParams.WRAP_CONTENT);
		params.addRule(RelativeLayout.BELOW, R.id.btn_importRecog);
		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		btn_exit.setLayoutParams(params);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.view.View.OnClickListener#onClick(android.view.View)
	 */
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		// ���кż�����¼�
		case R.id.btn_ActivationProgram:
			activationProgramOpera();
			break;
		// ֤�����Ͱ�ť
		case R.id.btn_chooserIdCardType:
			dialog();
			break;
		// ���հ�ť
		case R.id.btn_takePicture:
			Intent intent = new Intent(MainActivity.this, CameraActivity.class);
			intent.putExtra("nMainId", SharedPreferencesHelper.getInt(
					getApplicationContext(), "nMainId", 2));
			intent.putExtra("devcode", devcode);
			intent.putExtra("flag", 0);			
			MainActivity.this.finish();
			startActivity(intent);
			break;
		// ����ʶ��ť
		case R.id.btn_importRecog:
			if (SharedPreferencesHelper.getInt(getApplicationContext(),
					"nMainId", 2) == 3000) {
				createMachineReaderCodeDialog();

			}
			// else if (SharedPreferencesHelper.getInt(getApplicationContext(),
			// "nMainId", 2) == 2) {
			// createIDCardCodeDialog();
			// }
			else {
				intent = new Intent();
				intent.putExtra("title", getString(R.string.fileManage));
				intent.setDataAndType(Uri.fromFile(new File(Environment
						.getExternalStorageDirectory().toString())), "image/*");
				intent.setClass(MainActivity.this, FileManageActivity.class);

				startActivityForResult(intent, 9);
			}
			break;
		// �˳�
		case R.id.btn_exit:
			finish();
			break;
		default:
			break;
		}
	}

	/**
	 * @Title: activationProgramOpera
	 * @Description: TODO(������һ�仰�����������������)
	 * @param �趨�ļ�
	 * @return void ��������
	 * @throws
	 */
	private void activationProgramOpera() {
		// TODO Auto-generated method stub
		DIALOG_ID = 1;
		View view = getLayoutInflater().inflate(R.layout.serialdialog, null);
		editText = (EditText) view.findViewById(R.id.serialdialogEdittext);
		dialog = new AlertDialog.Builder(MainActivity.this)
				.setView(view)
				.setPositiveButton(getString(R.string.online_activation),
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int which) {
								InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
								if (imm.isActive()) {
									imm.toggleSoftInput(
											InputMethodManager.SHOW_IMPLICIT,
											InputMethodManager.HIDE_NOT_ALWAYS);
								}
								String editsString = editText.getText()
										.toString().toUpperCase();
								if (editsString != null) {
									sn = editsString;
								}
								if (isNetworkConnected(MainActivity.this)) {
									if (isWifiConnected(MainActivity.this)
											|| isMobileConnected(MainActivity.this)) {
										startAuthService();
										dialog.dismiss();
									} else if (!isWifiConnected(MainActivity.this)
											&& !isMobileConnected(MainActivity.this)) {
										Toast.makeText(
												getApplicationContext(),
												getString(R.string.network_unused),
												Toast.LENGTH_SHORT).show();
									}
								} else {
									Toast.makeText(
											getApplicationContext(),
											getString(R.string.please_connect_network),
											Toast.LENGTH_SHORT).show();
								}

							}

						})
				.setNegativeButton(getString(R.string.cancel),
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();

							}

						}).create();
		dialog.show();
	}

	/**
	 * @Title: createMachineReadCodeDialog
	 * @Description:����ϸ�ֻ�����ķ������ʾ��
	 * @param �趨�ļ�
	 * @return void ��������
	 * @throws
	 */
	private void createMachineReaderCodeDialog() {
		// TODO Auto-generated method stub
		DIALOG_ID = 2;
		AlertDialog.Builder recogTypeDialog = createAlertDialog(
				getString(R.string.chooseRecogType), null);
		recogTypeDialog.setSingleChoiceItems(recogTypes, 0, dialogListener);
		recogTypeDialog.show();
	}

	/**
	 * @Title: createMachineReadCodeDialog
	 * @Description:����ϸ������֤��������ķ������ʾ��
	 * @param �趨�ļ�
	 * @return void ��������
	 * @throws
	 */
	private void createIDCardCodeDialog() {
		// TODO Auto-generated method stub
		DIALOG_ID = 3;
		AlertDialog.Builder recogTypeDialog = createAlertDialog(
				getString(R.string.chooseRecogType), null);
		recogTypeDialog.setSingleChoiceItems(IDCardTypes, 0, dialogListener);
		recogTypeDialog.show();
	}

	/**
	 * @Title: dialog
	 * @Description: TODO(������һ�仰�����������������)
	 * @param �趨�ļ�
	 * @return void ��������
	 * @throws
	 */
	private void dialog() {
		// TODO Auto-generated method stub

		int checkedItem = -1;
		if (getResources().getConfiguration().locale.getLanguage().equals("zh")
				&& getResources().getConfiguration().locale.getCountry()
						.equals("CN")) {
			for (int i = 0; i < type2.length; i++) {

				if (Integer.valueOf(type2[i][1]) == SharedPreferencesHelper
						.getInt(getApplicationContext(), "nMainId", 2)) {
					checkedItem = i;
					break;
				}
			}

		}
		// �ܹ�ʹ�����б���ѡ��Ч������ʧ
		DIALOG_ID = 1;
		AlertDialog.Builder dialog = createAlertDialog(
				getString(R.string.chooseRecogType), null);
		dialog.setPositiveButton(getString(R.string.confirm), dialogListener);
		dialog.setNegativeButton(getString(R.string.cancel), dialogListener);
		dialog.setSingleChoiceItems(type, checkedItem,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {

						if (getResources().getConfiguration().locale
								.getLanguage().equals("zh")
								&& getResources().getConfiguration().locale
										.getCountry().equals("CN")) {
							for (int i = 0; i < type2.length; i++) {
								if (which == i) {
									nMainID = Integer.valueOf(type2[i][1]);
									break;
								}
							}

						}
					}
				});
		dialog.show();
	}

	/**
	 * @Title: createAlertDialog
	 * @Description: TODO(������һ�仰�����������������)
	 * @param @param string
	 * @param @param object
	 * @param @return �趨�ļ�
	 * @return Builder ��������
	 * @throws
	 */
	private Builder createAlertDialog(String title, String message) {
		// TODO Auto-generated method stub
		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle(title);
		dialog.setMessage(message);
		dialog.create();
		return dialog;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			if (isQuit == false) {
				isQuit = true;
				Toast.makeText(getBaseContext(), R.string.back_confirm, 2000)
						.show();
				TimerTask task = null;
				task = new TimerTask() {
					@Override
					public void run() {
						isQuit = false;
					}
				};
				timer.schedule(task, 2000);
			} else {
				finish();
			}
		}
		return true;
	}

	public DialogInterface.OnClickListener dialogListener = new DialogInterface.OnClickListener() {

		@Override
		public void onClick(DialogInterface dialog, int which) {

			switch (DIALOG_ID) {

			case 1:
				if (dialog.BUTTON_POSITIVE == which) {

					if (nMainID == 0)
						nMainID = 2;
					SharedPreferencesHelper.putInt(getApplicationContext(),
							"nMainId", nMainID);
					dialog.dismiss();
				} else if (dialog.BUTTON_NEGATIVE == which) {
					dialog.dismiss();
				}
				break;
			case 2:
				if (which == 0) {
					nMainId = 1034;
				} else if (which == 1) {
					nMainId = 1036;
				} else {
					nMainId = 1033;
				}
				Intent intent = new Intent();
				intent.putExtra("title", getString(R.string.fileManage));
				intent.putExtra("nMainId", nMainId);
				intent.setDataAndType(Uri.fromFile(new File(Environment
						.getExternalStorageDirectory().toString())), "image/*");
				intent.setClass(MainActivity.this, FileManageActivity.class);
				startActivityForResult(intent, 9);
				dialog.dismiss();
				break;
			case 3:
				if (which == 0) {
					nMainId = 2;
				} else if (which == 1) {
					nMainId = 3;
				}
				intent = new Intent();
				intent.putExtra("title", getString(R.string.fileManage));
				intent.putExtra("nMainId", nMainId);
				intent.setDataAndType(Uri.fromFile(new File(Environment
						.getExternalStorageDirectory().toString())), "image/*");
				intent.setClass(MainActivity.this, FileManageActivity.class);
				startActivityForResult(intent, 9);

				dialog.dismiss();
				break;

			}

		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if (requestCode == 9 && resultCode == Activity.RESULT_OK) {
			Uri uri = data.getData();
			selectPath = uri.getPath();
			nMainId = data.getIntExtra("nMainId", 2);
			RecogService.isRecogByPath = true;
			Intent recogIntent = new Intent(MainActivity.this,
					RecogService.class);
			bindService(recogIntent, recogConn, Service.BIND_AUTO_CREATE);
		}
	}

	// ʶ����֤
	public ServiceConnection recogConn = new ServiceConnection() {

		public void onServiceDisconnected(ComponentName name) {
			recogBinder = null;
		}

		public void onServiceConnected(ComponentName name, IBinder service) {

			recogBinder = (RecogService.recogBinder) service;

			RecogParameterMessage rpm = new RecogParameterMessage();
			rpm.nTypeLoadImageToMemory = 0;
			rpm.nMainID = SharedPreferencesHelper.getInt(
					getApplicationContext(), "nMainId", 2);
			rpm.nSubID = null;
			rpm.GetSubID = true;
			rpm.GetVersionInfo = true;
			rpm.logo = "";
			rpm.userdata = "";
			rpm.sn = "";
			rpm.authfile = "";
			rpm.isCut = true;
			rpm.triggertype = 0;
			rpm.devcode = devcode;
			rpm.lpFileName = selectPath; // rpm.lpFileName��Ϊ��ʱ����ִ���Զ�ʶ����
			if (SharedPreferencesHelper.getInt(getApplicationContext(),
					"nMainId", 2) == 2) {
				rpm.isAutoClassify = true;
				rpm.isOnlyClassIDCard = true;
			} else if (SharedPreferencesHelper.getInt(getApplicationContext(),
					"nMainId", 2) == 3000) {
				rpm.nMainID = nMainId;
			}
			// end
			try {

				ResultMessage resultMessage;
				resultMessage = recogBinder.getRecogResult(rpm);
				if (resultMessage.ReturnAuthority == 0
						&& resultMessage.ReturnInitIDCard == 0
						&& resultMessage.ReturnLoadImageToMemory == 0
						&& resultMessage.ReturnRecogIDCard > 0) {
					String iDResultString = "";
					String[] GetFieldName = resultMessage.GetFieldName;
					String[] GetRecogResult = resultMessage.GetRecogResult;

					for (int i = 1; i < GetFieldName.length; i++) {
						if (GetRecogResult[i] != null) {
							if (!recogResultString.equals(""))
								recogResultString = recogResultString
										+ GetFieldName[i] + ":"
										+ GetRecogResult[i] + ",";
							else {
								recogResultString = GetFieldName[i] + ":"
										+ GetRecogResult[i] + ",";
							}
						}
					}
					Intent intent = new Intent(MainActivity.this,
							ShowResultActivity.class);
					intent.putExtra("recogResult", recogResultString);
					MainActivity.this.finish();
					startActivity(intent);
				} else {
					String string = "";
					if (resultMessage.ReturnAuthority == -100000) {
						string = getString(R.string.exception)
								+ resultMessage.ReturnAuthority;
					} else if (resultMessage.ReturnAuthority != 0) {
						string = getString(R.string.exception1)
								+ resultMessage.ReturnAuthority;
					} else if (resultMessage.ReturnInitIDCard != 0) {
						string = getString(R.string.exception2)
								+ resultMessage.ReturnInitIDCard;
					} else if (resultMessage.ReturnLoadImageToMemory != 0) {
						if (resultMessage.ReturnLoadImageToMemory == 3) {
							string = getString(R.string.exception3)
									+ resultMessage.ReturnLoadImageToMemory;
						} else if (resultMessage.ReturnLoadImageToMemory == 1) {
							string = getString(R.string.exception4)
									+ resultMessage.ReturnLoadImageToMemory;
						} else {
							string = getString(R.string.exception5)
									+ resultMessage.ReturnLoadImageToMemory;
						}
					} else if (resultMessage.ReturnRecogIDCard <= 0) {
						if (resultMessage.ReturnRecogIDCard == -6) {
							string = getString(R.string.exception9);
						} else {
							string = getString(R.string.exception6)
									+ resultMessage.ReturnRecogIDCard;
						}
					}
					Intent intent = new Intent(MainActivity.this,
							ShowResultActivity.class);
					intent.putExtra("exception", string);
					MainActivity.this.finish();
					startActivity(intent);
				}
			} catch (Exception e) {
				e.printStackTrace();
				Toast.makeText(getApplicationContext(),
						getString(R.string.recognized_failed),
						Toast.LENGTH_SHORT).show();

			} finally {
				if (recogBinder != null) {
					unbindService(recogConn);
				}
			}

		}
	};

	private void startAuthService() {
		Intent authIntent = new Intent(MainActivity.this, AuthService.class);
		bindService(authIntent, authConn, Service.BIND_AUTO_CREATE);
	}

	public boolean isNetworkConnected(Context context) {
		if (context != null) {
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo mNetworkInfo = mConnectivityManager
					.getActiveNetworkInfo();
			if (mNetworkInfo != null) {
				return mNetworkInfo.isAvailable();
			}
		}
		return false;
	}

	public boolean isWifiConnected(Context context) {
		if (context != null) {
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo mWiFiNetworkInfo = mConnectivityManager
					.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
			if (mWiFiNetworkInfo != null) {
				return mWiFiNetworkInfo.isAvailable();
			}
		}
		return false;
	}

	public boolean isMobileConnected(Context context) {
		if (context != null) {
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo mMobileNetworkInfo = mConnectivityManager
					.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
			if (mMobileNetworkInfo != null) {
				return mMobileNetworkInfo.isAvailable();
			}
		}
		return false;
	}

}
