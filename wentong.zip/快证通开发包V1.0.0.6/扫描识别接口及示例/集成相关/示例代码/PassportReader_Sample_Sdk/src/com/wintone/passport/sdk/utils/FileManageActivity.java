package com.wintone.passport.sdk.utils;

import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore.Images.Media;
import android.provider.MediaStore.Images.Thumbnails;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.BaseAdapter;
import android.widget.Toast;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.content.ContentResolver;
import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.app.Activity;
import android.app.ListActivity;
import android.view.WindowManager;
import android.view.Display;
import android.view.WindowManager.LayoutParams;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Field;

import com.wintone.passportreader.sdk.MainActivity;
import com.wintone.passportreader.sdk.R;

/**
 * 
 * 
 * ��Ŀ���ƣ�excelIODemo �����ƣ�FileManageActivity ��������������Ҫʵ���ļ���������������ܣ�֧�ֵ���͵����� �����ˣ�����
 * ����ʱ�䣺2014-11-9 ����8:03:47 �޸��ˣ����� �޸�ʱ�䣺2014-11-9 ����8:03:47 �޸ı�ע��
 * 
 * @version
 * 
 */
public class FileManageActivity extends Activity {
    private List<Map<String, Object>> mData;
    private String mDir = Environment.getExternalStorageDirectory().toString();
    private ListView filename_list;

    private RelativeLayout relativeLayout;
    private int srcHeight, srcWidth;
    private DisplayMetrics displayMetrics = new DisplayMetrics();
    private List<String> mDirs = new ArrayList<String>();
    private Intent intent1;
    private String btn_type;

    private String path = Environment.getExternalStorageDirectory().toString()
            + "/";
    private Bitmap bitmap;
    private ArrayList<HashMap<String, String>> thumbnailList;
    private ContentResolver cr;
    private int nMainId = 2;

    @Override
    protected void onStart() {
        // TODO Auto-generated method stub

        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        srcHeight = displayMetrics.heightPixels;
        srcWidth = displayMetrics.widthPixels;
        findView();
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.filemanage);
        Intent intent = this.getIntent();
        Bundle bl = intent.getExtras();
        String title = bl.getString("title");
        nMainId = intent.getIntExtra("nMainId", 2);

        Uri uri = intent.getData();
        mDir = uri.getPath();
        setTitle(title);
        mData = getData();
        // ���android�豸����������ͼ��IMAGE_ID�Ͷ�Ӧ������ͼ��·�������б�thumbnailList��
        thumbnailList = new ArrayList<HashMap<String, String>>();
        cr = getContentResolver();
        String[] projection = { Thumbnails._ID, Thumbnails.IMAGE_ID,
                Thumbnails.DATA };
        Cursor cursor = cr.query(Thumbnails.EXTERNAL_CONTENT_URI, projection,
                null, null, null);
        thumbnailList = getColumnData(cursor);
    }

    /**
     * 
     * @Title: findView
     * @Description: UI�����ʼ��
     * @param �趨�ļ�
     * @return void ��������
     * @throws
     */
    private void findView() {
        filename_list = (ListView) this.findViewById(R.id.filename_list);
        relativeLayout = (RelativeLayout) this
                .findViewById(R.id.relativeLayout);
        RelativeLayout.LayoutParams lParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT, srcHeight);
        relativeLayout.setLayoutParams(lParams);
        MyAdapter adapter = new MyAdapter(this);
        filename_list.setAdapter(adapter);
        filename_list.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                    int position, long arg3) {

                // TODO Auto-generated method stub
                // �����Ŀ¼ ��� �����ݹ� �鿴��·���µ������ļ����ļ��У����߷�����һĿ¼
                if ((Integer) mData.get(position).get("img") == R.drawable.ex_folder) {
                    mDir = (String) mData.get(position).get("info");
                    path = mDir;
                    mDirs.add(mDir);
                    mData = getData();
                    MyAdapter adapter = new MyAdapter(FileManageActivity.this);
                    filename_list.setAdapter(adapter);
                } else {

                    // ������ļ������ �����ļ�·���ش�����һҳ��
                    finishWithResult((String) mData.get(position).get("info"));

                }
            }
        });
    }

    // ��ȡ��ǰ·���µ������ļ��к��ļ�
    private List<Map<String, Object>> getData() {

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = null;
        File f = new File(mDir);
        File[] files = f.listFiles();

        if (!mDir.equals(Environment.getExternalStorageDirectory().toString())) {
            map = new HashMap<String, Object>();
            map.put("title", getString(R.string.backLastDir));
            map.put("info", f.getParent());
            map.put("img", R.drawable.ex_folder);
            list.add(map);

        }
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                map = new HashMap<String, Object>();
                map.put("title", files[i].getName());
                map.put("info", files[i].getPath());

                if (files[i].isDirectory())// �Ƿ���Ŀ¼

                {
                    map.put("img", R.drawable.ex_folder);

                } else if (files[i].getName().length() >= 4) {
                    if (files[i]
                            .getName()
                            .substring(files[i].getName().length() - 4,
                                    files[i].getName().length()).equals(".jpg")
                            || files[i]
                                    .getName()
                                    .substring(files[i].getName().length() - 4,
                                            files[i].getName().length())
                                    .equals(".JPG")) {
                        map.put("img", 1000);
                    } else {
                        // ����ļ����ĳ��ȴ���4��������.jpg��β�Ļ��ǽ��ļ�ͼƬ������
                        map.put("img", R.drawable.ex_doc);
                        // map.put("img", bitmap1);
                    }
                } else {
                    map.put("img", R.drawable.ex_doc);
                    // map.put("img", bitmap1);
                }

                list.add(map);
            }
        }
        return list;
    }

    public final class ViewHolder {
        public ImageView img;
        public TextView title;
        public TextView info;

    }

    /**
     * 
     * 
     * ��Ŀ���ƣ�excelIODemo �����ƣ�MyAdapter ���������Զ��� Adapter �����ˣ����� ����ʱ�䣺2014-11-9
     * ����8:05:02 �޸��ˣ����� �޸�ʱ�䣺2014-11-9 ����8:05:02 �޸ı�ע��
     * 
     * @version
     * 
     */
    public class MyAdapter extends BaseAdapter {
        private LayoutInflater mInflater;

        public MyAdapter(Context context) {
            this.mInflater = LayoutInflater.from(context);

        }

        public int getCount() {
            return mData.size();
        }

        public Object getItem(int arg0) {
            return null;
        }

        public long getItemId(int arg0) {
            return 0;
        }

        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            if (convertView == null) {
                holder = new ViewHolder();
                convertView = mInflater.inflate(R.layout.filemanage_listview,
                        null);
                holder.img = (ImageView) convertView.findViewById(R.id.img);
                holder.title = (TextView) convertView.findViewById(R.id.title);
                // holder.info = (TextView)
                // convertView.findViewById(R.id.info);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            // �����»�����ʱ�򽫽�Ҫ����ʾ��ͼƬ���������
            holder.img.setImageBitmap(null);
            holder.img.setBackgroundResource(0);
            if ((Integer) mData.get(position).get("img") == 1000) {
                // Android thumbnail ����ͼ�Ļ�ȡ����ԭʼͼƬ��ӳ���ϵ
                String thumbnailPath = "";
                String media_id = "";
                String[] projection1 = { Media._ID, Media.DATA };
                String[] whereArgs = { (String) mData.get(position).get("info") };// �޸������Ĳ���
                // �ȸ���ԭʼͼƬ��·������ѯ�����ݿ�ı�image��Media._ID��ֵ
                Cursor cursor1 = cr.query(Media.EXTERNAL_CONTENT_URI,
                        projection1, Media.DATA + "=?", whereArgs, null);
                if (cursor1 != null) {
                    while (cursor1.moveToNext()) {
                        media_id = cursor1.getString(cursor1
                                .getColumnIndex(Media._ID));
                    }
                    cursor1.close();
                }
                // ����ԭʼͼ���Media._ID�����β�ѯ����ͼ��Ĵ洢·��
                for (int i = 0; i < thumbnailList.size(); i++) {
                    if (media_id.equals(thumbnailList.get(i).get("image_id"))) {
                        thumbnailPath = thumbnailList.get(i).get("path");
                        break;
                    }

                }
                if (thumbnailPath != null && !thumbnailPath.equals("")) {
                    // ����洢·����Ϊ�ղ��Ҳ����ڿ�ֵ����֤��������ͼ�����ǽ�����ͼ����ԭʼͼ��ʾ��������
                    String[] str = thumbnailPath.split("/");
                    byte[] data = Stream2Byte(thumbnailPath);
                    if(data!=null)
                    bitmap = BitmapFactory
                            .decodeByteArray(data, 0, data.length);
                    if (bitmap == null) {
                        holder.img.setBackgroundResource(R.drawable.picture);
                    } else {
                        holder.img.setImageBitmap(bitmap);
                    }
                    
                } else if (thumbnailPath.equals("")) {
                    // �������ͼ��û�м��أ���������ʾԭʼͼ����ʾǰ�轫ͼ���һ��ѹ������ֹOOM
                    File file = new File((String) mData.get(position).get(
                            "info"));
                    // ͼƬ�Ĵ���
                    FileInputStream fis = null;
                    try {

                        BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inInputShareable = true;
                        opts.inPurgeable = true;
                        // ����ȡ�������鵽�ڴ��У�����ȡͼƬ����Ϣ
                        opts.inJustDecodeBounds = true;
                        fis = new FileInputStream(file);
                        BitmapFactory.decodeStream(fis, null, opts);
                        // ��Options�л�ȡͼƬ�ķֱ���
                        int imageHeight = opts.outHeight;
                        int imageWidth = opts.outWidth;
                        int scaleX = imageWidth / 640;
                        int scaleY = imageHeight / 480;
                        int scale = 1;
                        // �������������ķ���Ϊ׼
                        if (scaleX > scaleY && scaleY >= 1) {
                            scale = scaleX;
                        }
                        if (scaleX < scaleY && scaleX >= 1) {
                            scale = scaleY;
                        }

                        BitmapFactory.Options opts1 = new BitmapFactory.Options();
                        opts1.inInputShareable = true;
                        opts1.inPurgeable = true;
                        // ������
                        opts1.inSampleSize = scale;
                        fis = new FileInputStream(file);
                        byte[] data = Stream2Byte((String) mData.get(position)
                                .get("info"));
                        long time = System.currentTimeMillis();

                        bitmap = BitmapFactory.decodeByteArray(data, 0,
                                data.length, opts1);
                        if (bitmap == null) {
                            // ���bitmapΪ����֤����ͼƬ�Ĵ�СΪ0������ʾ�Ѿ�׼���õ�ͼƬ
                            holder.img
                                    .setBackgroundResource(R.drawable.picture);
                        } else {
                            // �����Ϊ�գ�����ʾ��������ͼ��
                            // System.out.println("position:" + position);
                            holder.img.setImageBitmap(bitmap);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {
                // ������ļ�������Ƭ��������ʾ���ı���ʽ��
                holder.img.setBackgroundResource((Integer) mData.get(position)
                        .get("img"));
            }
            holder.title.setText((String) mData.get(position).get("title"));
            return convertView;
        }
    }

    private void finishWithResult(String path) {
        Bundle conData = new Bundle();
        conData.putString("results", "Thanks Thanks");
        conData.putInt("nMainId", nMainId);
        Intent intent = new Intent();
        intent.putExtras(conData);
        Uri startDir = Uri.fromFile(new File(path));
        intent.setDataAndType(startDir, "image/*");
        setResult(RESULT_OK, intent);
        finish();
    }

    // �������ؼ��¼�
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            Intent intent = new Intent(FileManageActivity.this,
                    MainActivity.class);
            FileManageActivity.this.finish();
            startActivity(intent);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * 
     * @Title: showMess
     * @Description: TODO ������ʾ��ʾ��Ϣ
     * @param @param s �趨�ļ�
     * @return void ��������
     * @throws
     */
    private void showMess(String s) {
        Toast toast = Toast.makeText(getBaseContext(), s, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 20, 30);
        toast.show();
    }

    /*
     * ��������ת�����ֽ�����
     */
    public byte[] Stream2Byte(String infile) {

        BufferedInputStream in = null;
        ByteArrayOutputStream out = null;
        try {
            in = new BufferedInputStream(new FileInputStream(infile));
            out = new ByteArrayOutputStream(1024);
            byte[] temp = new byte[1024];
            int size = 0;
            while ((size = in.read(temp)) != -1) {
                out.write(temp, 0, size);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        byte[] content = null;
        if (out != null)
            try {
                content = out.toByteArray();
                out.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        return content;
    }

    private ArrayList<HashMap<String, String>> getColumnData(Cursor cur) {
        ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
        if (cur.moveToFirst()) {
            int _id;
            int image_id;
            String image_path;
            int _idColumn = cur.getColumnIndex(Thumbnails._ID);
            int image_idColumn = cur.getColumnIndex(Thumbnails.IMAGE_ID);
            int dataColumn = cur.getColumnIndex(Thumbnails.DATA);

            do {
                // Get the field values
                _id = cur.getInt(_idColumn);
                image_id = cur.getInt(image_idColumn);
                image_path = cur.getString(dataColumn);

                // Do something with the values.
                // System.out.println(_id + " image_id:" + image_id + " path:"
                // + image_path + "---");
                HashMap hash = new HashMap();
                hash.put("image_id", image_id + "");
                hash.put("path", image_path);
                list.add(hash);

            } while (cur.moveToNext());
            cur.close();

        }
        return list;
    }
};
