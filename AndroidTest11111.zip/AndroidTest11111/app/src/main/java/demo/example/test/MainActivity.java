package demo.example.test;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import demo.example.test.fragment.FirstFragment;
import demo.example.test.fragment.SecondFragment;
import demo.example.test.fragment.ThirdFragment;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btn1;
    private Button btn2;
    private Button btn3;

    private FirstFragment firstFragment;
    private SecondFragment secondFragment;
    private ThirdFragment thirdFragment;

    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        findViewById(R.id.btn1).setOnClickListener(this);
        findViewById(R.id.btn2).setOnClickListener(this);
        findViewById(R.id.btn3).setOnClickListener(this);
        findViewById(R.id.btn4).setOnClickListener(this);
        findViewById(R.id.btn5).setOnClickListener(this);
        findViewById(R.id.btn6).setOnClickListener(this);

        drawerLayout =(DrawerLayout) findViewById(R.id.drawerlayout);

        initFragment(1);
    }

    private void initFragment(int type) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.setCustomAnimations(
                R.anim.push_left_in,
                R.anim.push_left_out,
                R.anim.push_left_in,
                R.anim.push_left_out);
        switch (type) {
            case 1:
                if (firstFragment == null) {
                    firstFragment = new FirstFragment();
                    fragmentTransaction.add(R.id.container, firstFragment);
                } else {
                    hideFragment(fragmentTransaction, firstFragment);
                }
                fragmentTransaction.show(firstFragment);
                break;
            case 2:
                if (secondFragment == null) {
                    secondFragment = new SecondFragment();
                    fragmentTransaction.add(R.id.container, secondFragment);
                } else {
                    hideFragment(fragmentTransaction, secondFragment);
                }
                fragmentTransaction.show(secondFragment);
                break;
            case 3:
                if (thirdFragment == null) {
                    thirdFragment = new ThirdFragment();
                    fragmentTransaction.add(R.id.container, thirdFragment);
                } else {
                    hideFragment(fragmentTransaction, thirdFragment);
                }
                fragmentTransaction.show(thirdFragment);
                break;
        }
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    private void hideFragment(FragmentTransaction fragmentTransaction, Fragment fragment) {
        if (firstFragment != null) {
            fragmentTransaction.hide(firstFragment);
        }

        if (secondFragment != null) {
            fragmentTransaction.hide(secondFragment);
        }

        if (thirdFragment != null) {
            fragmentTransaction.hide(thirdFragment);
        }


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn1:
            case R.id.btn4:
                drawerLayout.closeDrawers();
                initFragment(1);
                break;
            case R.id.btn2:
            case R.id.btn5:
                drawerLayout.closeDrawers();
               // drawerLayout.closeDrawer(Gravity.LEFT);
                initFragment(2);
                break;
            case R.id.btn3:
            case R.id.btn6:
                drawerLayout.closeDrawers();
                initFragment(3);
                break;
        }
    }
}
