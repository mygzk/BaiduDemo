package com.meng.slidemenum.ui;

public interface Constant {
	public static final String[] sCheeseStrings = { "开通会员", "QQ钱包", "我的相册",
			"我的文件", "我的好友", "设置", "我们", "关于", "a", "b", "c", "d", "e", "f",
			"g", "h" };

	public static final String[] NAMES = new String[] { "刘亦菲", "刘诗诗", "刘涛",
			"吴奇隆", "霍建华", "赵丽颖", "蒋欣", "孙俪", "邓超", "林青霞", "谢娜", "何炅", "袁弘",
			"张娜拉", "韩佳人" };
}
