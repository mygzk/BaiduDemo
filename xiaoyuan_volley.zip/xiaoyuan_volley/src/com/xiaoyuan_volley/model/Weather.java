package com.xiaoyuan_volley.model;


public class Weather {
	private Weather weatherinfo;
	private String city;
	private String date_y;
	public Weather getWeatherinfo() {
		return weatherinfo;
	}
	public void setWeatherinfo(Weather weatherinfo) {
		this.weatherinfo = weatherinfo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDate_y() {
		return date_y;
	}
	public void setDate_y(String date_y) {
		this.date_y = date_y;
	}
	
}
