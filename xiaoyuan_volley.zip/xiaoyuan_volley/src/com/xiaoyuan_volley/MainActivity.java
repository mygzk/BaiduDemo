package com.xiaoyuan_volley;

import com.android.volley.VolleyError;
import com.xiaoyuan_volley.model.Weather;
import com.xiaoyuan_volley.volley.IRequest;
import com.xiaoyuan_volley.volley.RequestJsonListener;
import com.xiaoyuan_volley.volley.RequestListener;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends BaseActivity {
	String url  = "http://m.weather.com.cn/data/101010100.html";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		IRequest.get(this, "https://www.baidu.com/", null, new RequestListener() {
			
			@Override
			public void requestSuccess(String json) {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this, json, Toast.LENGTH_SHORT).show();
			}
			@Override
			public void requestError(VolleyError e) {
				// TODO Auto-generated method stub
			}
		});
		IRequest.get(this, url, Weather.class, null, new RequestJsonListener<Weather>() {

			@Override
			public void requestSuccess(Weather result) {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this, result.getWeatherinfo().getCity(), Toast.LENGTH_SHORT).show();
			}
			@Override
			public void requestError(VolleyError e) {
				// TODO Auto-generated method stub
			}
		});
	}
}
