/** Automatically generated file. DO NOT MODIFY */
package com.xiaoyuan_volley;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}